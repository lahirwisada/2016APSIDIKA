<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-05 03:05:39 --> Config Class Initialized
DEBUG - 2016-09-05 03:05:39 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:05:39 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:05:39 --> URI Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Router Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Output Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:05:40 --> Security Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Input Class Initialized
DEBUG - 2016-09-05 03:05:40 --> XSS Filtering completed
DEBUG - 2016-09-05 03:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:05:40 --> Language Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Loader Class Initialized
DEBUG - 2016-09-05 03:05:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:05:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:05:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:05:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:05:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:05:40 --> Database Driver Class Initialized
ERROR - 2016-09-05 03:05:41 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-05 03:05:41 --> Unable to connect to the database
DEBUG - 2016-09-05 03:05:41 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-05 03:05:57 --> Config Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:05:57 --> URI Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Router Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Output Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Security Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Input Class Initialized
DEBUG - 2016-09-05 03:05:57 --> XSS Filtering completed
DEBUG - 2016-09-05 03:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:05:57 --> Language Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Loader Class Initialized
DEBUG - 2016-09-05 03:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:05:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:05:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:05:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:05:57 --> Database Driver Class Initialized
ERROR - 2016-09-05 03:05:58 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-05 03:05:58 --> Unable to connect to the database
DEBUG - 2016-09-05 03:05:58 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-05 03:06:14 --> Config Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:06:14 --> URI Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Router Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Output Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Security Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Input Class Initialized
DEBUG - 2016-09-05 03:06:14 --> XSS Filtering completed
DEBUG - 2016-09-05 03:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:06:14 --> Language Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Loader Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:06:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:06:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:06:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:06:14 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Session Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:06:14 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:06:14 --> A session cookie was not found.
DEBUG - 2016-09-05 03:06:14 --> Session routines successfully run
DEBUG - 2016-09-05 03:06:14 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:06:14 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:06:14 --> Controller Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:06:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:06:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:06:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:06:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:06:14 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:06:14 --> Model Class Initialized
ERROR - 2016-09-05 03:06:16 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:06:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Config Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:07:15 --> URI Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Router Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Output Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Security Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Input Class Initialized
DEBUG - 2016-09-05 03:07:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:07:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:07:15 --> Language Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Loader Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:07:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:07:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:07:15 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Session Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:07:15 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:07:15 --> Session routines successfully run
DEBUG - 2016-09-05 03:07:15 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:07:15 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:07:15 --> Controller Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:07:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:07:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:07:15 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:07:15 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:07:15 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
ERROR - 2016-09-05 03:07:15 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:07:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-05 03:07:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:07:16 --> Final output sent to browser
DEBUG - 2016-09-05 03:07:16 --> Total execution time: 0.4057
DEBUG - 2016-09-05 03:07:16 --> Config Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:07:16 --> URI Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Router Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Output Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Security Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Input Class Initialized
DEBUG - 2016-09-05 03:07:16 --> XSS Filtering completed
DEBUG - 2016-09-05 03:07:16 --> XSS Filtering completed
DEBUG - 2016-09-05 03:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:07:16 --> Language Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Loader Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:07:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:07:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:07:16 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Session Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:07:16 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:07:16 --> Session routines successfully run
DEBUG - 2016-09-05 03:07:16 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:07:16 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:07:16 --> Controller Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:07:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:07:16 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:07:16 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:07:16 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
ERROR - 2016-09-05 03:07:16 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:07:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-05 03:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-05 03:07:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/443396ecb580fa899fc67dd641c1c819
DEBUG - 2016-09-05 03:07:16 --> Final output sent to browser
DEBUG - 2016-09-05 03:07:16 --> Total execution time: 0.2337
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:32 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:32 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:32 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:32 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:32 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
ERROR - 2016-09-05 03:08:32 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:08:32 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:32 --> Total execution time: 0.3092
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73b83fb27e3327c2f56c56aba4c0a331
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.3119
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.4047
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bdda70e0840f92f1c0eee835c5128d40
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.5170
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.6270
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5b934a21cec2e54850424d2920de25c8
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.7600
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:08:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:33 --> Total execution time: 0.9009
DEBUG - 2016-09-05 03:08:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:33 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:33 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:33 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:08:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:33 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.7057
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: Yes
ERROR - 2016-09-05 03:08:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.7579
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: file_helper
ERROR - 2016-09-05 03:08:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:34 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.7994
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:08:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.8292
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: conf_helper
ERROR - 2016-09-05 03:08:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.8687
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Database Driver Class Initialized
ERROR - 2016-09-05 03:08:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:34 --> Total execution time: 0.8916
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:34 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:34 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:34 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:34 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:08:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:35 --> Total execution time: 0.9947
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:35 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:35 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:35 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:35 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:35 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:08:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:35 --> Total execution time: 1.0246
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:35 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:35 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:35 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:35 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
ERROR - 2016-09-05 03:08:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Total execution time: 1.0626
DEBUG - 2016-09-05 03:08:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:35 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:35 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:35 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: file_helper
ERROR - 2016-09-05 03:08:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:08:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:35 --> Total execution time: 1.1805
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:35 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:35 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: No
ERROR - 2016-09-05 03:08:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:35 --> Total execution time: 1.1876
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:35 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:35 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:35 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:35 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:35 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:35 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:35 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:35 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:35 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: crypto_helper
ERROR - 2016-09-05 03:08:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/2d461f2b02f602c1e15bf7847b419b66
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:36 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Total execution time: 1.2286
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:36 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:36 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:36 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:36 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:36 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:36 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: sidika_helper
ERROR - 2016-09-05 03:08:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d612482e4e77821b617e68f9033e8910
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> Total execution time: 1.2111
DEBUG - 2016-09-05 03:08:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:36 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Config Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:08:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:36 --> URI Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Router Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Output Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:36 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Security Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Input Class Initialized
DEBUG - 2016-09-05 03:08:36 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> XSS Filtering completed
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Language Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Loader Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
ERROR - 2016-09-05 03:08:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/72299799e7be2698f2763d20cbe6582e
DEBUG - 2016-09-05 03:08:36 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:36 --> Total execution time: 1.2345
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:08:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:08:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:08:36 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/10f18dab9dad5a443779bd2325894a0c
DEBUG - 2016-09-05 03:08:36 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:36 --> Total execution time: 1.2316
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:36 --> Session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:36 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:08:36 --> Session routines successfully run
DEBUG - 2016-09-05 03:08:36 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:36 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
ERROR - 2016-09-05 03:08:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b69a0d6fb1177b7d8e2df256265692d6
DEBUG - 2016-09-05 03:08:36 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:36 --> Total execution time: 1.2160
DEBUG - 2016-09-05 03:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:37 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
ERROR - 2016-09-05 03:08:37 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a18ef52a5acab6505e709ea5839991a9
DEBUG - 2016-09-05 03:08:37 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:37 --> Total execution time: 1.2708
DEBUG - 2016-09-05 03:08:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:37 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
ERROR - 2016-09-05 03:08:37 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/40c1006990c613844d744bffb3779912
DEBUG - 2016-09-05 03:08:37 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:37 --> Total execution time: 1.3025
DEBUG - 2016-09-05 03:08:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:08:37 --> Controller Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:08:37 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
ERROR - 2016-09-05 03:08:37 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:08:37 --> Model Class Initialized
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cabc5d4df53e8b71459ea1d83d04b09b
DEBUG - 2016-09-05 03:08:37 --> Final output sent to browser
DEBUG - 2016-09-05 03:08:37 --> Total execution time: 1.3111
DEBUG - 2016-09-05 03:09:49 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:49 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:49 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:49 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:49 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:49 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:49 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:49 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:50 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:50 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
ERROR - 2016-09-05 03:09:50 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:09:50 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:50 --> Total execution time: 0.7304
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:50 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:50 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:50 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:50 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:50 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
ERROR - 2016-09-05 03:09:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:09:51 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:51 --> Total execution time: 0.8941
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:51 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:51 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:51 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:51 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:51 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:09:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:51 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Total execution time: 1.1519
DEBUG - 2016-09-05 03:09:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:51 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:51 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:51 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: file_helper
ERROR - 2016-09-05 03:09:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:51 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5b934a21cec2e54850424d2920de25c8
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:51 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Total execution time: 1.4297
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:51 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:51 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:51 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:51 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:09:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:51 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bdda70e0840f92f1c0eee835c5128d40
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:52 --> Total execution time: 1.6914
DEBUG - 2016-09-05 03:09:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:52 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:52 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:52 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:09:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:09:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Total execution time: 1.9649
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:52 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
ERROR - 2016-09-05 03:09:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73b83fb27e3327c2f56c56aba4c0a331
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:52 --> Total execution time: 2.2732
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:52 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:52 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:52 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:52 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:52 --> Total execution time: 1.5851
DEBUG - 2016-09-05 03:09:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:52 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:52 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:52 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:53 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:53 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:53 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:53 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:53 --> Total execution time: 1.6434
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:53 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:53 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:53 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:53 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: No
ERROR - 2016-09-05 03:09:53 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:53 --> Total execution time: 1.6741
DEBUG - 2016-09-05 03:09:53 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:53 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:53 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:53 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:53 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:53 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:09:53 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Total execution time: 1.7413
DEBUG - 2016-09-05 03:09:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:53 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:53 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:53 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:53 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:53 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
ERROR - 2016-09-05 03:09:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:54 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:09:54 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Total execution time: 1.8296
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:54 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:54 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:54 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:54 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: Yes
ERROR - 2016-09-05 03:09:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:54 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:54 --> Total execution time: 1.8600
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:54 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:54 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:54 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:54 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:54 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:54 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:54 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:54 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:54 --> Total execution time: 1.9056
DEBUG - 2016-09-05 03:09:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:54 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:54 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:54 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:54 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:54 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:55 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:55 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:55 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:09:55 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:55 --> Total execution time: 1.9183
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:55 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:55 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:55 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:55 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:55 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:55 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:55 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:55 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:55 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:09:55 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Total execution time: 1.9550
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:55 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:55 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:55 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:55 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:55 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:55 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:55 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:55 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:55 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:55 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:55 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:09:55 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:55 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:55 --> Total execution time: 1.9539
DEBUG - 2016-09-05 03:09:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:56 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:56 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:56 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:56 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: file_helper
ERROR - 2016-09-05 03:09:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Total execution time: 2.0258
DEBUG - 2016-09-05 03:09:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:56 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:56 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:56 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:56 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:09:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:56 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/2d461f2b02f602c1e15bf7847b419b66
DEBUG - 2016-09-05 03:09:56 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Total execution time: 2.0627
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:56 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:56 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:56 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:56 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:56 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:09:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:56 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:09:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d612482e4e77821b617e68f9033e8910
DEBUG - 2016-09-05 03:09:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Total execution time: 2.0843
DEBUG - 2016-09-05 03:09:57 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:57 --> Config Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:57 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:57 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:57 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:57 --> URI Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Router Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:57 --> Output Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> Security Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:57 --> Input Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:57 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> XSS Filtering completed
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:09:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:57 --> Language Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Loader Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:09:57 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/72299799e7be2698f2763d20cbe6582e
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:09:57 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Total execution time: 2.1157
DEBUG - 2016-09-05 03:09:57 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:09:57 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:09:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:09:57 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: crypto_helper
ERROR - 2016-09-05 03:09:57 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/10f18dab9dad5a443779bd2325894a0c
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:09:57 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:57 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Total execution time: 2.1444
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:57 --> Session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:09:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:57 --> Session routines successfully run
DEBUG - 2016-09-05 03:09:57 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:57 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
ERROR - 2016-09-05 03:09:58 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b69a0d6fb1177b7d8e2df256265692d6
DEBUG - 2016-09-05 03:09:58 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:58 --> Total execution time: 2.1362
DEBUG - 2016-09-05 03:09:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:58 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:58 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
ERROR - 2016-09-05 03:09:58 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a18ef52a5acab6505e709ea5839991a9
DEBUG - 2016-09-05 03:09:58 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:58 --> Total execution time: 2.1409
DEBUG - 2016-09-05 03:09:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:58 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:58 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
ERROR - 2016-09-05 03:09:58 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/40c1006990c613844d744bffb3779912
DEBUG - 2016-09-05 03:09:58 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:58 --> Total execution time: 2.1786
DEBUG - 2016-09-05 03:09:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:09:59 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:09:59 --> Controller Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:09:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:09:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:09:59 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:59 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:09:59 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
ERROR - 2016-09-05 03:09:59 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:09:59 --> Model Class Initialized
DEBUG - 2016-09-05 03:09:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:09:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:09:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cabc5d4df53e8b71459ea1d83d04b09b
DEBUG - 2016-09-05 03:09:59 --> Final output sent to browser
DEBUG - 2016-09-05 03:09:59 --> Total execution time: 2.1978
DEBUG - 2016-09-05 03:10:42 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:42 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:42 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:42 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:42 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:42 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:42 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:42 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:42 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:43 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:43 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:43 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:43 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:43 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:43 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:43 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:43 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:43 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
ERROR - 2016-09-05 03:10:43 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:10:43 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:43 --> Total execution time: 1.1868
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:44 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
ERROR - 2016-09-05 03:10:45 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:10:45 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:45 --> Total execution time: 1.3735
DEBUG - 2016-09-05 03:10:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:45 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:45 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:45 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:45 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:45 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:45 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:10:45 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:45 --> Total execution time: 1.8333
DEBUG - 2016-09-05 03:10:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:45 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:45 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:45 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:45 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:45 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:45 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:45 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:46 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:10:46 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Total execution time: 2.2707
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:46 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:46 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:46 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:46 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:46 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:46 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:10:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:10:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Total execution time: 2.6825
DEBUG - 2016-09-05 03:10:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:46 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:46 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:46 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:46 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:46 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:46 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:46 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:46 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:10:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:10:47 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:47 --> Total execution time: 3.1283
DEBUG - 2016-09-05 03:10:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:47 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:47 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:47 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:47 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:47 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:47 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:47 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:10:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:47 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Total execution time: 3.5583
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:47 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:47 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:47 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:47 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:47 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:47 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:47 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:47 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:47 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:47 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:47 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: crypto_helper
ERROR - 2016-09-05 03:10:47 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:10:47 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:47 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:47 --> Total execution time: 2.5288
DEBUG - 2016-09-05 03:10:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:48 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:48 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:48 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:48 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:48 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:48 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: crypto_helper
ERROR - 2016-09-05 03:10:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:10:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:48 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Total execution time: 2.5088
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:48 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:48 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:48 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:48 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:48 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:48 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:48 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:48 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:48 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:48 --> Total execution time: 2.5347
DEBUG - 2016-09-05 03:10:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:48 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:48 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:48 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:48 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:49 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:49 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:49 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:49 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:10:49 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:49 --> Total execution time: 2.5412
DEBUG - 2016-09-05 03:10:49 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:49 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:49 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:49 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:49 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:49 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:49 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:49 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:10:49 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:49 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:10:49 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:49 --> Total execution time: 2.5908
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:49 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:49 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:49 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:49 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:49 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:49 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:50 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:50 --> Total execution time: 2.6384
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:50 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:50 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:50 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:50 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:50 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:10:50 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:50 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Total execution time: 2.6662
DEBUG - 2016-09-05 03:10:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:50 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:50 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:50 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:50 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:50 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:50 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:50 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Check Exists sidika_helper.php: No
ERROR - 2016-09-05 03:10:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:51 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Total execution time: 2.7399
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:51 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:51 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:51 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:51 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:51 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:51 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:51 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:10:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/2d461f2b02f602c1e15bf7847b419b66
DEBUG - 2016-09-05 03:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:51 --> Total execution time: 2.8193
DEBUG - 2016-09-05 03:10:51 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:51 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:51 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:51 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:51 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:51 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:51 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:51 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:51 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:52 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:52 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:52 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:52 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:10:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d612482e4e77821b617e68f9033e8910
DEBUG - 2016-09-05 03:10:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:52 --> Total execution time: 2.8544
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Config Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:10:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:52 --> URI Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Router Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:52 --> Output Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:10:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Security Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:52 --> Input Class Initialized
DEBUG - 2016-09-05 03:10:52 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> XSS Filtering completed
DEBUG - 2016-09-05 03:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Language Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Loader Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:10:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:10:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:10:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/72299799e7be2698f2763d20cbe6582e
DEBUG - 2016-09-05 03:10:52 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:10:52 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:52 --> Total execution time: 2.8788
DEBUG - 2016-09-05 03:10:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:52 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:10:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:10:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:10:52 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:52 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:10:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:10:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:10:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists sidika_helper.php: No
ERROR - 2016-09-05 03:10:53 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:10:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:53 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/10f18dab9dad5a443779bd2325894a0c
DEBUG - 2016-09-05 03:10:53 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:53 --> Total execution time: 2.9262
DEBUG - 2016-09-05 03:10:53 --> Session Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:10:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:53 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:10:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Session routines successfully run
DEBUG - 2016-09-05 03:10:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:53 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:53 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:53 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
ERROR - 2016-09-05 03:10:53 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:53 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b69a0d6fb1177b7d8e2df256265692d6
DEBUG - 2016-09-05 03:10:53 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:53 --> Total execution time: 2.9414
DEBUG - 2016-09-05 03:10:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:53 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:54 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
ERROR - 2016-09-05 03:10:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a18ef52a5acab6505e709ea5839991a9
DEBUG - 2016-09-05 03:10:54 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:54 --> Total execution time: 2.9681
DEBUG - 2016-09-05 03:10:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:54 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:54 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
ERROR - 2016-09-05 03:10:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:54 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/40c1006990c613844d744bffb3779912
DEBUG - 2016-09-05 03:10:54 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:54 --> Total execution time: 2.9703
DEBUG - 2016-09-05 03:10:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:10:55 --> Controller Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:10:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:10:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:10:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:55 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:10:55 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
ERROR - 2016-09-05 03:10:55 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:10:55 --> Model Class Initialized
DEBUG - 2016-09-05 03:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:10:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cabc5d4df53e8b71459ea1d83d04b09b
DEBUG - 2016-09-05 03:10:55 --> Final output sent to browser
DEBUG - 2016-09-05 03:10:55 --> Total execution time: 2.9947
DEBUG - 2016-09-05 03:12:17 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:17 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:17 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:17 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:17 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:17 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:17 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:17 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:17 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:17 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:18 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:18 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:18 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:18 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:18 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:18 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
ERROR - 2016-09-05 03:12:18 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:12:19 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:19 --> Total execution time: 1.5476
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:20 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:20 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:20 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
ERROR - 2016-09-05 03:12:20 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:12:20 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:20 --> Total execution time: 1.6078
DEBUG - 2016-09-05 03:12:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:20 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:21 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:21 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Global POST and COOKIE data sanitized
ERROR - 2016-09-05 03:12:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:12:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:21 --> Total execution time: 2.1579
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:21 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:12:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:21 --> Total execution time: 2.7086
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:22 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Check Exists url_helper.php: Yes
ERROR - 2016-09-05 03:12:22 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:12:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:22 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Total execution time: 3.2615
DEBUG - 2016-09-05 03:12:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:22 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:22 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:12:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:23 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:23 --> Total execution time: 3.7100
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:23 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:23 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:23 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:23 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:23 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Check Exists url_helper.php: Yes
ERROR - 2016-09-05 03:12:23 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:12:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:23 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Total execution time: 4.3359
DEBUG - 2016-09-05 03:12:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:23 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:23 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:23 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:23 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:23 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:23 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:23 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Check Exists url_helper.php: Yes
ERROR - 2016-09-05 03:12:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:24 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:24 --> Total execution time: 3.1870
DEBUG - 2016-09-05 03:12:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:24 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:24 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:24 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:24 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:24 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:24 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:24 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
ERROR - 2016-09-05 03:12:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:12:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:24 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Total execution time: 3.3256
DEBUG - 2016-09-05 03:12:24 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:24 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:25 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:25 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:25 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:25 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:25 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:12:25 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:25 --> Total execution time: 3.3329
DEBUG - 2016-09-05 03:12:25 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:25 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:25 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:25 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:25 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:25 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:25 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:25 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:12:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:12:26 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:26 --> Total execution time: 3.4186
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:26 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:26 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:26 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:26 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:26 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:26 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:26 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/72299799e7be2698f2763d20cbe6582e
DEBUG - 2016-09-05 03:12:26 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:26 --> Total execution time: 3.3925
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:26 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:26 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:26 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:26 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:26 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:27 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/40c1006990c613844d744bffb3779912
DEBUG - 2016-09-05 03:12:27 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:27 --> Total execution time: 3.4069
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:27 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:27 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:27 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:27 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:27 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:27 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:27 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a18ef52a5acab6505e709ea5839991a9
DEBUG - 2016-09-05 03:12:27 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:27 --> Total execution time: 3.4582
DEBUG - 2016-09-05 03:12:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:27 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:28 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:28 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:28 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:28 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:28 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:28 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:12:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:28 --> Total execution time: 3.4831
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:28 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:28 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:28 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:28 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:28 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:28 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:28 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:28 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:28 --> Helper loaded: url_helper
ERROR - 2016-09-05 03:12:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:29 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/2d461f2b02f602c1e15bf7847b419b66
DEBUG - 2016-09-05 03:12:29 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Total execution time: 3.5252
DEBUG - 2016-09-05 03:12:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:29 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:29 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:29 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:29 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:29 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:29 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:29 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:29 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:29 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:29 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:29 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d612482e4e77821b617e68f9033e8910
DEBUG - 2016-09-05 03:12:29 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:29 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Total execution time: 3.5881
DEBUG - 2016-09-05 03:12:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:29 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:29 --> Config Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:12:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:29 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:29 --> URI Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:29 --> Router Class Initialized
DEBUG - 2016-09-05 03:12:29 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:29 --> Output Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:12:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:30 --> Security Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:30 --> Input Class Initialized
DEBUG - 2016-09-05 03:12:30 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> XSS Filtering completed
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Language Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Loader Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:12:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:12:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b69a0d6fb1177b7d8e2df256265692d6
DEBUG - 2016-09-05 03:12:30 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Total execution time: 3.6126
DEBUG - 2016-09-05 03:12:30 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:12:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:12:30 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:12:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:12:30 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> Helper loaded: crypto_helper
ERROR - 2016-09-05 03:12:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:12:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:12:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:12:31 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:12:31 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:31 --> Total execution time: 3.6273
DEBUG - 2016-09-05 03:12:31 --> Session Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:12:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:12:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Session routines successfully run
DEBUG - 2016-09-05 03:12:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:31 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:31 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:31 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:31 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
ERROR - 2016-09-05 03:12:31 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cabc5d4df53e8b71459ea1d83d04b09b
DEBUG - 2016-09-05 03:12:31 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:31 --> Total execution time: 3.6796
DEBUG - 2016-09-05 03:12:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:31 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:31 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:32 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
ERROR - 2016-09-05 03:12:32 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:12:32 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:32 --> Total execution time: 3.7123
DEBUG - 2016-09-05 03:12:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:32 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:32 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
ERROR - 2016-09-05 03:12:32 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/10f18dab9dad5a443779bd2325894a0c
DEBUG - 2016-09-05 03:12:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:33 --> Total execution time: 3.7291
DEBUG - 2016-09-05 03:12:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:12:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:12:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:12:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:12:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:12:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:12:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
ERROR - 2016-09-05 03:12:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:12:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:12:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:12:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:12:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:12:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:12:33 --> Total execution time: 3.7562
DEBUG - 2016-09-05 03:15:41 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:41 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:41 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:41 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:41 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:41 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:41 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:42 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:42 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:42 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:42 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:42 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:42 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:42 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:42 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:42 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:42 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Model Class Initialized
ERROR - 2016-09-05 03:15:43 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:43 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:15:43 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:43 --> Total execution time: 1.9635
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Output Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Security Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> Input Class Initialized
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> XSS Filtering completed
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Language Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Loader Class Initialized
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:15:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:15:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Session routines successfully run
DEBUG - 2016-09-05 03:15:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:45 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
ERROR - 2016-09-05 03:15:45 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:15:45 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:45 --> Total execution time: 2.0090
DEBUG - 2016-09-05 03:15:45 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:45 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:45 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Carabiner: Library initialized.
ERROR - 2016-09-05 03:15:45 --> 404 Page Not Found --> front_end
DEBUG - 2016-09-05 03:15:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:45 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:45 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:45 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:45 --> Model Class Initialized
ERROR - 2016-09-05 03:15:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:46 --> Router Class Initialized
ERROR - 2016-09-05 03:15:46 --> 404 Page Not Found --> img
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:46 --> Config Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:46 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:15:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:15:46 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:46 --> URI Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Total execution time: 2.7226
DEBUG - 2016-09-05 03:15:46 --> Router Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Class Library loaded: LWS_Session on session
ERROR - 2016-09-05 03:15:46 --> 404 Page Not Found --> front_end/favicon.ico
DEBUG - 2016-09-05 03:15:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:46 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:46 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:46 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
ERROR - 2016-09-05 03:15:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:46 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:15:46 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:46 --> Total execution time: 3.4153
DEBUG - 2016-09-05 03:15:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:47 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:47 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
ERROR - 2016-09-05 03:15:47 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:15:47 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:47 --> Total execution time: 4.1205
DEBUG - 2016-09-05 03:15:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:47 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:47 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
ERROR - 2016-09-05 03:15:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:15:48 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:48 --> Total execution time: 4.8344
DEBUG - 2016-09-05 03:15:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:15:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:15:48 --> Controller Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:15:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:15:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:15:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:15:48 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
ERROR - 2016-09-05 03:15:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:15:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:15:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:15:48 --> Final output sent to browser
DEBUG - 2016-09-05 03:15:49 --> Total execution time: 5.5449
DEBUG - 2016-09-05 03:16:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:20 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:20 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:20 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:20 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:20 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:20 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:21 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:21 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:21 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:21 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:21 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:21 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:21 --> Model Class Initialized
ERROR - 2016-09-05 03:16:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:22 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:16:22 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:22 --> Total execution time: 2.0738
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:22 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:23 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:24 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
ERROR - 2016-09-05 03:16:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b95eda515cf961daac2dde7dd8e18c7c
DEBUG - 2016-09-05 03:16:24 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:24 --> Total execution time: 2.0818
DEBUG - 2016-09-05 03:16:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:24 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:24 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:24 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:24 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:24 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:24 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:16:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/50066ace4d8278a73baae4cc0e54b531
DEBUG - 2016-09-05 03:16:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:25 --> Total execution time: 2.8195
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:25 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:25 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:25 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:25 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:16:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/439afa2b84c85ae972a3f9deac1c951f
DEBUG - 2016-09-05 03:16:25 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:25 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Total execution time: 3.5398
DEBUG - 2016-09-05 03:16:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:25 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:26 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:26 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:26 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
ERROR - 2016-09-05 03:16:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6c166029fa05c18d19d077c7bb18bf74
DEBUG - 2016-09-05 03:16:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:26 --> Total execution time: 4.2602
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:26 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:26 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:26 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:26 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:26 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:26 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:26 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:27 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:16:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0e8b31adaf68ea18d380f40e99a46c6f
DEBUG - 2016-09-05 03:16:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:27 --> Total execution time: 4.9825
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:27 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:27 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:27 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:27 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:27 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:27 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:27 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:16:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ec5e2e5665c2e9783e6dd9bb3215327b
DEBUG - 2016-09-05 03:16:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:28 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Total execution time: 5.7147
DEBUG - 2016-09-05 03:16:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:28 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:28 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:28 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:28 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:28 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:16:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/72299799e7be2698f2763d20cbe6582e
DEBUG - 2016-09-05 03:16:28 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:28 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Total execution time: 4.1748
DEBUG - 2016-09-05 03:16:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:28 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:28 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:29 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:29 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:29 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:29 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:29 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:16:29 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a18ef52a5acab6505e709ea5839991a9
DEBUG - 2016-09-05 03:16:29 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:29 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Total execution time: 4.2070
DEBUG - 2016-09-05 03:16:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:29 --> Config Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:29 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:29 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:16:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> URI Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Router Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:29 --> Output Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:16:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:29 --> Security Class Initialized
DEBUG - 2016-09-05 03:16:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:29 --> Input Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:30 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> XSS Filtering completed
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Language Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:30 --> Loader Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:16:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/2d461f2b02f602c1e15bf7847b419b66
DEBUG - 2016-09-05 03:16:30 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:30 --> Total execution time: 4.3250
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:30 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:16:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:16:30 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:16:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:16:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:16:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:16:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:16:31 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:31 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d612482e4e77821b617e68f9033e8910
DEBUG - 2016-09-05 03:16:31 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:31 --> Session Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:16:31 --> Total execution time: 4.3640
DEBUG - 2016-09-05 03:16:31 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:16:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:31 --> Session routines successfully run
DEBUG - 2016-09-05 03:16:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:31 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:31 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:31 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:31 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
ERROR - 2016-09-05 03:16:31 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b69a0d6fb1177b7d8e2df256265692d6
DEBUG - 2016-09-05 03:16:32 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:32 --> Total execution time: 4.4759
DEBUG - 2016-09-05 03:16:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:32 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:32 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:32 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
ERROR - 2016-09-05 03:16:32 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:32 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cabc5d4df53e8b71459ea1d83d04b09b
DEBUG - 2016-09-05 03:16:32 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:32 --> Total execution time: 4.5324
DEBUG - 2016-09-05 03:16:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:32 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
ERROR - 2016-09-05 03:16:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/10f18dab9dad5a443779bd2325894a0c
DEBUG - 2016-09-05 03:16:33 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:33 --> Total execution time: 4.5790
DEBUG - 2016-09-05 03:16:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:16:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:16:33 --> Controller Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:16:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:16:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:16:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:33 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:16:33 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:16:33 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
ERROR - 2016-09-05 03:16:34 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:16:34 --> Model Class Initialized
DEBUG - 2016-09-05 03:16:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:16:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:16:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/40c1006990c613844d744bffb3779912
DEBUG - 2016-09-05 03:16:34 --> Final output sent to browser
DEBUG - 2016-09-05 03:16:34 --> Total execution time: 4.5957
DEBUG - 2016-09-05 03:19:08 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:08 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:08 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:08 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:08 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:08 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:09 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:09 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:09 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:09 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:09 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:09 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:10 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:10 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:10 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:10 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:10 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:10 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:10 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:10 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:10 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:10 --> Model Class Initialized
ERROR - 2016-09-05 03:19:10 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:11 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:19:11 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:11 --> Total execution time: 2.2983
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:13 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:13 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
ERROR - 2016-09-05 03:19:13 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:19:13 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:13 --> Total execution time: 2.2861
DEBUG - 2016-09-05 03:19:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:13 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:13 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:13 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:13 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:14 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:14 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:14 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:19:14 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:19:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:14 --> Total execution time: 3.0889
DEBUG - 2016-09-05 03:19:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:14 --> Config Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:14 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:19:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:14 --> URI Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:14 --> Router Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:14 --> Output Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:19:14 --> Security Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:14 --> Input Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:14 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> XSS Filtering completed
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:19:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Language Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:14 --> Loader Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:19:15 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:19:15 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:15 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Total execution time: 3.8971
DEBUG - 2016-09-05 03:19:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:19:15 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:19:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists crypto_helper.php: No
ERROR - 2016-09-05 03:19:15 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:19:16 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:16 --> Session Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Total execution time: 4.6763
DEBUG - 2016-09-05 03:19:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:19:16 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:19:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:16 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Session routines successfully run
DEBUG - 2016-09-05 03:19:16 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:16 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:16 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:16 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:16 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
ERROR - 2016-09-05 03:19:16 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:16 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:19:16 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:16 --> Total execution time: 5.5265
DEBUG - 2016-09-05 03:19:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:17 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:17 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
ERROR - 2016-09-05 03:19:17 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:19:17 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:17 --> Total execution time: 6.3531
DEBUG - 2016-09-05 03:19:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:17 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:18 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
ERROR - 2016-09-05 03:19:18 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:19:18 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:18 --> Total execution time: 4.6923
DEBUG - 2016-09-05 03:19:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:19:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:19:18 --> Controller Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:19:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:19:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:19:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:19:18 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:19:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
ERROR - 2016-09-05 03:19:19 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:19:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:19:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:19:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:19:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:19:19 --> Final output sent to browser
DEBUG - 2016-09-05 03:19:19 --> Total execution time: 4.7184
DEBUG - 2016-09-05 03:28:18 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:18 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:18 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:18 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:18 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:18 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:18 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:18 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:19 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:19 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:19 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:19 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:20 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:20 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:20 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:20 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:20 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
ERROR - 2016-09-05 03:28:20 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:20 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:28:20 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:20 --> Total execution time: 2.4575
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:20 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:22 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:22 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:23 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:23 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
ERROR - 2016-09-05 03:28:23 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:23 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:28:23 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:23 --> Total execution time: 2.5215
DEBUG - 2016-09-05 03:28:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:23 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:23 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:23 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:24 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:24 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:24 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:24 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
ERROR - 2016-09-05 03:28:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:24 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Total execution time: 3.4485
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:24 --> Config Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:24 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:28:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:24 --> URI Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:24 --> Router Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:24 --> Output Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> Security Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:24 --> Input Class Initialized
DEBUG - 2016-09-05 03:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Language Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Loader Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:28:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:28:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:25 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:28:25 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:28:25 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:25 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Total execution time: 4.3575
DEBUG - 2016-09-05 03:28:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:28:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:28:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:28:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:28:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:28:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:28:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:28:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:26 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:26 --> Session Class Initialized
DEBUG - 2016-09-05 03:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:26 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:28:26 --> Session routines successfully run
DEBUG - 2016-09-05 03:28:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:28:26 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:26 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Total execution time: 5.3033
DEBUG - 2016-09-05 03:28:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
ERROR - 2016-09-05 03:28:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:28:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:27 --> Total execution time: 6.2726
DEBUG - 2016-09-05 03:28:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:27 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:27 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
ERROR - 2016-09-05 03:28:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:28:28 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:28 --> Total execution time: 7.2466
DEBUG - 2016-09-05 03:28:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:28 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:28 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
ERROR - 2016-09-05 03:28:29 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:28:29 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:29 --> Total execution time: 5.4023
DEBUG - 2016-09-05 03:28:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:28:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:28:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:28:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:28:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:28:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:28:29 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:30 --> Model Class Initialized
ERROR - 2016-09-05 03:28:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:28:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:28:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:28:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:28:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:28:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:28:30 --> Final output sent to browser
DEBUG - 2016-09-05 03:28:30 --> Total execution time: 5.4507
DEBUG - 2016-09-05 03:29:55 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:55 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:55 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:55 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:55 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:29:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:29:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:29:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:29:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:29:57 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Session Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:29:57 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:29:57 --> Session routines successfully run
DEBUG - 2016-09-05 03:29:57 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:29:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:29:57 --> Controller Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:29:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:29:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:29:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:29:57 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:29:57 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:57 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Model Class Initialized
ERROR - 2016-09-05 03:29:58 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:29:58 --> Model Class Initialized
DEBUG - 2016-09-05 03:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:29:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:29:58 --> Final output sent to browser
DEBUG - 2016-09-05 03:29:58 --> Total execution time: 2.6822
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> URI Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Router Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Output Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Security Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Input Class Initialized
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> XSS Filtering completed
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Language Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Loader Class Initialized
DEBUG - 2016-09-05 03:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:29:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:29:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:00 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:00 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:00 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:00 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:00 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
ERROR - 2016-09-05 03:30:00 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:00 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:30:01 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:01 --> Total execution time: 2.5767
DEBUG - 2016-09-05 03:30:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:01 --> Config Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:30:01 --> URI Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Router Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:01 --> Output Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:30:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:01 --> Security Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:01 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:01 --> Input Class Initialized
DEBUG - 2016-09-05 03:30:01 --> XSS Filtering completed
DEBUG - 2016-09-05 03:30:01 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:01 --> XSS Filtering completed
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Language Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Loader Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:30:01 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:01 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:01 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:30:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:30:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:30:02 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Total execution time: 3.5142
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:30:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:02 --> Config Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:30:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:30:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:30:02 --> URI Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Router Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:02 --> Output Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:30:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:02 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:30:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:02 --> Security Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Input Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:02 --> XSS Filtering completed
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:02 --> XSS Filtering completed
DEBUG - 2016-09-05 03:30:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Language Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Loader Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:30:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:30:02 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:02 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:30:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:02 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:30:02 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:03 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:30:03 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:03 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:30:03 --> Total execution time: 4.4666
DEBUG - 2016-09-05 03:30:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:30:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:30:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:30:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:30:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:30:03 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:03 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:30:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:30:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:03 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:30:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:03 --> Session Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:04 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:30:04 --> Session routines successfully run
DEBUG - 2016-09-05 03:30:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:30:04 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:04 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Total execution time: 5.4579
DEBUG - 2016-09-05 03:30:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:04 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:04 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:04 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:04 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:04 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
ERROR - 2016-09-05 03:30:04 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:04 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bbbd166bab9c8f0c7c4b3c6180e520e2
DEBUG - 2016-09-05 03:30:05 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:05 --> Total execution time: 6.4375
DEBUG - 2016-09-05 03:30:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:05 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:05 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:05 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:05 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:05 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
ERROR - 2016-09-05 03:30:05 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:05 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:30:06 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:06 --> Total execution time: 7.3961
DEBUG - 2016-09-05 03:30:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:06 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:06 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:06 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:06 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:06 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
ERROR - 2016-09-05 03:30:06 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:06 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:30:07 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:07 --> Total execution time: 5.5333
DEBUG - 2016-09-05 03:30:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:30:07 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:30:07 --> Controller Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:30:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:30:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:30:07 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:07 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:30:07 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
ERROR - 2016-09-05 03:30:07 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:30:07 --> Model Class Initialized
DEBUG - 2016-09-05 03:30:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:30:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:30:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:30:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:30:08 --> Final output sent to browser
DEBUG - 2016-09-05 03:30:08 --> Total execution time: 5.5980
DEBUG - 2016-09-05 03:31:19 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:19 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:19 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:19 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:19 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:19 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:19 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:20 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:20 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:20 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:21 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:21 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:21 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:21 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:21 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
ERROR - 2016-09-05 03:31:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:21 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:31:22 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:22 --> Total execution time: 2.7549
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:23 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:24 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:24 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:24 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
ERROR - 2016-09-05 03:31:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:24 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/58d9105dc9852668aeaad855d2b18a37
DEBUG - 2016-09-05 03:31:25 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:25 --> Total execution time: 2.7835
DEBUG - 2016-09-05 03:31:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:25 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:25 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:25 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:25 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:25 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:25 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:25 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:25 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists file_helper.php: Yes
ERROR - 2016-09-05 03:31:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4df7d65d31a37919f241527c7a39b933
DEBUG - 2016-09-05 03:31:26 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:26 --> Total execution time: 3.9316
DEBUG - 2016-09-05 03:31:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:26 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Check Exists LWS_sidika_helper.php: No
ERROR - 2016-09-05 03:31:27 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:27 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:27 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/78d05d9105a832659496aa5ac427c180
DEBUG - 2016-09-05 03:31:27 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:27 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Total execution time: 4.9790
DEBUG - 2016-09-05 03:31:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:27 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:27 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:27 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:27 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
ERROR - 2016-09-05 03:31:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55c415864c2a480de59b70a367e58847
DEBUG - 2016-09-05 03:31:28 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:28 --> Total execution time: 6.0079
DEBUG - 2016-09-05 03:31:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:28 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:28 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:28 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:28 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
ERROR - 2016-09-05 03:31:29 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/db4f3d1831c3c5e71259cde517e1524d
DEBUG - 2016-09-05 03:31:29 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:29 --> Total execution time: 7.0105
DEBUG - 2016-09-05 03:31:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:29 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:29 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:29 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:29 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
ERROR - 2016-09-05 03:31:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/155e2e6dfe4c3ac0abd9f20f1e20ad8a
DEBUG - 2016-09-05 03:31:30 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:30 --> Total execution time: 8.0576
DEBUG - 2016-09-05 03:31:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:30 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:30 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:30 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:30 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:31 --> Model Class Initialized
ERROR - 2016-09-05 03:31:31 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:31 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cdd06881602187e3c5004ecc4b6d4a4c
DEBUG - 2016-09-05 03:31:31 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:31 --> Total execution time: 6.0329
DEBUG - 2016-09-05 03:31:45 --> Config Class Initialized
DEBUG - 2016-09-05 03:31:45 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:31:45 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:31:45 --> URI Class Initialized
DEBUG - 2016-09-05 03:31:45 --> Router Class Initialized
DEBUG - 2016-09-05 03:31:45 --> Output Class Initialized
DEBUG - 2016-09-05 03:31:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:31:46 --> Security Class Initialized
DEBUG - 2016-09-05 03:31:46 --> Input Class Initialized
DEBUG - 2016-09-05 03:31:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:46 --> XSS Filtering completed
DEBUG - 2016-09-05 03:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:31:46 --> Language Class Initialized
DEBUG - 2016-09-05 03:31:46 --> Loader Class Initialized
DEBUG - 2016-09-05 03:31:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:31:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:31:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:31:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:31:46 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:31:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:31:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:31:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:31:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:31:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:31:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:31:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:31:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:31:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:31:47 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Session Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:31:47 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:31:47 --> Session routines successfully run
DEBUG - 2016-09-05 03:31:47 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:31:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:31:47 --> Controller Class Initialized
DEBUG - 2016-09-05 03:31:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:31:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:31:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:31:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:48 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:31:48 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
ERROR - 2016-09-05 03:31:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:31:48 --> Model Class Initialized
DEBUG - 2016-09-05 03:31:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:31:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:31:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:31:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:31:48 --> Final output sent to browser
DEBUG - 2016-09-05 03:31:48 --> Total execution time: 2.8605
DEBUG - 2016-09-05 03:32:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:32:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:32:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:32:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:32:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:32:12 --> XSS Filtering completed
DEBUG - 2016-09-05 03:32:12 --> XSS Filtering completed
DEBUG - 2016-09-05 03:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:32:12 --> Language Class Initialized
DEBUG - 2016-09-05 03:32:12 --> Loader Class Initialized
DEBUG - 2016-09-05 03:32:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:32:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:32:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:32:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:32:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:32:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:32:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:32:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:32:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:32:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:32:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:32:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:32:13 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Session Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:32:13 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:32:13 --> Session routines successfully run
DEBUG - 2016-09-05 03:32:13 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:32:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:32:13 --> Controller Class Initialized
DEBUG - 2016-09-05 03:32:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:32:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:32:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:32:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:32:14 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:32:14 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
ERROR - 2016-09-05 03:32:14 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:32:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:32:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:32:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:32:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:32:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:32:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:32:14 --> Final output sent to browser
DEBUG - 2016-09-05 03:32:14 --> Total execution time: 2.8756
DEBUG - 2016-09-05 03:32:53 --> Config Class Initialized
DEBUG - 2016-09-05 03:32:53 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:32:53 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:32:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:32:54 --> URI Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Router Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Output Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:32:54 --> Security Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Input Class Initialized
DEBUG - 2016-09-05 03:32:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:32:54 --> XSS Filtering completed
DEBUG - 2016-09-05 03:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:32:54 --> Language Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Loader Class Initialized
DEBUG - 2016-09-05 03:32:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:32:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:32:54 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:32:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:32:54 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:32:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:32:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:32:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:32:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:32:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:32:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:32:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:32:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:32:54 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:32:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:32:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:32:55 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:32:55 --> Session Class Initialized
DEBUG - 2016-09-05 03:32:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:32:55 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:32:55 --> Session routines successfully run
DEBUG - 2016-09-05 03:32:55 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:32:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:32:56 --> Controller Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:32:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:32:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:32:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:32:56 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:32:56 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
ERROR - 2016-09-05 03:32:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:32:56 --> Model Class Initialized
DEBUG - 2016-09-05 03:32:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:32:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:32:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:32:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:32:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:32:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:32:57 --> Final output sent to browser
DEBUG - 2016-09-05 03:32:57 --> Total execution time: 2.9140
DEBUG - 2016-09-05 03:33:10 --> Config Class Initialized
DEBUG - 2016-09-05 03:33:10 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:33:10 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:33:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:33:10 --> URI Class Initialized
DEBUG - 2016-09-05 03:33:10 --> Router Class Initialized
DEBUG - 2016-09-05 03:33:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:33:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:33:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:33:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:33:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:33:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:33:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:33:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:33:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:33:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:33:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:33:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:33:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:33:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:33:11 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:33:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:33:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:33:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:33:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:33:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:33:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:33:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:33:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:33:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:33:12 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:33:12 --> Session Class Initialized
DEBUG - 2016-09-05 03:33:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:33:12 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:33:12 --> Session routines successfully run
DEBUG - 2016-09-05 03:33:12 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:33:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:33:12 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:33:12 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:33:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:33:13 --> Controller Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:33:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:33:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:33:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:33:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:33:13 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
ERROR - 2016-09-05 03:33:13 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:33:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:33:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:33:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:33:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:33:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:33:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:33:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:33:13 --> Final output sent to browser
DEBUG - 2016-09-05 03:33:13 --> Total execution time: 2.8918
DEBUG - 2016-09-05 03:34:44 --> Config Class Initialized
DEBUG - 2016-09-05 03:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:34:44 --> URI Class Initialized
DEBUG - 2016-09-05 03:34:44 --> Router Class Initialized
DEBUG - 2016-09-05 03:34:44 --> Output Class Initialized
DEBUG - 2016-09-05 03:34:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:34:44 --> Security Class Initialized
DEBUG - 2016-09-05 03:34:45 --> Input Class Initialized
DEBUG - 2016-09-05 03:34:45 --> XSS Filtering completed
DEBUG - 2016-09-05 03:34:45 --> XSS Filtering completed
DEBUG - 2016-09-05 03:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:34:45 --> Language Class Initialized
DEBUG - 2016-09-05 03:34:45 --> Loader Class Initialized
DEBUG - 2016-09-05 03:34:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:34:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:34:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:34:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:34:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:34:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:34:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:34:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:34:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:34:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:34:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:34:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:34:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:34:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:34:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:34:46 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Session Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:34:46 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:34:46 --> Session routines successfully run
DEBUG - 2016-09-05 03:34:46 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:34:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:34:46 --> Controller Class Initialized
DEBUG - 2016-09-05 03:34:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:34:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:34:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:34:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:34:47 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:34:47 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
ERROR - 2016-09-05 03:34:47 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:34:47 --> Model Class Initialized
DEBUG - 2016-09-05 03:34:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:34:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:34:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:34:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:34:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:34:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:34:47 --> Final output sent to browser
DEBUG - 2016-09-05 03:34:47 --> Total execution time: 2.9107
DEBUG - 2016-09-05 03:40:16 --> Config Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:40:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:40:16 --> URI Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Router Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Output Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:40:16 --> Security Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Input Class Initialized
DEBUG - 2016-09-05 03:40:16 --> XSS Filtering completed
DEBUG - 2016-09-05 03:40:16 --> XSS Filtering completed
DEBUG - 2016-09-05 03:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:40:16 --> Language Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Loader Class Initialized
DEBUG - 2016-09-05 03:40:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:40:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:40:16 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:40:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:40:16 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:40:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:40:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:40:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:40:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:40:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:40:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:40:18 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Session Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:40:18 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:40:18 --> Session routines successfully run
DEBUG - 2016-09-05 03:40:18 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:40:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:40:18 --> Controller Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:40:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:40:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:40:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:40:18 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:40:18 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:18 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:19 --> Model Class Initialized
ERROR - 2016-09-05 03:40:19 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:40:19 --> Model Class Initialized
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:40:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:40:19 --> Final output sent to browser
DEBUG - 2016-09-05 03:40:19 --> Total execution time: 2.9574
DEBUG - 2016-09-05 03:43:11 --> Config Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:43:11 --> URI Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Router Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Output Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:43:11 --> Security Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Input Class Initialized
DEBUG - 2016-09-05 03:43:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:43:11 --> XSS Filtering completed
DEBUG - 2016-09-05 03:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:43:11 --> Language Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Loader Class Initialized
DEBUG - 2016-09-05 03:43:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:43:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:43:11 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:43:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:43:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:43:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:43:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:43:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:43:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:43:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:43:13 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Session Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:43:13 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:43:13 --> Session routines successfully run
DEBUG - 2016-09-05 03:43:13 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:43:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:43:13 --> Controller Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:43:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:43:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:43:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:43:13 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:43:13 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:13 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:14 --> Model Class Initialized
ERROR - 2016-09-05 03:43:14 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:43:14 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:43:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:43:14 --> Final output sent to browser
DEBUG - 2016-09-05 03:43:14 --> Total execution time: 2.8974
DEBUG - 2016-09-05 03:43:37 --> Config Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:43:37 --> URI Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Router Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Output Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:43:37 --> Security Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Input Class Initialized
DEBUG - 2016-09-05 03:43:37 --> XSS Filtering completed
DEBUG - 2016-09-05 03:43:37 --> XSS Filtering completed
DEBUG - 2016-09-05 03:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:43:37 --> Language Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Loader Class Initialized
DEBUG - 2016-09-05 03:43:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:43:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:43:37 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:43:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:43:37 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:43:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:43:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:43:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:43:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:43:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:43:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:43:39 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Session Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:43:39 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:43:39 --> Session routines successfully run
DEBUG - 2016-09-05 03:43:39 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:43:39 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:43:39 --> Controller Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:43:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:43:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:43:39 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:43:39 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:43:39 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:40 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:40 --> Model Class Initialized
ERROR - 2016-09-05 03:43:40 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:43:40 --> Model Class Initialized
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:43:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:43:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:43:40 --> Final output sent to browser
DEBUG - 2016-09-05 03:43:40 --> Total execution time: 3.0061
DEBUG - 2016-09-05 03:48:14 --> Config Class Initialized
DEBUG - 2016-09-05 03:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:48:15 --> URI Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Router Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Output Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:48:15 --> Security Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Input Class Initialized
DEBUG - 2016-09-05 03:48:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:48:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:48:15 --> Language Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Loader Class Initialized
DEBUG - 2016-09-05 03:48:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:48:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:48:15 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:48:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:48:15 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:48:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:48:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:48:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:48:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:48:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:48:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:48:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:48:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:48:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:48:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:48:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:48:16 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:48:16 --> Session Class Initialized
DEBUG - 2016-09-05 03:48:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:48:16 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:48:16 --> Session routines successfully run
DEBUG - 2016-09-05 03:48:17 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:48:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:48:17 --> Controller Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:48:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:48:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:48:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:48:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:48:17 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
ERROR - 2016-09-05 03:48:17 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:48:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:48:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:48:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:48:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:48:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:48:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:48:18 --> Final output sent to browser
DEBUG - 2016-09-05 03:48:18 --> Total execution time: 2.9863
DEBUG - 2016-09-05 03:51:47 --> Config Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:51:47 --> URI Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Router Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Output Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:51:47 --> Security Class Initialized
DEBUG - 2016-09-05 03:51:47 --> Input Class Initialized
DEBUG - 2016-09-05 03:51:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:51:47 --> XSS Filtering completed
DEBUG - 2016-09-05 03:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:51:48 --> Language Class Initialized
DEBUG - 2016-09-05 03:51:48 --> Loader Class Initialized
DEBUG - 2016-09-05 03:51:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:51:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:51:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:51:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:51:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:51:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:51:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:51:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:51:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:51:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:51:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:51:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:51:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:51:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:51:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:51:49 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Session Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:51:49 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:51:49 --> Session routines successfully run
DEBUG - 2016-09-05 03:51:49 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:51:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:51:49 --> Controller Class Initialized
DEBUG - 2016-09-05 03:51:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:51:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:51:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:51:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:51:49 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:51:50 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
ERROR - 2016-09-05 03:51:50 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:51:50 --> Model Class Initialized
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:51:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:51:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:51:50 --> Final output sent to browser
DEBUG - 2016-09-05 03:51:50 --> Total execution time: 2.9395
DEBUG - 2016-09-05 03:52:09 --> Config Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:52:09 --> URI Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Router Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Output Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:52:09 --> Security Class Initialized
DEBUG - 2016-09-05 03:52:09 --> Input Class Initialized
DEBUG - 2016-09-05 03:52:09 --> XSS Filtering completed
DEBUG - 2016-09-05 03:52:09 --> XSS Filtering completed
DEBUG - 2016-09-05 03:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:52:09 --> Language Class Initialized
DEBUG - 2016-09-05 03:52:10 --> Loader Class Initialized
DEBUG - 2016-09-05 03:52:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:52:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:52:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:52:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:52:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:52:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:52:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:52:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:52:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:52:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:52:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:52:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:52:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:52:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:52:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:52:11 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Session Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:52:11 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:52:11 --> Session routines successfully run
DEBUG - 2016-09-05 03:52:11 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:52:11 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:52:11 --> Controller Class Initialized
DEBUG - 2016-09-05 03:52:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:52:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:52:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:52:12 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:52:12 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:52:12 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
ERROR - 2016-09-05 03:52:12 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:52:12 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:14 --> Config Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:52:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:52:15 --> URI Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Router Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Output Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Security Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Input Class Initialized
DEBUG - 2016-09-05 03:52:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:52:15 --> XSS Filtering completed
DEBUG - 2016-09-05 03:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:52:15 --> Language Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Loader Class Initialized
DEBUG - 2016-09-05 03:52:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:52:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:52:15 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:52:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:52:15 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:52:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:52:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:52:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:52:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:52:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:52:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:52:15 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:52:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:52:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:52:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:52:16 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:52:16 --> Session Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:52:17 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:52:17 --> Session routines successfully run
DEBUG - 2016-09-05 03:52:17 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:52:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:52:17 --> Controller Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:52:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:52:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:52:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:52:17 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:52:17 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
ERROR - 2016-09-05 03:52:17 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:52:17 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:33 --> Config Class Initialized
DEBUG - 2016-09-05 03:58:33 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:58:33 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:58:33 --> URI Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Router Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Output Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Security Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Input Class Initialized
DEBUG - 2016-09-05 03:58:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:58:34 --> XSS Filtering completed
DEBUG - 2016-09-05 03:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:58:34 --> Language Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Loader Class Initialized
DEBUG - 2016-09-05 03:58:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:58:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:58:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:58:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:58:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:58:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:58:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:58:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:58:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:58:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:58:34 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:58:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:58:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:58:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:58:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:58:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:58:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:58:35 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:58:35 --> Session Class Initialized
DEBUG - 2016-09-05 03:58:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:58:35 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:58:35 --> Session routines successfully run
DEBUG - 2016-09-05 03:58:35 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:58:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:58:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:58:36 --> Controller Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:58:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:58:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:58:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:58:36 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:58:36 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
ERROR - 2016-09-05 03:58:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:58:36 --> Model Class Initialized
DEBUG - 2016-09-05 03:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:58:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:58:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:58:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:58:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:58:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:58:37 --> Final output sent to browser
DEBUG - 2016-09-05 03:58:37 --> Total execution time: 3.0123
DEBUG - 2016-09-05 03:59:23 --> Config Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:59:23 --> URI Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Router Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Output Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:59:23 --> Security Class Initialized
DEBUG - 2016-09-05 03:59:23 --> Input Class Initialized
DEBUG - 2016-09-05 03:59:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:59:24 --> XSS Filtering completed
DEBUG - 2016-09-05 03:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:59:24 --> Language Class Initialized
DEBUG - 2016-09-05 03:59:24 --> Loader Class Initialized
DEBUG - 2016-09-05 03:59:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:59:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:59:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:59:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:59:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:59:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:59:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:59:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:59:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:59:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:59:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:59:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:59:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:59:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:59:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:59:25 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:59:25 --> Session Class Initialized
DEBUG - 2016-09-05 03:59:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:59:25 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:59:25 --> Session routines successfully run
DEBUG - 2016-09-05 03:59:25 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:59:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:59:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:59:25 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:59:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:59:25 --> Controller Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:59:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:59:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:59:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:59:26 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:59:26 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
ERROR - 2016-09-05 03:59:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:59:26 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:59:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:59:27 --> Final output sent to browser
DEBUG - 2016-09-05 03:59:27 --> Total execution time: 3.0670
DEBUG - 2016-09-05 03:59:36 --> Config Class Initialized
DEBUG - 2016-09-05 03:59:36 --> Hooks Class Initialized
DEBUG - 2016-09-05 03:59:36 --> Utf8 Class Initialized
DEBUG - 2016-09-05 03:59:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-05 03:59:37 --> URI Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Router Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Output Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-05 03:59:37 --> Security Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Input Class Initialized
DEBUG - 2016-09-05 03:59:37 --> XSS Filtering completed
DEBUG - 2016-09-05 03:59:37 --> XSS Filtering completed
DEBUG - 2016-09-05 03:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-05 03:59:37 --> Language Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Loader Class Initialized
DEBUG - 2016-09-05 03:59:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-05 03:59:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-05 03:59:37 --> Helper loaded: url_helper
DEBUG - 2016-09-05 03:59:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-05 03:59:37 --> Helper loaded: file_helper
DEBUG - 2016-09-05 03:59:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:59:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-05 03:59:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-05 03:59:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-05 03:59:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-05 03:59:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-05 03:59:37 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:59:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: common_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: form_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: security_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-05 03:59:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-05 03:59:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-05 03:59:38 --> Database Driver Class Initialized
DEBUG - 2016-09-05 03:59:38 --> Session Class Initialized
DEBUG - 2016-09-05 03:59:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-05 03:59:38 --> Helper loaded: string_helper
DEBUG - 2016-09-05 03:59:39 --> Session routines successfully run
DEBUG - 2016-09-05 03:59:39 --> Native_session Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-05 03:59:39 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Form Validation Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-05 03:59:39 --> Controller Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-05 03:59:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-05 03:59:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-05 03:59:39 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:59:39 --> Carabiner: library configured.
DEBUG - 2016-09-05 03:59:39 --> User Agent Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
ERROR - 2016-09-05 03:59:39 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-05 03:59:39 --> Model Class Initialized
DEBUG - 2016-09-05 03:59:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-05 03:59:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:59:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-05 03:59:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-05 03:59:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-05 03:59:40 --> Final output sent to browser
DEBUG - 2016-09-05 03:59:40 --> Total execution time: 3.0879
