<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-23 09:53:49 --> Config Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:53:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:53:49 --> URI Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Router Class Initialized
DEBUG - 2016-09-23 09:53:49 --> No URI present. Default controller set.
DEBUG - 2016-09-23 09:53:49 --> Output Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:53:49 --> Security Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Input Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:53:49 --> Language Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Loader Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:53:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:53:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:53:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:53:49 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Session Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:53:49 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:53:49 --> A session cookie was not found.
DEBUG - 2016-09-23 09:53:49 --> Session routines successfully run
DEBUG - 2016-09-23 09:53:49 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:53:49 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:53:49 --> Controller Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:53:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:53:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:53:49 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:53:49 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:53:49 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:49 --> Model Class Initialized
ERROR - 2016-09-23 09:53:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:53:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:53:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-23 09:53:49 --> Final output sent to browser
DEBUG - 2016-09-23 09:53:49 --> Total execution time: 0.3695
DEBUG - 2016-09-23 09:53:52 --> Config Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:53:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:53:52 --> URI Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Router Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Output Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:53:52 --> Security Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Input Class Initialized
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:53:52 --> Language Class Initialized
DEBUG - 2016-09-23 09:53:52 --> Loader Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:53:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:53:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:53:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:53:53 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Session Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:53:53 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:53:53 --> Session routines successfully run
DEBUG - 2016-09-23 09:53:53 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:53:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:53:53 --> Controller Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:53:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:53:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:53:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:53:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:53:53 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:53:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-23 09:53:53 --> Final output sent to browser
DEBUG - 2016-09-23 09:53:53 --> Total execution time: 0.2640
DEBUG - 2016-09-23 09:57:27 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:27 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:27 --> No URI present. Default controller set.
DEBUG - 2016-09-23 09:57:27 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:27 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:27 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:27 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:27 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:27 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:27 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:27 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:27 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:27 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:27 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:27 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:27 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:27 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:27 --> Model Class Initialized
ERROR - 2016-09-23 09:57:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:57:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-23 09:57:27 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:27 --> Total execution time: 0.2484
DEBUG - 2016-09-23 09:57:28 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:28 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:28 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:28 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:28 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:28 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:28 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:28 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:28 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:28 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:28 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:28 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:28 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-23 09:57:28 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:28 --> Total execution time: 0.3035
DEBUG - 2016-09-23 09:57:30 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:30 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:30 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:30 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:30 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:30 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:30 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:31 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:31 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:31 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:31 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:31 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:31 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:31 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:31 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:31 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-23 09:57:31 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:31 --> Total execution time: 0.2699
DEBUG - 2016-09-23 09:57:33 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:33 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:33 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:33 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:33 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:34 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:34 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:34 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:34 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:34 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:34 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:34 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:34 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:34 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Model Class Initialized
ERROR - 2016-09-23 09:57:34 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-23 09:57:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-23 09:57:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-23 09:57:34 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:34 --> Total execution time: 0.3239
DEBUG - 2016-09-23 09:57:34 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:34 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:34 --> Router Class Initialized
ERROR - 2016-09-23 09:57:34 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-23 09:57:41 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:41 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:41 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:41 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:41 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:41 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:41 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:41 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:41 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:41 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:41 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:41 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Model Class Initialized
ERROR - 2016-09-23 09:57:41 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-23 09:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 09:57:41 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:41 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 09:57:41 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:41 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:41 --> No URI present. Default controller set.
DEBUG - 2016-09-23 09:57:41 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:41 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:41 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:42 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:42 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:42 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:42 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:42 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:42 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:42 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:42 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
ERROR - 2016-09-23 09:57:42 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-23 09:57:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-23 09:57:42 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:42 --> Total execution time: 0.3175
DEBUG - 2016-09-23 09:57:42 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:42 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:42 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:42 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:42 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:42 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:42 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:42 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:42 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:42 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:42 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:42 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:42 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-23 09:57:42 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:42 --> Total execution time: 0.3380
DEBUG - 2016-09-23 09:57:50 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:50 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:50 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:50 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:50 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:50 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:50 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:50 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:50 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:50 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:50 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:50 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:50 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:50 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:50 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:50 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-23 09:57:50 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:50 --> Total execution time: 0.3832
DEBUG - 2016-09-23 09:57:52 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:52 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:52 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:52 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:52 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:52 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:53 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:53 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:53 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:53 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:53 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 09:57:53 --> Pagination Class Initialized
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-23 09:57:53 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:53 --> Total execution time: 0.5390
DEBUG - 2016-09-23 09:57:55 --> Config Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Hooks Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Utf8 Class Initialized
DEBUG - 2016-09-23 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 09:57:55 --> URI Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Router Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Output Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 09:57:55 --> Security Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Input Class Initialized
DEBUG - 2016-09-23 09:57:55 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:55 --> XSS Filtering completed
DEBUG - 2016-09-23 09:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 09:57:55 --> Language Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Loader Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 09:57:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: url_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: file_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: common_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: form_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: security_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 09:57:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 09:57:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 09:57:55 --> Database Driver Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Session Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 09:57:55 --> Helper loaded: string_helper
DEBUG - 2016-09-23 09:57:55 --> Session routines successfully run
DEBUG - 2016-09-23 09:57:55 --> Native_session Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 09:57:55 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Form Validation Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 09:57:55 --> Controller Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 09:57:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 09:57:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 09:57:55 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:55 --> Carabiner: library configured.
DEBUG - 2016-09-23 09:57:55 --> User Agent Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:55 --> Model Class Initialized
DEBUG - 2016-09-23 09:57:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 09:57:56 --> Pagination Class Initialized
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 09:57:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 09:57:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-23 09:57:56 --> Final output sent to browser
DEBUG - 2016-09-23 09:57:56 --> Total execution time: 0.5234
DEBUG - 2016-09-23 10:02:10 --> Config Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:02:10 --> URI Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Router Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Output Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Security Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Input Class Initialized
DEBUG - 2016-09-23 10:02:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:02:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:02:10 --> Language Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Loader Class Initialized
DEBUG - 2016-09-23 10:02:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:02:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:02:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:02:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:02:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:02:10 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Session Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:02:11 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:02:11 --> Session routines successfully run
DEBUG - 2016-09-23 10:02:11 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:02:11 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:02:11 --> Controller Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:02:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:02:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:02:11 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:02:11 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:02:11 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:02:11 --> Model Class Initialized
ERROR - 2016-09-23 10:02:11 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  query has no destination for result data
HINT:  If you want to discard the results of a SELECT, use PERFORM instead.
CONTEXT:  PL/pgSQL function sc_sidika.tru_after_update_tr_peserta_diklat() line 7 at SQL statement E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-23 10:02:11 --> DB Transaction Failure
ERROR - 2016-09-23 10:02:11 --> Query error: ERROR:  query has no destination for result data
HINT:  If you want to discard the results of a SELECT, use PERFORM instead.
CONTEXT:  PL/pgSQL function sc_sidika.tru_after_update_tr_peserta_diklat() line 7 at SQL statement
DEBUG - 2016-09-23 10:02:11 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-23 10:04:19 --> Config Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:04:19 --> URI Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Router Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Output Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Security Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Input Class Initialized
DEBUG - 2016-09-23 10:04:19 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:19 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:04:19 --> Language Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Loader Class Initialized
DEBUG - 2016-09-23 10:04:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:04:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:04:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:04:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:04:20 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Session Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:04:20 --> Session routines successfully run
DEBUG - 2016-09-23 10:04:20 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:04:20 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:04:20 --> Controller Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:04:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:04:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:04:20 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:20 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:20 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Config Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:04:20 --> URI Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Router Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Output Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Security Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Input Class Initialized
DEBUG - 2016-09-23 10:04:20 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:20 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:04:20 --> Language Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Loader Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:04:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:04:20 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Session Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:04:20 --> Session routines successfully run
DEBUG - 2016-09-23 10:04:20 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:04:20 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:04:20 --> Controller Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:04:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:04:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:04:20 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:20 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:20 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Config Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:04:20 --> URI Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Router Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Output Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:04:20 --> Security Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Input Class Initialized
DEBUG - 2016-09-23 10:04:20 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:20 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:04:20 --> Language Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Loader Class Initialized
DEBUG - 2016-09-23 10:04:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:04:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:04:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:04:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:04:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:04:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:04:21 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Session Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:04:21 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:04:21 --> Session routines successfully run
DEBUG - 2016-09-23 10:04:21 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:04:21 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:04:21 --> Controller Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:04:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:04:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:04:21 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:21 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:21 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:04:21 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:04:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:04:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-23 10:04:21 --> Final output sent to browser
DEBUG - 2016-09-23 10:04:21 --> Total execution time: 0.5420
DEBUG - 2016-09-23 10:04:26 --> Config Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:04:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:04:26 --> URI Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Router Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Output Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:04:26 --> Security Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Input Class Initialized
DEBUG - 2016-09-23 10:04:26 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:26 --> XSS Filtering completed
DEBUG - 2016-09-23 10:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:04:26 --> Language Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Loader Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:04:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:04:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:04:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:04:26 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Session Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:04:26 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:04:26 --> Session routines successfully run
DEBUG - 2016-09-23 10:04:26 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:04:26 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:04:26 --> Controller Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:04:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:04:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:04:26 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:26 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:04:26 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Model Class Initialized
DEBUG - 2016-09-23 10:04:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:04:26 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:04:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:04:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-23 10:04:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:04:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:04:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-23 10:04:27 --> Final output sent to browser
DEBUG - 2016-09-23 10:04:27 --> Total execution time: 0.6462
DEBUG - 2016-09-23 10:27:57 --> Config Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:27:57 --> URI Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Router Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Output Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:27:57 --> Security Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Input Class Initialized
DEBUG - 2016-09-23 10:27:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:27:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:27:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:27:57 --> Language Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Loader Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:27:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:27:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:27:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:27:57 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Session Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:27:57 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:27:57 --> Session routines successfully run
DEBUG - 2016-09-23 10:27:57 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:27:57 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:27:57 --> Controller Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:27:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:27:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:27:57 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:27:57 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:27:57 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:57 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:27:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:27:58 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:27:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:27:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-23 10:27:58 --> Final output sent to browser
DEBUG - 2016-09-23 10:27:58 --> Total execution time: 0.5393
DEBUG - 2016-09-23 10:28:01 --> Config Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:28:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:28:01 --> URI Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Router Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Output Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:28:01 --> Security Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Input Class Initialized
DEBUG - 2016-09-23 10:28:01 --> XSS Filtering completed
DEBUG - 2016-09-23 10:28:01 --> XSS Filtering completed
DEBUG - 2016-09-23 10:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:28:01 --> Language Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Loader Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:28:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:28:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:28:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:28:01 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Session Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:28:01 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:28:01 --> Session routines successfully run
DEBUG - 2016-09-23 10:28:01 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:28:01 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:28:01 --> Controller Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:28:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:28:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:28:01 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:28:01 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:28:01 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
DEBUG - 2016-09-23 10:28:01 --> Model Class Initialized
ERROR - 2016-09-23 10:28:02 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  column tr_diklat.is_registration_closed does not exist
LINE 1: ...&quot;, &quot;sc_sidika&quot;.&quot;tr_diklat&quot;.&quot;jumlah_waiting_list&quot;, &quot;sc_sidika...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-23 10:28:02 --> DB Transaction Failure
ERROR - 2016-09-23 10:28:02 --> Query error: ERROR:  column tr_diklat.is_registration_closed does not exist
LINE 1: ...", "sc_sidika"."tr_diklat"."jumlah_waiting_list", "sc_sidika...
                                                             ^
DEBUG - 2016-09-23 10:28:02 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-23 10:29:57 --> Config Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:29:57 --> URI Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Router Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Output Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Security Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Input Class Initialized
DEBUG - 2016-09-23 10:29:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:29:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:29:57 --> Language Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Loader Class Initialized
DEBUG - 2016-09-23 10:29:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:29:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:29:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:29:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:29:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:29:57 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Session Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:29:58 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:29:58 --> Session routines successfully run
DEBUG - 2016-09-23 10:29:58 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:29:58 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:29:58 --> Controller Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:29:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:29:58 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:29:58 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:29:58 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:29:58 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:29:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:29:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-23 10:29:58 --> Final output sent to browser
DEBUG - 2016-09-23 10:29:58 --> Total execution time: 0.5690
DEBUG - 2016-09-23 10:35:57 --> Config Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:35:57 --> URI Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Router Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Output Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:35:57 --> Security Class Initialized
DEBUG - 2016-09-23 10:35:57 --> Input Class Initialized
DEBUG - 2016-09-23 10:35:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:35:57 --> XSS Filtering completed
DEBUG - 2016-09-23 10:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:35:57 --> Language Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Loader Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:35:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:35:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:35:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:35:58 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Session Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:35:58 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:35:58 --> Session routines successfully run
DEBUG - 2016-09-23 10:35:58 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:35:58 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:35:58 --> Controller Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:35:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:35:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:35:58 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:35:58 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:35:58 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Model Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:35:58 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:35:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:35:58 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:35:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:35:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:35:58 --> Final output sent to browser
DEBUG - 2016-09-23 10:35:58 --> Total execution time: 0.7173
DEBUG - 2016-09-23 10:36:07 --> Config Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:36:07 --> URI Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Router Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Output Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:36:07 --> Security Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Input Class Initialized
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:36:07 --> Language Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Loader Class Initialized
DEBUG - 2016-09-23 10:36:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:36:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:36:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:36:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:36:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:36:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:36:08 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Session Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:36:08 --> Session routines successfully run
DEBUG - 2016-09-23 10:36:08 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:36:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:36:08 --> Controller Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:36:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:36:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:36:08 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:08 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:08 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:36:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:36:08 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:36:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:36:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:36:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:36:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:36:08 --> Final output sent to browser
DEBUG - 2016-09-23 10:36:08 --> Total execution time: 0.8690
DEBUG - 2016-09-23 10:36:08 --> Config Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:36:08 --> URI Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Router Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Output Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:36:08 --> Security Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Input Class Initialized
DEBUG - 2016-09-23 10:36:08 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:08 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:36:08 --> Language Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Loader Class Initialized
DEBUG - 2016-09-23 10:36:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:36:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:36:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:36:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:36:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:36:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:36:08 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:36:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:36:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:36:09 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Session Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:36:09 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:36:09 --> Session routines successfully run
DEBUG - 2016-09-23 10:36:09 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:36:09 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:36:09 --> Controller Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:36:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:36:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:36:09 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:09 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:09 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:36:09 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-23 10:36:09 --> Final output sent to browser
DEBUG - 2016-09-23 10:36:09 --> Total execution time: 0.7080
DEBUG - 2016-09-23 10:36:11 --> Config Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:36:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:36:11 --> URI Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Router Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Output Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:36:11 --> Security Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Input Class Initialized
DEBUG - 2016-09-23 10:36:11 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:11 --> XSS Filtering completed
DEBUG - 2016-09-23 10:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:36:11 --> Language Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Loader Class Initialized
DEBUG - 2016-09-23 10:36:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:36:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:36:11 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:36:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:36:11 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:36:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:36:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:36:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:36:12 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Session Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:36:12 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:36:12 --> Session routines successfully run
DEBUG - 2016-09-23 10:36:12 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:36:12 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:36:12 --> Controller Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:36:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:36:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:36:12 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:12 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:36:12 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Model Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:36:12 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:36:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:36:12 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:36:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:36:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:36:12 --> Final output sent to browser
DEBUG - 2016-09-23 10:36:12 --> Total execution time: 0.7161
DEBUG - 2016-09-23 10:37:08 --> Config Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:37:08 --> URI Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Router Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Output Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:37:08 --> Security Class Initialized
DEBUG - 2016-09-23 10:37:08 --> Input Class Initialized
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:37:09 --> Language Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Loader Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:37:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:37:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:37:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:37:09 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Session Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:37:09 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:37:09 --> Session routines successfully run
DEBUG - 2016-09-23 10:37:09 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:37:09 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:09 --> Controller Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:37:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:37:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:37:09 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:09 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:09 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:37:09 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:09 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:37:09 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:09 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:09 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:09 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:37:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:37:10 --> Final output sent to browser
DEBUG - 2016-09-23 10:37:10 --> Total execution time: 0.9666
DEBUG - 2016-09-23 10:37:10 --> Config Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:37:10 --> URI Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Router Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Output Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:37:10 --> Security Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Input Class Initialized
DEBUG - 2016-09-23 10:37:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:37:10 --> Language Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Loader Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:37:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:37:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:37:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:37:10 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Session Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:37:10 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:37:10 --> Session routines successfully run
DEBUG - 2016-09-23 10:37:10 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:37:10 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:10 --> Controller Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:37:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:37:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:37:10 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:10 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:10 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:10 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-23 10:37:11 --> Pagination Class Initialized
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-23 10:37:11 --> Final output sent to browser
DEBUG - 2016-09-23 10:37:11 --> Total execution time: 0.7654
DEBUG - 2016-09-23 10:37:34 --> Config Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:37:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:37:34 --> URI Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Router Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Output Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:37:34 --> Security Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Input Class Initialized
DEBUG - 2016-09-23 10:37:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:37:34 --> Language Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Loader Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:37:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:37:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:37:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:37:34 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Session Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:37:34 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:37:34 --> Session routines successfully run
DEBUG - 2016-09-23 10:37:34 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:37:34 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:34 --> Controller Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:37:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:37:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:37:34 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:34 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:34 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:37:34 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:35 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:37:35 --> Final output sent to browser
DEBUG - 2016-09-23 10:37:35 --> Total execution time: 0.8026
DEBUG - 2016-09-23 10:37:43 --> Config Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:37:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:37:43 --> URI Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Router Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Output Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:37:43 --> Security Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Input Class Initialized
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:37:43 --> Language Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Loader Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:37:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:37:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:37:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:37:43 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Session Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:37:43 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:37:43 --> Session routines successfully run
DEBUG - 2016-09-23 10:37:43 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:37:43 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:43 --> Controller Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:37:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:37:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:37:43 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:43 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:37:43 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:43 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:37:44 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:37:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:37:44 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:37:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:37:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:37:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:37:44 --> Final output sent to browser
DEBUG - 2016-09-23 10:37:44 --> Total execution time: 1.0957
DEBUG - 2016-09-23 10:39:35 --> Config Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:39:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:39:35 --> URI Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Router Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Output Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:39:35 --> Security Class Initialized
DEBUG - 2016-09-23 10:39:35 --> Input Class Initialized
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> XSS Filtering completed
DEBUG - 2016-09-23 10:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:39:36 --> Language Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Loader Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:39:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:39:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:39:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:39:36 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Session Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:39:36 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:39:36 --> Session routines successfully run
DEBUG - 2016-09-23 10:39:36 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:39:36 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:39:36 --> Controller Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:39:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:39:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:39:36 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:39:36 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:39:36 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Model Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:39:36 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:39:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:39:36 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:39:36 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:39:36 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:39:36 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:39:36 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:39:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:39:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:39:37 --> Final output sent to browser
DEBUG - 2016-09-23 10:39:37 --> Total execution time: 1.1387
DEBUG - 2016-09-23 10:41:10 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:10 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:41:10 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:10 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:11 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:11 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:11 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:11 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:11 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:11 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:11 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:11 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:11 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:11 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:11 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:11 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:11 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:11 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:11 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:12 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:12 --> Total execution time: 1.2081
DEBUG - 2016-09-23 10:41:34 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:34 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:41:34 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:34 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:34 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:35 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:35 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:35 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:35 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:35 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:35 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:35 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:35 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:35 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:35 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:35 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:35 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:35 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:36 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:36 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:36 --> Total execution time: 1.2506
DEBUG - 2016-09-23 10:41:48 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:48 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:41:48 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:48 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:48 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:48 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:48 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:48 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:48 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:49 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:49 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:49 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:49 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:49 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:49 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:49 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:49 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:49 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:49 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Config Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:49 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:41:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:49 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:49 --> URI Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Router Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:49 --> Output Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Security Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Input Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> XSS Filtering completed
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:41:49 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Language Class Initialized
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:49 --> Loader Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:49 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:49 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:49 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:41:50 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:50 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:50 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:50 --> Session Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:50 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:41:50 --> Total execution time: 0.9869
DEBUG - 2016-09-23 10:41:50 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:41:50 --> Session routines successfully run
DEBUG - 2016-09-23 10:41:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:50 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:50 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:50 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:50 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:50 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:50 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:50 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:51 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:51 --> Total execution time: 1.4884
DEBUG - 2016-09-23 10:41:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:51 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:51 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:51 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:52 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:52 --> Total execution time: 2.2573
DEBUG - 2016-09-23 10:41:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:52 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:52 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:52 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:52 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:52 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:53 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:53 --> Total execution time: 3.0597
DEBUG - 2016-09-23 10:41:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:41:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:53 --> Controller Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:41:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:41:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:41:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:53 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:41:53 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Model Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:41:53 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:41:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:41:53 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:41:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:41:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:41:54 --> Final output sent to browser
DEBUG - 2016-09-23 10:41:54 --> Total execution time: 4.0130
DEBUG - 2016-09-23 10:42:07 --> Config Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:42:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:42:07 --> URI Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Router Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Output Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:42:07 --> Security Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Input Class Initialized
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:42:07 --> Language Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Loader Class Initialized
DEBUG - 2016-09-23 10:42:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:42:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:42:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:42:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:42:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:42:07 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:42:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:42:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:42:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:42:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:42:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:42:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:42:08 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Session Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:42:08 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:42:08 --> Session routines successfully run
DEBUG - 2016-09-23 10:42:08 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:42:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:42:08 --> Controller Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:42:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:42:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:42:08 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:42:08 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:42:08 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:42:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:42:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:42:08 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:42:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:42:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:42:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:42:08 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:42:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:42:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:42:09 --> Final output sent to browser
DEBUG - 2016-09-23 10:42:09 --> Total execution time: 1.5925
DEBUG - 2016-09-23 10:44:24 --> Config Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:44:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:44:24 --> URI Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Router Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Output Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:44:24 --> Security Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Input Class Initialized
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> XSS Filtering completed
DEBUG - 2016-09-23 10:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:44:24 --> Language Class Initialized
DEBUG - 2016-09-23 10:44:24 --> Loader Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:44:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:44:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:44:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:44:25 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Session Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:44:25 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:44:25 --> Session routines successfully run
DEBUG - 2016-09-23 10:44:25 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:44:25 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:44:25 --> Controller Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:44:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:44:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:44:25 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:44:25 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:44:25 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:44:25 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Config Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:45:21 --> URI Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Router Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Output Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Security Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Input Class Initialized
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:45:21 --> Language Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Loader Class Initialized
DEBUG - 2016-09-23 10:45:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:45:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:45:21 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:45:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:45:21 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:45:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:45:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:45:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:45:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:45:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:45:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:45:21 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:45:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:45:21 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:45:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:45:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:45:22 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Session Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:45:22 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:45:22 --> Session routines successfully run
DEBUG - 2016-09-23 10:45:22 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:45:22 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:45:22 --> Controller Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:45:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:45:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:45:22 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:45:22 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:45:22 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:45:22 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:45:22 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:45:22 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:22 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:22 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:22 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:43 --> Config Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:45:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:45:43 --> URI Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Router Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Output Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Security Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Input Class Initialized
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> XSS Filtering completed
DEBUG - 2016-09-23 10:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:45:43 --> Language Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Loader Class Initialized
DEBUG - 2016-09-23 10:45:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:45:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:45:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:45:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:45:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:45:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:45:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:45:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:45:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:45:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:45:43 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:45:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:45:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:45:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:45:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:45:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:45:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:45:44 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Session Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:45:44 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:45:44 --> Session routines successfully run
DEBUG - 2016-09-23 10:45:44 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:45:44 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:45:44 --> Controller Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:45:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:45:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:45:44 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:45:44 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:45:44 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Model Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:45:44 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:45:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:45:44 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:45:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:45:44 --> Unable to find validation rule: 
DEBUG - 2016-09-23 10:57:15 --> Config Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:57:15 --> URI Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Router Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Output Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Security Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Input Class Initialized
DEBUG - 2016-09-23 10:57:15 --> XSS Filtering completed
DEBUG - 2016-09-23 10:57:15 --> XSS Filtering completed
DEBUG - 2016-09-23 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:57:15 --> Language Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Loader Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:57:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:57:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:57:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:57:15 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Session Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:57:15 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:57:15 --> Session routines successfully run
DEBUG - 2016-09-23 10:57:15 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:57:15 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:57:15 --> Controller Class Initialized
DEBUG - 2016-09-23 10:57:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:57:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:57:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:57:15 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:57:16 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:57:16 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Model Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:57:16 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:57:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:57:16 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:57:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:57:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:57:16 --> Final output sent to browser
DEBUG - 2016-09-23 10:57:17 --> Total execution time: 1.2328
DEBUG - 2016-09-23 10:59:06 --> Config Class Initialized
DEBUG - 2016-09-23 10:59:06 --> Hooks Class Initialized
DEBUG - 2016-09-23 10:59:06 --> Utf8 Class Initialized
DEBUG - 2016-09-23 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 10:59:06 --> URI Class Initialized
DEBUG - 2016-09-23 10:59:06 --> Router Class Initialized
DEBUG - 2016-09-23 10:59:06 --> Output Class Initialized
DEBUG - 2016-09-23 10:59:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 10:59:06 --> Security Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Input Class Initialized
DEBUG - 2016-09-23 10:59:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:59:07 --> XSS Filtering completed
DEBUG - 2016-09-23 10:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 10:59:07 --> Language Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Loader Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 10:59:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: url_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: file_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: common_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: form_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: security_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 10:59:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 10:59:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 10:59:07 --> Database Driver Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Session Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 10:59:07 --> Helper loaded: string_helper
DEBUG - 2016-09-23 10:59:07 --> Session routines successfully run
DEBUG - 2016-09-23 10:59:07 --> Native_session Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 10:59:07 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:59:07 --> Controller Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 10:59:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 10:59:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 10:59:07 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:59:07 --> Carabiner: library configured.
DEBUG - 2016-09-23 10:59:07 --> User Agent Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:07 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:08 --> Model Class Initialized
DEBUG - 2016-09-23 10:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 10:59:08 --> Form Validation Class Initialized
DEBUG - 2016-09-23 10:59:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 10:59:08 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 10:59:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 10:59:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 10:59:08 --> Final output sent to browser
DEBUG - 2016-09-23 10:59:08 --> Total execution time: 1.2813
DEBUG - 2016-09-23 11:00:34 --> Config Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Utf8 Class Initialized
DEBUG - 2016-09-23 11:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 11:00:34 --> URI Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Router Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Output Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 11:00:34 --> Security Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Input Class Initialized
DEBUG - 2016-09-23 11:00:34 --> XSS Filtering completed
DEBUG - 2016-09-23 11:00:34 --> XSS Filtering completed
DEBUG - 2016-09-23 11:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 11:00:34 --> Language Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Loader Class Initialized
DEBUG - 2016-09-23 11:00:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 11:00:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: url_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: file_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: common_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: common_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: form_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: security_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 11:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 11:00:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 11:00:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 11:00:34 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Session Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 11:00:35 --> Helper loaded: string_helper
DEBUG - 2016-09-23 11:00:35 --> Session routines successfully run
DEBUG - 2016-09-23 11:00:35 --> Native_session Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 11:00:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 11:00:35 --> Controller Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 11:00:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 11:00:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 11:00:35 --> Carabiner: library configured.
DEBUG - 2016-09-23 11:00:35 --> Carabiner: library configured.
DEBUG - 2016-09-23 11:00:35 --> User Agent Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Model Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 11:00:35 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:00:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 11:00:35 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 11:00:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 11:00:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 11:00:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 11:00:36 --> Final output sent to browser
DEBUG - 2016-09-23 11:00:36 --> Total execution time: 1.3161
DEBUG - 2016-09-23 11:02:05 --> Config Class Initialized
DEBUG - 2016-09-23 11:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-23 11:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-23 11:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 11:02:05 --> URI Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Router Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Output Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 11:02:06 --> Security Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Input Class Initialized
DEBUG - 2016-09-23 11:02:06 --> XSS Filtering completed
DEBUG - 2016-09-23 11:02:06 --> XSS Filtering completed
DEBUG - 2016-09-23 11:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 11:02:06 --> Language Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Loader Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 11:02:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: url_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: file_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: common_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: common_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: form_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: security_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 11:02:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 11:02:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 11:02:06 --> Database Driver Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Session Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 11:02:06 --> Helper loaded: string_helper
DEBUG - 2016-09-23 11:02:06 --> Session routines successfully run
DEBUG - 2016-09-23 11:02:06 --> Native_session Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 11:02:06 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 11:02:06 --> Controller Class Initialized
DEBUG - 2016-09-23 11:02:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 11:02:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 11:02:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 11:02:06 --> Carabiner: library configured.
DEBUG - 2016-09-23 11:02:06 --> Carabiner: library configured.
DEBUG - 2016-09-23 11:02:07 --> User Agent Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Model Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 11:02:07 --> Form Validation Class Initialized
DEBUG - 2016-09-23 11:02:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 11:02:07 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 11:02:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 11:02:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 11:02:08 --> Final output sent to browser
DEBUG - 2016-09-23 11:02:08 --> Total execution time: 1.3534
DEBUG - 2016-09-23 17:22:22 --> Config Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Hooks Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Utf8 Class Initialized
DEBUG - 2016-09-23 17:22:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 17:22:22 --> URI Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Router Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Output Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 17:22:22 --> Security Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Input Class Initialized
DEBUG - 2016-09-23 17:22:22 --> XSS Filtering completed
DEBUG - 2016-09-23 17:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 17:22:22 --> Language Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Loader Class Initialized
DEBUG - 2016-09-23 17:22:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 17:22:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: url_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: file_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: common_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: common_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: form_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: security_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 17:22:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 17:22:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 17:22:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 17:22:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 17:22:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 17:22:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 17:22:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 17:22:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 17:22:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 17:22:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 17:22:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 17:22:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 17:22:23 --> Database Driver Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Session Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 17:22:23 --> Helper loaded: string_helper
DEBUG - 2016-09-23 17:22:23 --> A session cookie was not found.
DEBUG - 2016-09-23 17:22:23 --> Session routines successfully run
DEBUG - 2016-09-23 17:22:23 --> Native_session Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 17:22:23 --> Form Validation Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Form Validation Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 17:22:23 --> Controller Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 17:22:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 17:22:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 17:22:23 --> Carabiner: library configured.
DEBUG - 2016-09-23 17:22:23 --> Carabiner: library configured.
DEBUG - 2016-09-23 17:22:23 --> User Agent Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Model Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 17:22:23 --> Form Validation Class Initialized
DEBUG - 2016-09-23 17:22:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 17:22:23 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 17:22:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 17:22:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 17:22:24 --> Final output sent to browser
DEBUG - 2016-09-23 17:22:24 --> Total execution time: 1.4211
DEBUG - 2016-09-23 20:55:18 --> Config Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Hooks Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Utf8 Class Initialized
DEBUG - 2016-09-23 20:55:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 20:55:18 --> URI Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Router Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Output Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 20:55:18 --> Security Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Input Class Initialized
DEBUG - 2016-09-23 20:55:18 --> XSS Filtering completed
DEBUG - 2016-09-23 20:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 20:55:18 --> Language Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Loader Class Initialized
DEBUG - 2016-09-23 20:55:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 20:55:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: url_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: file_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: common_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: common_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: form_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: security_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 20:55:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 20:55:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 20:55:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 20:55:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 20:55:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 20:55:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 20:55:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 20:55:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 20:55:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 20:55:19 --> Database Driver Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Session Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 20:55:19 --> Helper loaded: string_helper
DEBUG - 2016-09-23 20:55:19 --> A session cookie was not found.
DEBUG - 2016-09-23 20:55:19 --> Session routines successfully run
DEBUG - 2016-09-23 20:55:19 --> Native_session Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 20:55:19 --> Form Validation Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Form Validation Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 20:55:19 --> Controller Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 20:55:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 20:55:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 20:55:19 --> Carabiner: library configured.
DEBUG - 2016-09-23 20:55:19 --> Carabiner: library configured.
DEBUG - 2016-09-23 20:55:19 --> User Agent Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Model Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 20:55:19 --> Form Validation Class Initialized
DEBUG - 2016-09-23 20:55:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 20:55:19 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-23 20:55:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-23 20:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-23 20:55:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-23 20:55:20 --> Final output sent to browser
DEBUG - 2016-09-23 20:55:20 --> Total execution time: 1.4195
DEBUG - 2016-09-23 21:05:16 --> Config Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Hooks Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Utf8 Class Initialized
DEBUG - 2016-09-23 21:05:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-23 21:05:16 --> URI Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Router Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Output Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-23 21:05:16 --> Security Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Input Class Initialized
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> XSS Filtering completed
DEBUG - 2016-09-23 21:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-23 21:05:16 --> Language Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Loader Class Initialized
DEBUG - 2016-09-23 21:05:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-23 21:05:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-23 21:05:16 --> Helper loaded: url_helper
DEBUG - 2016-09-23 21:05:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-23 21:05:16 --> Helper loaded: file_helper
DEBUG - 2016-09-23 21:05:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 21:05:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-23 21:05:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-23 21:05:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-23 21:05:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: common_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: common_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: form_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: security_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-23 21:05:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-23 21:05:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-23 21:05:17 --> Database Driver Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Session Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-23 21:05:17 --> Helper loaded: string_helper
DEBUG - 2016-09-23 21:05:17 --> Session routines successfully run
DEBUG - 2016-09-23 21:05:17 --> Native_session Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-23 21:05:17 --> Form Validation Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Form Validation Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 21:05:17 --> Controller Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-23 21:05:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-23 21:05:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-23 21:05:17 --> Carabiner: library configured.
DEBUG - 2016-09-23 21:05:17 --> Carabiner: library configured.
DEBUG - 2016-09-23 21:05:17 --> User Agent Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Model Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-23 21:05:17 --> Form Validation Class Initialized
DEBUG - 2016-09-23 21:05:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-23 21:05:17 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-23 21:05:18 --> Unable to find validation rule: 
DEBUG - 2016-09-23 21:05:18 --> Unable to find validation rule: 
DEBUG - 2016-09-23 21:05:18 --> Unable to find validation rule: 
DEBUG - 2016-09-23 21:05:18 --> Unable to find validation rule: 
ERROR - 2016-09-23 21:05:18 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;&quot;
LINE 1: ..._active&quot;, &quot;modified_date&quot;, &quot;modified_by&quot;) VALUES ('', 'Terda...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-23 21:05:18 --> DB Transaction Failure
ERROR - 2016-09-23 21:05:18 --> Query error: ERROR:  invalid input syntax for integer: ""
LINE 1: ..._active", "modified_date", "modified_by") VALUES ('', 'Terda...
                                                             ^
DEBUG - 2016-09-23 21:05:18 --> Language file loaded: language/indonesia/db_lang.php
