<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-24 18:32:21 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:21 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:32:21 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:21 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:21 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:22 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:22 --> A session cookie was not found.
DEBUG - 2016-08-24 18:32:22 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:22 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:22 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:22 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:22 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:22 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:22 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:22 --> Model Class Initialized
ERROR - 2016-08-24 18:32:24 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-24 18:32:24 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-24 18:32:24 --> Final output sent to browser
DEBUG - 2016-08-24 18:32:24 --> Total execution time: 3.2613
DEBUG - 2016-08-24 18:32:27 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:27 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:32:27 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:27 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:27 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:27 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:27 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:27 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:27 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:27 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:27 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:27 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:27 --> Model Class Initialized
ERROR - 2016-08-24 18:32:27 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-24 18:32:27 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-08-24 18:32:27 --> Final output sent to browser
DEBUG - 2016-08-24 18:32:27 --> Total execution time: 0.2952
DEBUG - 2016-08-24 18:32:32 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:32 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:32:32 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:32 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:32 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:32 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:32 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:33 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:33 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:33 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:33 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:33 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:33 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:33 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:33 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:33 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:33 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:32:33 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 18:32:33 --> Final output sent to browser
DEBUG - 2016-08-24 18:32:33 --> Total execution time: 0.6045
DEBUG - 2016-08-24 18:32:33 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:33 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:33 --> Router Class Initialized
ERROR - 2016-08-24 18:32:33 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-24 18:32:38 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:38 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:38 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:38 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:38 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:38 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:32:39 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:39 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:39 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:39 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:39 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:39 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:39 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:39 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:39 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:39 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:39 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:39 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:39 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:32:39 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-24 18:32:39 --> Final output sent to browser
DEBUG - 2016-08-24 18:32:39 --> Total execution time: 0.7386
DEBUG - 2016-08-24 18:32:40 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:40 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:40 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:40 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:40 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:40 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:40 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:40 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:40 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:40 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:40 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Config Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:32:40 --> URI Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Router Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Output Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:32:40 --> Security Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Input Class Initialized
DEBUG - 2016-08-24 18:32:40 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:40 --> XSS Filtering completed
DEBUG - 2016-08-24 18:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:32:40 --> Language Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Loader Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:32:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:32:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:32:40 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Session Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:32:40 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:32:40 --> Session routines successfully run
DEBUG - 2016-08-24 18:32:40 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:32:40 --> Controller Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:32:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:32:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:32:40 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:40 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:32:40 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Model Class Initialized
DEBUG - 2016-08-24 18:32:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:32:40 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:32:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:32:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 18:32:40 --> Final output sent to browser
DEBUG - 2016-08-24 18:32:40 --> Total execution time: 0.2773
DEBUG - 2016-08-24 18:43:15 --> Config Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:43:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:43:15 --> URI Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Router Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Output Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:43:15 --> Security Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Input Class Initialized
DEBUG - 2016-08-24 18:43:15 --> XSS Filtering completed
DEBUG - 2016-08-24 18:43:15 --> XSS Filtering completed
DEBUG - 2016-08-24 18:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:43:15 --> Language Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Loader Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:43:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:43:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:43:15 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Session Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:43:15 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:43:15 --> Session routines successfully run
DEBUG - 2016-08-24 18:43:15 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:43:15 --> Controller Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:43:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:43:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:43:15 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:43:15 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:43:15 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Model Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Model Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Model Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Model Class Initialized
DEBUG - 2016-08-24 18:43:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:43:15 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:43:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-24 18:43:15 --> Final output sent to browser
DEBUG - 2016-08-24 18:43:15 --> Total execution time: 0.4097
DEBUG - 2016-08-24 18:44:57 --> Config Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:44:57 --> URI Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Router Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Output Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:44:57 --> Security Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Input Class Initialized
DEBUG - 2016-08-24 18:44:57 --> XSS Filtering completed
DEBUG - 2016-08-24 18:44:57 --> XSS Filtering completed
DEBUG - 2016-08-24 18:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:44:57 --> Language Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Loader Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:44:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:44:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:44:57 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Session Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:44:57 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:44:57 --> Session routines successfully run
DEBUG - 2016-08-24 18:44:57 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:44:57 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:44:57 --> Controller Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:44:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:44:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:44:57 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:44:57 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:44:57 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Model Class Initialized
DEBUG - 2016-08-24 18:44:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:44:57 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:44:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:44:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 18:44:57 --> Final output sent to browser
DEBUG - 2016-08-24 18:44:57 --> Total execution time: 0.3324
DEBUG - 2016-08-24 18:45:02 --> Config Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:45:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:45:02 --> URI Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Router Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Output Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:45:02 --> Security Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Input Class Initialized
DEBUG - 2016-08-24 18:45:02 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:02 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:45:02 --> Language Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Loader Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:45:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Session Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:45:02 --> Session routines successfully run
DEBUG - 2016-08-24 18:45:02 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:45:02 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:45:02 --> Controller Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:45:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:45:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:45:02 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:02 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:02 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:45:02 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-24 18:45:02 --> Final output sent to browser
DEBUG - 2016-08-24 18:45:02 --> Total execution time: 0.3284
DEBUG - 2016-08-24 18:45:02 --> Config Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:45:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:45:02 --> URI Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Router Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Output Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Security Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Input Class Initialized
DEBUG - 2016-08-24 18:45:02 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:02 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:45:02 --> Language Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Loader Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:45:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:45:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:02 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Session Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:45:02 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:45:02 --> Session routines successfully run
DEBUG - 2016-08-24 18:45:02 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:45:02 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:45:02 --> Controller Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:45:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:45:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:45:02 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:02 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:02 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:02 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Config Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:45:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:45:03 --> URI Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Router Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Output Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:45:03 --> Security Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Input Class Initialized
DEBUG - 2016-08-24 18:45:03 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:03 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:45:03 --> Language Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Loader Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:45:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Session Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:45:03 --> Session routines successfully run
DEBUG - 2016-08-24 18:45:03 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:45:03 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:45:03 --> Controller Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:45:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:45:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:45:03 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:03 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:03 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:45:03 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 18:45:03 --> Final output sent to browser
DEBUG - 2016-08-24 18:45:03 --> Total execution time: 0.3662
DEBUG - 2016-08-24 18:45:03 --> Config Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:45:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:45:03 --> URI Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Router Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Output Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Security Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Input Class Initialized
DEBUG - 2016-08-24 18:45:03 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:03 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:45:03 --> Language Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Loader Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:45:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:45:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:03 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Session Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:45:03 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:45:03 --> Session routines successfully run
DEBUG - 2016-08-24 18:45:03 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:45:03 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:45:03 --> Controller Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:45:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:45:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:45:03 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:03 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:03 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:45:03 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a181d4a679e6905a87ac04b152de0aae
DEBUG - 2016-08-24 18:45:04 --> Final output sent to browser
DEBUG - 2016-08-24 18:45:04 --> Total execution time: 0.3561
DEBUG - 2016-08-24 18:45:04 --> Config Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:45:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:45:04 --> URI Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Router Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Output Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:45:04 --> Security Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Input Class Initialized
DEBUG - 2016-08-24 18:45:04 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:04 --> XSS Filtering completed
DEBUG - 2016-08-24 18:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:45:04 --> Language Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Loader Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:45:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:45:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:45:04 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Session Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:45:04 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:45:04 --> Session routines successfully run
DEBUG - 2016-08-24 18:45:04 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:45:04 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:45:04 --> Controller Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:45:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:45:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:45:04 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:04 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:45:04 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-08-24 18:45:04 --> Model Class Initialized
ERROR - 2016-08-24 18:45:04 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-24 18:45:04 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:45:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:45:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/f16f443ef5d136340ba982c3e8ed6e1e
DEBUG - 2016-08-24 18:45:04 --> Final output sent to browser
DEBUG - 2016-08-24 18:45:04 --> Total execution time: 0.4226
DEBUG - 2016-08-24 18:50:32 --> Config Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:50:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:50:32 --> URI Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Router Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Output Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:50:32 --> Security Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Input Class Initialized
DEBUG - 2016-08-24 18:50:32 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:32 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:50:32 --> Language Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Loader Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:50:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:50:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:32 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Session Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:50:32 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:50:32 --> Session routines successfully run
DEBUG - 2016-08-24 18:50:32 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:50:32 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:50:32 --> Controller Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:50:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:50:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:50:32 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:32 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:32 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 18:50:32 --> Pagination Class Initialized
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:50:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:50:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-24 18:50:32 --> Final output sent to browser
DEBUG - 2016-08-24 18:50:32 --> Total execution time: 0.4206
DEBUG - 2016-08-24 18:50:32 --> Config Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:50:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:50:32 --> URI Class Initialized
DEBUG - 2016-08-24 18:50:32 --> Router Class Initialized
ERROR - 2016-08-24 18:50:32 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-24 18:50:34 --> Config Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:50:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:50:34 --> URI Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Router Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Output Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Security Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Input Class Initialized
DEBUG - 2016-08-24 18:50:34 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:34 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:50:34 --> Language Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Loader Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:50:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:50:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:34 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Session Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:50:34 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:50:34 --> Session routines successfully run
DEBUG - 2016-08-24 18:50:34 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:50:34 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:50:34 --> Controller Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:50:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:50:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:50:34 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:34 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:34 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Model Class Initialized
ERROR - 2016-08-24 18:50:34 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-24 18:50:34 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/detail.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:50:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:50:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3cd2012797efc339130dbd0f76604ad9
DEBUG - 2016-08-24 18:50:34 --> Final output sent to browser
DEBUG - 2016-08-24 18:50:34 --> Total execution time: 0.3861
DEBUG - 2016-08-24 18:50:34 --> Config Class Initialized
DEBUG - 2016-08-24 18:50:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:50:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:50:35 --> URI Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Router Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Output Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Security Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Input Class Initialized
DEBUG - 2016-08-24 18:50:35 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:35 --> XSS Filtering completed
DEBUG - 2016-08-24 18:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:50:35 --> Language Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Loader Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:50:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:50:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:50:35 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Session Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:50:35 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:50:35 --> Session routines successfully run
DEBUG - 2016-08-24 18:50:35 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:50:35 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:50:35 --> Controller Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:50:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:50:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:50:35 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:35 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:50:35 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Model Class Initialized
DEBUG - 2016-08-24 18:50:35 --> Model Class Initialized
ERROR - 2016-08-24 18:50:35 --> 404 Page Not Found --> 
DEBUG - 2016-08-24 18:51:29 --> Config Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:51:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:51:29 --> URI Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Router Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Output Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:51:29 --> Security Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Input Class Initialized
DEBUG - 2016-08-24 18:51:29 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:29 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:51:29 --> Language Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Loader Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:51:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:51:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:29 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Session Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:51:29 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:51:29 --> Session routines successfully run
DEBUG - 2016-08-24 18:51:29 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:51:29 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:51:29 --> Controller Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:51:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:51:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:51:29 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:29 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:29 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:51:29 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
ERROR - 2016-08-24 18:51:30 --> Severity: Notice  --> Undefined variable: detail_diklat E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 126
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/detail.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:51:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:51:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3cd2012797efc339130dbd0f76604ad9
DEBUG - 2016-08-24 18:51:30 --> Final output sent to browser
DEBUG - 2016-08-24 18:51:30 --> Total execution time: 0.4549
DEBUG - 2016-08-24 18:51:30 --> Config Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:51:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:51:30 --> URI Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Router Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Output Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Security Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Input Class Initialized
DEBUG - 2016-08-24 18:51:30 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:30 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:51:30 --> Language Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Loader Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:51:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:51:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:30 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Session Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:51:30 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:51:30 --> Session routines successfully run
DEBUG - 2016-08-24 18:51:30 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:51:30 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:51:30 --> Controller Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:51:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:51:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:51:30 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:30 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:30 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:30 --> Model Class Initialized
ERROR - 2016-08-24 18:51:30 --> 404 Page Not Found --> 
DEBUG - 2016-08-24 18:51:51 --> Config Class Initialized
DEBUG - 2016-08-24 18:51:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:51:51 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:51:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:51:51 --> URI Class Initialized
DEBUG - 2016-08-24 18:51:51 --> Router Class Initialized
DEBUG - 2016-08-24 18:51:51 --> Output Class Initialized
DEBUG - 2016-08-24 18:51:51 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 18:51:51 --> Security Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Input Class Initialized
DEBUG - 2016-08-24 18:51:52 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:52 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:51:52 --> Language Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Loader Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:51:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Session Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:51:52 --> Session routines successfully run
DEBUG - 2016-08-24 18:51:52 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:51:52 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:51:52 --> Controller Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:51:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:51:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:51:52 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:52 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:52 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/detail.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 18:51:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 18:51:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3cd2012797efc339130dbd0f76604ad9
DEBUG - 2016-08-24 18:51:52 --> Final output sent to browser
DEBUG - 2016-08-24 18:51:52 --> Total execution time: 0.4552
DEBUG - 2016-08-24 18:51:52 --> Config Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Utf8 Class Initialized
DEBUG - 2016-08-24 18:51:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 18:51:52 --> URI Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Router Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Output Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Security Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Input Class Initialized
DEBUG - 2016-08-24 18:51:52 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:52 --> XSS Filtering completed
DEBUG - 2016-08-24 18:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 18:51:52 --> Language Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Loader Class Initialized
DEBUG - 2016-08-24 18:51:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 18:51:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: url_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: file_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 18:51:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 18:51:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 18:51:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: common_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: form_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: security_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 18:51:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 18:51:53 --> Database Driver Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Session Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 18:51:53 --> Helper loaded: string_helper
DEBUG - 2016-08-24 18:51:53 --> Session routines successfully run
DEBUG - 2016-08-24 18:51:53 --> Native_session Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 18:51:53 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Form Validation Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 18:51:53 --> Controller Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 18:51:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 18:51:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 18:51:53 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:53 --> Carabiner: library configured.
DEBUG - 2016-08-24 18:51:53 --> User Agent Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Model Class Initialized
DEBUG - 2016-08-24 18:51:53 --> Model Class Initialized
ERROR - 2016-08-24 18:51:53 --> 404 Page Not Found --> 
DEBUG - 2016-08-24 21:08:40 --> Config Class Initialized
DEBUG - 2016-08-24 21:08:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:08:40 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:08:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:08:40 --> URI Class Initialized
DEBUG - 2016-08-24 21:08:40 --> Router Class Initialized
DEBUG - 2016-08-24 21:08:41 --> Output Class Initialized
DEBUG - 2016-08-24 21:08:41 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:08:41 --> Security Class Initialized
DEBUG - 2016-08-24 21:08:41 --> Input Class Initialized
DEBUG - 2016-08-24 21:08:41 --> XSS Filtering completed
DEBUG - 2016-08-24 21:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:08:41 --> Language Class Initialized
DEBUG - 2016-08-24 21:08:41 --> Loader Class Initialized
DEBUG - 2016-08-24 21:08:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:08:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:08:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:08:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:08:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:08:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:08:42 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:08:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:08:42 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:08:43 --> Session Class Initialized
DEBUG - 2016-08-24 21:08:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:08:43 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:08:43 --> A session cookie was not found.
DEBUG - 2016-08-24 21:08:43 --> Session routines successfully run
DEBUG - 2016-08-24 21:08:43 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:08:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:08:43 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:08:43 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:08:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:08:44 --> Controller Class Initialized
DEBUG - 2016-08-24 21:08:44 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:08:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:08:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:08:44 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:08:44 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:08:44 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:08:44 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:44 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:44 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:45 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/detail.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/detail_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/detail_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:08:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3cd2012797efc339130dbd0f76604ad9
DEBUG - 2016-08-24 21:08:45 --> Final output sent to browser
DEBUG - 2016-08-24 21:08:45 --> Total execution time: 4.9332
DEBUG - 2016-08-24 21:08:54 --> Config Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:08:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:08:54 --> URI Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Router Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Output Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Security Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Input Class Initialized
DEBUG - 2016-08-24 21:08:54 --> XSS Filtering completed
DEBUG - 2016-08-24 21:08:54 --> XSS Filtering completed
DEBUG - 2016-08-24 21:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:08:54 --> Language Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Loader Class Initialized
DEBUG - 2016-08-24 21:08:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:08:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:08:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:08:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:08:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:08:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:08:54 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:08:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:08:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:08:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:08:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:08:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:08:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:08:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:08:55 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Session Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:08:55 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:08:55 --> Session routines successfully run
DEBUG - 2016-08-24 21:08:55 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:08:55 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:08:55 --> Controller Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:08:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:08:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:08:55 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:08:55 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:08:55 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Model Class Initialized
DEBUG - 2016-08-24 21:08:55 --> Model Class Initialized
ERROR - 2016-08-24 21:08:55 --> 404 Page Not Found --> 
DEBUG - 2016-08-24 21:13:26 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:26 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:13:26 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:26 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:26 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:26 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:26 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:26 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:26 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:26 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:26 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:26 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:27 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:27 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:27 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:27 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:27 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:27 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-24 21:13:27 --> Final output sent to browser
DEBUG - 2016-08-24 21:13:27 --> Total execution time: 0.7715
DEBUG - 2016-08-24 21:13:28 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:28 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:13:28 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:28 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:28 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:28 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:28 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:28 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:28 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:28 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:28 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:28 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:28 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:28 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:29 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:29 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:29 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:29 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:29 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:29 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:29 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-24 21:13:29 --> Final output sent to browser
DEBUG - 2016-08-24 21:13:29 --> Total execution time: 0.6487
DEBUG - 2016-08-24 21:13:35 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:35 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:13:35 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:35 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:35 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:35 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:35 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:35 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:35 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:36 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:36 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:36 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:36 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:36 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:36 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-24 21:13:36 --> Final output sent to browser
DEBUG - 2016-08-24 21:13:36 --> Total execution time: 0.6159
DEBUG - 2016-08-24 21:13:53 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:53 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:13:53 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:53 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:53 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:53 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:53 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:54 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:54 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:54 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:54 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:54 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:54 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:54 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:54 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:54 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 21:13:54 --> Pagination Class Initialized
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:13:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-08-24 21:13:54 --> Final output sent to browser
DEBUG - 2016-08-24 21:13:54 --> Total execution time: 0.7422
DEBUG - 2016-08-24 21:13:55 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:55 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:55 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:55 --> Router Class Initialized
ERROR - 2016-08-24 21:13:55 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-24 21:13:57 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:57 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:57 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:57 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:57 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:58 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:58 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:58 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:58 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:58 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:58 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:58 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:58 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:58 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:58 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/detail.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 21:13:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 21:13:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/49e4762d00d24f1c5533f9e9ce9c758c
DEBUG - 2016-08-24 21:13:58 --> Final output sent to browser
DEBUG - 2016-08-24 21:13:58 --> Total execution time: 0.6721
DEBUG - 2016-08-24 21:13:58 --> Config Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:13:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:13:58 --> URI Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Router Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Output Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Security Class Initialized
DEBUG - 2016-08-24 21:13:58 --> Input Class Initialized
DEBUG - 2016-08-24 21:13:58 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:58 --> XSS Filtering completed
DEBUG - 2016-08-24 21:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:13:58 --> Language Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Loader Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:13:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:13:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:13:59 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Session Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:13:59 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:13:59 --> Session routines successfully run
DEBUG - 2016-08-24 21:13:59 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:13:59 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:13:59 --> Controller Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:13:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:13:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:13:59 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:59 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:13:59 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Model Class Initialized
DEBUG - 2016-08-24 21:13:59 --> Model Class Initialized
ERROR - 2016-08-24 21:13:59 --> 404 Page Not Found --> 
DEBUG - 2016-08-24 21:14:37 --> Config Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Hooks Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Utf8 Class Initialized
DEBUG - 2016-08-24 21:14:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 21:14:37 --> URI Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Router Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Output Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 21:14:37 --> Security Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Input Class Initialized
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> XSS Filtering completed
DEBUG - 2016-08-24 21:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 21:14:37 --> Language Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Loader Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 21:14:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: url_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: file_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: common_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: form_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: security_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 21:14:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 21:14:37 --> Database Driver Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Session Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 21:14:37 --> Helper loaded: string_helper
DEBUG - 2016-08-24 21:14:37 --> Session routines successfully run
DEBUG - 2016-08-24 21:14:37 --> Native_session Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 21:14:37 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:14:37 --> Controller Class Initialized
DEBUG - 2016-08-24 21:14:37 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 21:14:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 21:14:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 21:14:37 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:14:37 --> Carabiner: library configured.
DEBUG - 2016-08-24 21:14:38 --> User Agent Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Model Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Model Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Model Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Model Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 21:14:38 --> Form Validation Class Initialized
DEBUG - 2016-08-24 21:14:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 21:14:38 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-08-24 21:14:38 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;&quot;
LINE 1: ...e&quot;, &quot;modified_by&quot;) VALUES ('SKPD Contoh Level 1', '', 'SCL1'...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-24 21:14:38 --> DB Transaction Failure
ERROR - 2016-08-24 21:14:38 --> Query error: ERROR:  invalid input syntax for integer: ""
LINE 1: ...e", "modified_by") VALUES ('SKPD Contoh Level 1', '', 'SCL1'...
                                                             ^
DEBUG - 2016-08-24 21:14:38 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-24 22:51:33 --> Config Class Initialized
DEBUG - 2016-08-24 22:51:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:51:34 --> URI Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Router Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Output Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:51:34 --> Security Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Input Class Initialized
DEBUG - 2016-08-24 22:51:34 --> XSS Filtering completed
DEBUG - 2016-08-24 22:51:34 --> XSS Filtering completed
DEBUG - 2016-08-24 22:51:34 --> XSS Filtering completed
DEBUG - 2016-08-24 22:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:51:34 --> Language Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Loader Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:51:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:51:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:51:34 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Session Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:51:34 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:51:34 --> Session routines successfully run
DEBUG - 2016-08-24 22:51:34 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:51:34 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:51:34 --> Controller Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:51:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:51:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:51:34 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:51:34 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:51:34 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Model Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Model Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Model Class Initialized
DEBUG - 2016-08-24 22:51:34 --> Model Class Initialized
DEBUG - 2016-08-24 22:51:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:51:35 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:51:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:51:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-08-24 22:51:35 --> Final output sent to browser
DEBUG - 2016-08-24 22:51:35 --> Total execution time: 1.2387
DEBUG - 2016-08-24 22:53:36 --> Config Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:53:36 --> URI Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Router Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Output Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Security Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Input Class Initialized
DEBUG - 2016-08-24 22:53:36 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:36 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:36 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:53:36 --> Language Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Loader Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:53:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:53:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:36 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Session Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:53:36 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:53:36 --> Session routines successfully run
DEBUG - 2016-08-24 22:53:36 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:53:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:53:36 --> Controller Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:53:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:53:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:53:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:36 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/detail.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:53:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:53:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/49e4762d00d24f1c5533f9e9ce9c758c
DEBUG - 2016-08-24 22:53:36 --> Final output sent to browser
DEBUG - 2016-08-24 22:53:36 --> Total execution time: 0.6350
DEBUG - 2016-08-24 22:53:57 --> Config Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:53:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:53:57 --> URI Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Router Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Output Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:53:57 --> Security Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Input Class Initialized
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:53:57 --> Language Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Loader Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:53:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:53:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:57 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Session Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:53:57 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:53:57 --> Session routines successfully run
DEBUG - 2016-08-24 22:53:57 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:53:57 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:53:57 --> Controller Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:53:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:53:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:53:57 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:57 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:57 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 22:53:57 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:53:57 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-24 22:53:58 --> Config Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:53:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:53:58 --> URI Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Router Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Output Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:53:58 --> Security Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Input Class Initialized
DEBUG - 2016-08-24 22:53:58 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:58 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:58 --> XSS Filtering completed
DEBUG - 2016-08-24 22:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:53:58 --> Language Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Loader Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:53:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:53:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:53:58 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Session Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:53:58 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:53:58 --> Session routines successfully run
DEBUG - 2016-08-24 22:53:58 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:53:58 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:53:58 --> Controller Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:53:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:53:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:53:58 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:58 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:53:58 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Model Class Initialized
DEBUG - 2016-08-24 22:53:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:53:58 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:53:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:53:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-08-24 22:53:58 --> Final output sent to browser
DEBUG - 2016-08-24 22:53:58 --> Total execution time: 0.7544
DEBUG - 2016-08-24 22:54:13 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:13 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:13 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:13 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:13 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:13 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:13 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:13 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:13 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:14 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:14 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:14 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:14 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:14 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:14 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:14 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:14 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:14 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:14 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:14 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-24 22:54:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Total execution time: 0.7823
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:14 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:14 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:14 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:14 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:14 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:14 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:14 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:14 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:14 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-24 22:54:14 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:14 --> Total execution time: 0.6654
DEBUG - 2016-08-24 22:54:20 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:20 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:20 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:20 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:20 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:20 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:20 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:20 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:20 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:20 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:20 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:20 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:20 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:20 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:20 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:21 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:21 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:21 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:21 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:21 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:54:21 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/index.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/js/index_js.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/js/index_js.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ba4994ce93fe7c31a0d1ab59dc6a7701
DEBUG - 2016-08-24 22:54:21 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:21 --> Total execution time: 0.9770
DEBUG - 2016-08-24 22:54:26 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:26 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:26 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:26 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:26 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:26 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:27 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:27 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:27 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:27 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:27 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:27 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:27 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:27 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:27 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:27 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-24 22:54:27 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:27 --> Total execution time: 0.7541
DEBUG - 2016-08-24 22:54:33 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:33 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:33 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:33 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:33 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:33 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:33 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:33 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:33 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:33 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:33 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:33 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:33 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:33 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:33 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:33 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:33 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-24 22:54:33 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:33 --> Total execution time: 0.8520
DEBUG - 2016-08-24 22:54:35 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:35 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:35 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:35 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:35 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:35 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:35 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:35 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:35 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:36 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:36 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:36 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:36 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:36 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:36 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-24 22:54:36 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:36 --> Total execution time: 0.7590
DEBUG - 2016-08-24 22:54:40 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:40 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:41 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:41 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:41 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:41 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:41 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:41 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:41 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:41 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:41 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:41 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:41 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:41 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:41 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 22:54:42 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:42 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:42 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:43 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:43 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:43 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:43 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:43 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:44 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:44 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:44 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:44 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:44 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:44 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:44 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:44 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:44 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:44 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:44 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:44 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:44 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:44 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:44 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:45 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:45 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:45 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:45 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:45 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:45 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:45 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:45 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:45 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:45 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:54:46 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 22:54:46 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:46 --> Total execution time: 1.7074
DEBUG - 2016-08-24 22:54:46 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:46 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:46 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:46 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:46 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:46 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:46 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:46 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:46 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:47 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:47 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:47 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:47 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:47 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:47 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:47 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:47 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:47 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:54:47 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-24 22:54:47 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:48 --> Total execution time: 0.9475
DEBUG - 2016-08-24 22:54:48 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:48 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:48 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:48 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:48 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:48 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:48 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:49 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:49 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:49 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:49 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:49 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:49 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:49 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Config Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Utf8 Class Initialized
DEBUG - 2016-08-24 22:54:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 22:54:49 --> URI Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Router Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Output Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Cache file has expired. File deleted
DEBUG - 2016-08-24 22:54:49 --> Security Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Input Class Initialized
DEBUG - 2016-08-24 22:54:49 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:49 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:49 --> XSS Filtering completed
DEBUG - 2016-08-24 22:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-24 22:54:49 --> Language Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Loader Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-24 22:54:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: url_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: file_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: common_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: form_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: security_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-24 22:54:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-24 22:54:49 --> Database Driver Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Session Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-24 22:54:49 --> Helper loaded: string_helper
DEBUG - 2016-08-24 22:54:49 --> Session routines successfully run
DEBUG - 2016-08-24 22:54:49 --> Native_session Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-24 22:54:49 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:49 --> Form Validation Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-24 22:54:50 --> Controller Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-24 22:54:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-24 22:54:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-24 22:54:50 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:50 --> Carabiner: library configured.
DEBUG - 2016-08-24 22:54:50 --> User Agent Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Model Class Initialized
DEBUG - 2016-08-24 22:54:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-24 22:54:50 --> Pagination Class Initialized
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-24 22:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-24 22:54:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-24 22:54:50 --> Final output sent to browser
DEBUG - 2016-08-24 22:54:50 --> Total execution time: 0.9320
