<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-28 18:39:48 --> Config Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:39:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:39:48 --> URI Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Router Class Initialized
DEBUG - 2016-09-28 18:39:48 --> No URI present. Default controller set.
DEBUG - 2016-09-28 18:39:48 --> Output Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:39:48 --> Security Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Input Class Initialized
DEBUG - 2016-09-28 18:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:39:48 --> Language Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Loader Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:39:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:39:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:39:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:39:49 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Session Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:39:49 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:39:49 --> A session cookie was not found.
DEBUG - 2016-09-28 18:39:49 --> Session routines successfully run
DEBUG - 2016-09-28 18:39:49 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:39:49 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:39:49 --> Controller Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:39:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:39:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:39:49 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:49 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:49 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:49 --> Model Class Initialized
ERROR - 2016-09-28 18:39:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:39:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-28 18:39:49 --> Final output sent to browser
DEBUG - 2016-09-28 18:39:49 --> Total execution time: 0.9921
DEBUG - 2016-09-28 18:39:50 --> Config Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:39:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:39:50 --> URI Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Router Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Output Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:39:50 --> Security Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Input Class Initialized
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:39:50 --> Language Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Loader Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:39:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:39:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:39:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:39:50 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Session Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:39:50 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:39:50 --> Session routines successfully run
DEBUG - 2016-09-28 18:39:50 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:39:50 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:39:50 --> Controller Class Initialized
DEBUG - 2016-09-28 18:39:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:39:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:39:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:39:50 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:50 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:51 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-28 18:39:51 --> Final output sent to browser
DEBUG - 2016-09-28 18:39:51 --> Total execution time: 0.9117
DEBUG - 2016-09-28 18:39:55 --> Config Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:39:55 --> URI Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Router Class Initialized
DEBUG - 2016-09-28 18:39:55 --> No URI present. Default controller set.
DEBUG - 2016-09-28 18:39:55 --> Output Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:39:55 --> Security Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Input Class Initialized
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:39:55 --> Language Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Loader Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:39:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:39:55 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Session Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:39:55 --> Session routines successfully run
DEBUG - 2016-09-28 18:39:55 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:39:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:39:55 --> Controller Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:39:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:39:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:39:55 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:55 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:55 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
ERROR - 2016-09-28 18:39:55 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:39:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-28 18:39:55 --> Final output sent to browser
DEBUG - 2016-09-28 18:39:55 --> Total execution time: 0.2008
DEBUG - 2016-09-28 18:39:55 --> Config Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:39:55 --> URI Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Router Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Output Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:39:55 --> Security Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Input Class Initialized
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:39:55 --> Language Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Loader Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:39:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:39:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:39:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:39:55 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Session Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:39:55 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:39:55 --> Session routines successfully run
DEBUG - 2016-09-28 18:39:55 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:39:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:39:55 --> Controller Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:39:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:39:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:39:55 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:55 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:55 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-28 18:39:55 --> Final output sent to browser
DEBUG - 2016-09-28 18:39:55 --> Total execution time: 0.2536
DEBUG - 2016-09-28 18:39:57 --> Config Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:39:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:39:57 --> URI Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Router Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Output Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:39:57 --> Security Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Input Class Initialized
DEBUG - 2016-09-28 18:39:57 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:57 --> XSS Filtering completed
DEBUG - 2016-09-28 18:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:39:57 --> Language Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Loader Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:39:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:39:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:39:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:39:57 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Session Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:39:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:39:57 --> Session routines successfully run
DEBUG - 2016-09-28 18:39:57 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:39:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:39:57 --> Controller Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:39:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:39:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:39:57 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:57 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:39:57 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:57 --> Model Class Initialized
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:39:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:39:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-28 18:39:57 --> Final output sent to browser
DEBUG - 2016-09-28 18:39:57 --> Total execution time: 0.2844
DEBUG - 2016-09-28 18:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:06 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:06 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:06 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:06 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:06 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:06 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:06 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:06 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:06 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:06 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:06 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:06 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:06 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Model Class Initialized
ERROR - 2016-09-28 18:40:06 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-28 18:40:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-28 18:40:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-28 18:40:06 --> Final output sent to browser
DEBUG - 2016-09-28 18:40:06 --> Total execution time: 0.3832
DEBUG - 2016-09-28 18:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:06 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:06 --> Router Class Initialized
ERROR - 2016-09-28 18:40:06 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-28 18:40:38 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:38 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:40:38 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:38 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:39 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:39 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:39 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:39 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:39 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:39 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:39 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
ERROR - 2016-09-28 18:40:39 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 18:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:39 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-28 18:40:39 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:39 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:39 --> No URI present. Default controller set.
DEBUG - 2016-09-28 18:40:39 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:40:39 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:39 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:39 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:39 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:39 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:39 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:39 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:39 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:39 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Model Class Initialized
ERROR - 2016-09-28 18:40:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 18:40:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-28 18:40:39 --> Final output sent to browser
DEBUG - 2016-09-28 18:40:39 --> Total execution time: 0.2858
DEBUG - 2016-09-28 18:40:39 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:39 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:40:39 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:39 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:39 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:40 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:40 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:40 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:40 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:40 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:40 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:40 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:40 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-28 18:40:40 --> Final output sent to browser
DEBUG - 2016-09-28 18:40:40 --> Total execution time: 0.3516
DEBUG - 2016-09-28 18:40:43 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:43 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:40:43 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:43 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:43 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:43 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:43 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:43 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:43 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:43 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:43 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:43 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:43 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:43 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:43 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:43 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:40:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-28 18:40:43 --> Final output sent to browser
DEBUG - 2016-09-28 18:40:43 --> Total execution time: 0.3157
DEBUG - 2016-09-28 18:40:49 --> Config Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:40:49 --> URI Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Router Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Output Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:40:49 --> Security Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Input Class Initialized
DEBUG - 2016-09-28 18:40:49 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:49 --> XSS Filtering completed
DEBUG - 2016-09-28 18:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:40:49 --> Language Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Loader Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:40:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:40:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:40:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:40:49 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Session Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:40:49 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:40:49 --> Session routines successfully run
DEBUG - 2016-09-28 18:40:49 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:40:49 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:40:49 --> Controller Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:40:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:40:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:40:49 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:49 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:40:49 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Model Class Initialized
DEBUG - 2016-09-28 18:40:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-28 18:40:49 --> Pagination Class Initialized
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:40:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:40:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-28 18:40:49 --> Final output sent to browser
DEBUG - 2016-09-28 18:40:49 --> Total execution time: 0.5505
DEBUG - 2016-09-28 18:41:13 --> Config Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:41:13 --> URI Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Router Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Output Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Security Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Input Class Initialized
DEBUG - 2016-09-28 18:41:13 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:13 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:41:13 --> Language Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Loader Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:41:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:41:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:41:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:41:13 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Session Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:41:13 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:41:13 --> Session routines successfully run
DEBUG - 2016-09-28 18:41:13 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:41:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:41:13 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:41:14 --> Controller Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:41:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:41:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:41:14 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:14 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:14 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:41:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/37bfe9d383fa3714edfd5c3493032fc5
DEBUG - 2016-09-28 18:41:14 --> Final output sent to browser
DEBUG - 2016-09-28 18:41:14 --> Total execution time: 0.4952
DEBUG - 2016-09-28 18:41:35 --> Config Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:41:35 --> URI Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Router Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Output Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:41:35 --> Security Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Input Class Initialized
DEBUG - 2016-09-28 18:41:35 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:35 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:41:35 --> Language Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Loader Class Initialized
DEBUG - 2016-09-28 18:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:41:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:41:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:41:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:41:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:41:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:41:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:41:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:41:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:41:36 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Session Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:41:36 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:41:36 --> Session routines successfully run
DEBUG - 2016-09-28 18:41:36 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:41:36 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:41:36 --> Controller Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:41:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:41:36 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:36 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:36 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-28 18:41:36 --> Pagination Class Initialized
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:41:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-28 18:41:36 --> Final output sent to browser
DEBUG - 2016-09-28 18:41:36 --> Total execution time: 0.6015
DEBUG - 2016-09-28 18:41:49 --> Config Class Initialized
DEBUG - 2016-09-28 18:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:41:49 --> URI Class Initialized
DEBUG - 2016-09-28 18:41:49 --> Router Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Output Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Security Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Input Class Initialized
DEBUG - 2016-09-28 18:41:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:50 --> XSS Filtering completed
DEBUG - 2016-09-28 18:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:41:50 --> Language Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Loader Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:41:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:41:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:41:50 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Session Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:41:50 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:41:50 --> Session routines successfully run
DEBUG - 2016-09-28 18:41:50 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:41:50 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:41:50 --> Controller Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:41:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:41:50 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:50 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:41:50 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
DEBUG - 2016-09-28 18:41:50 --> Model Class Initialized
ERROR - 2016-09-28 18:41:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-09-28 18:47:46 --> Config Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:47:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:47:46 --> URI Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Router Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Output Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:47:46 --> Security Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Input Class Initialized
DEBUG - 2016-09-28 18:47:46 --> XSS Filtering completed
DEBUG - 2016-09-28 18:47:46 --> XSS Filtering completed
DEBUG - 2016-09-28 18:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:47:46 --> Language Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Loader Class Initialized
DEBUG - 2016-09-28 18:47:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:47:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:47:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:47:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:47:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:47:46 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:47:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:47:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:47:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:47:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:47:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:47:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:47:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:47:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:47:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:47:47 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Session Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:47:47 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:47:47 --> Session routines successfully run
DEBUG - 2016-09-28 18:47:47 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:47:47 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:47:47 --> Controller Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:47:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:47:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:47:47 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:47:47 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:47:47 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Model Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Model Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Model Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Model Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Model Class Initialized
DEBUG - 2016-09-28 18:47:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-28 18:47:47 --> Pagination Class Initialized
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/index.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:47:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:47:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bc71e124988d1eb532a929fcbfe4318b
DEBUG - 2016-09-28 18:47:47 --> Final output sent to browser
DEBUG - 2016-09-28 18:47:47 --> Total execution time: 0.5301
DEBUG - 2016-09-28 18:48:16 --> Config Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:48:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:48:16 --> URI Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Router Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Output Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 18:48:16 --> Security Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Input Class Initialized
DEBUG - 2016-09-28 18:48:16 --> XSS Filtering completed
DEBUG - 2016-09-28 18:48:16 --> XSS Filtering completed
DEBUG - 2016-09-28 18:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:48:16 --> Language Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Loader Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 18:48:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: common_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: security_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 18:48:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 18:48:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 18:48:16 --> Database Driver Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Session Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 18:48:16 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:48:16 --> Session routines successfully run
DEBUG - 2016-09-28 18:48:16 --> Native_session Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 18:48:16 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 18:48:16 --> Controller Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 18:48:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 18:48:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 18:48:16 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:48:16 --> Carabiner: library configured.
DEBUG - 2016-09-28 18:48:16 --> User Agent Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-28 18:48:16 --> Model Class Initialized
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/detail.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/detail_js.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/detail_js.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 18:48:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-28 18:48:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d1b0710b3157b8b9a8cd42211299f307
DEBUG - 2016-09-28 18:48:16 --> Final output sent to browser
DEBUG - 2016-09-28 18:48:16 --> Total execution time: 0.4911
DEBUG - 2016-09-28 21:36:59 --> Config Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 21:36:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 21:36:59 --> URI Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Router Class Initialized
DEBUG - 2016-09-28 21:36:59 --> No URI present. Default controller set.
DEBUG - 2016-09-28 21:36:59 --> Output Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 21:36:59 --> Security Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Input Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 21:36:59 --> Language Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Loader Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 21:36:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: url_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: file_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: common_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: common_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: form_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: security_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 21:36:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 21:36:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 21:36:59 --> Database Driver Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Session Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 21:36:59 --> Helper loaded: string_helper
DEBUG - 2016-09-28 21:36:59 --> A session cookie was not found.
DEBUG - 2016-09-28 21:36:59 --> Session routines successfully run
DEBUG - 2016-09-28 21:36:59 --> Native_session Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 21:36:59 --> Form Validation Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Form Validation Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 21:36:59 --> Controller Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 21:36:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 21:36:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 21:36:59 --> Carabiner: library configured.
DEBUG - 2016-09-28 21:36:59 --> Carabiner: library configured.
DEBUG - 2016-09-28 21:36:59 --> User Agent Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Model Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Model Class Initialized
DEBUG - 2016-09-28 21:36:59 --> Model Class Initialized
ERROR - 2016-09-28 21:36:59 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-28 21:36:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-28 21:36:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-28 21:36:59 --> Final output sent to browser
DEBUG - 2016-09-28 21:36:59 --> Total execution time: 0.4625
DEBUG - 2016-09-28 21:37:00 --> Config Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 21:37:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 21:37:00 --> URI Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Router Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Output Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-28 21:37:00 --> Security Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Input Class Initialized
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> XSS Filtering completed
DEBUG - 2016-09-28 21:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 21:37:00 --> Language Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Loader Class Initialized
DEBUG - 2016-09-28 21:37:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-28 21:37:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: url_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: file_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 21:37:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-28 21:37:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-28 21:37:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: common_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: common_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: form_helper
DEBUG - 2016-09-28 21:37:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-28 21:37:00 --> Helper loaded: security_helper
DEBUG - 2016-09-28 21:37:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-28 21:37:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-28 21:37:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-28 21:37:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-28 21:37:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-28 21:37:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-28 21:37:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-28 21:37:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-28 21:37:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-28 21:37:01 --> Database Driver Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Session Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-28 21:37:01 --> Helper loaded: string_helper
DEBUG - 2016-09-28 21:37:01 --> Session routines successfully run
DEBUG - 2016-09-28 21:37:01 --> Native_session Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-28 21:37:01 --> Form Validation Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Form Validation Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-28 21:37:01 --> Controller Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-28 21:37:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-28 21:37:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-28 21:37:01 --> Carabiner: library configured.
DEBUG - 2016-09-28 21:37:01 --> Carabiner: library configured.
DEBUG - 2016-09-28 21:37:01 --> User Agent Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Model Class Initialized
DEBUG - 2016-09-28 21:37:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-28 21:37:01 --> Final output sent to browser
DEBUG - 2016-09-28 21:37:01 --> Total execution time: 0.5574
