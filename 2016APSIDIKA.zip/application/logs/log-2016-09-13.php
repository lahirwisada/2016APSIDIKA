<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-13 10:55:37 --> Config Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 10:55:37 --> URI Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Router Class Initialized
DEBUG - 2016-09-13 10:55:37 --> No URI present. Default controller set.
DEBUG - 2016-09-13 10:55:37 --> Output Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Security Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Input Class Initialized
DEBUG - 2016-09-13 10:55:37 --> XSS Filtering completed
DEBUG - 2016-09-13 10:55:37 --> XSS Filtering completed
DEBUG - 2016-09-13 10:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 10:55:37 --> Language Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Loader Class Initialized
DEBUG - 2016-09-13 10:55:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 10:55:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: url_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: file_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: form_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: security_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 10:55:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 10:55:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 10:55:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 10:55:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 10:55:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 10:55:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 10:55:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 10:55:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 10:55:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 10:55:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 10:55:38 --> Session Class Initialized
DEBUG - 2016-09-13 10:55:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 10:55:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 10:55:38 --> A session cookie was not found.
DEBUG - 2016-09-13 10:55:38 --> Session routines successfully run
DEBUG - 2016-09-13 10:55:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 10:55:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 10:55:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 10:55:39 --> Controller Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 10:55:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 10:55:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 10:55:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 10:55:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 10:55:39 --> User Agent Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Model Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Model Class Initialized
DEBUG - 2016-09-13 10:55:39 --> Model Class Initialized
ERROR - 2016-09-13 10:55:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 10:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 10:55:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 10:55:43 --> Final output sent to browser
DEBUG - 2016-09-13 10:55:43 --> Total execution time: 5.8261
DEBUG - 2016-09-13 10:58:49 --> Config Class Initialized
DEBUG - 2016-09-13 10:58:49 --> Hooks Class Initialized
DEBUG - 2016-09-13 10:58:49 --> Utf8 Class Initialized
DEBUG - 2016-09-13 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 10:58:49 --> URI Class Initialized
DEBUG - 2016-09-13 10:58:49 --> Router Class Initialized
DEBUG - 2016-09-13 10:58:49 --> No URI present. Default controller set.
DEBUG - 2016-09-13 10:58:49 --> Output Class Initialized
DEBUG - 2016-09-13 10:58:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 10:58:49 --> Security Class Initialized
DEBUG - 2016-09-13 10:58:49 --> Input Class Initialized
DEBUG - 2016-09-13 10:58:49 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:49 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:49 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 10:58:49 --> Language Class Initialized
ERROR - 2016-09-13 10:58:49 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 10:58:54 --> Config Class Initialized
DEBUG - 2016-09-13 10:58:54 --> Hooks Class Initialized
DEBUG - 2016-09-13 10:58:54 --> Utf8 Class Initialized
DEBUG - 2016-09-13 10:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 10:58:54 --> URI Class Initialized
DEBUG - 2016-09-13 10:58:54 --> Router Class Initialized
DEBUG - 2016-09-13 10:58:54 --> No URI present. Default controller set.
DEBUG - 2016-09-13 10:58:54 --> Output Class Initialized
DEBUG - 2016-09-13 10:58:54 --> Security Class Initialized
DEBUG - 2016-09-13 10:58:54 --> Input Class Initialized
DEBUG - 2016-09-13 10:58:54 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:54 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:54 --> XSS Filtering completed
DEBUG - 2016-09-13 10:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 10:58:54 --> Language Class Initialized
ERROR - 2016-09-13 10:58:54 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 11:02:54 --> Config Class Initialized
DEBUG - 2016-09-13 11:02:54 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:02:54 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:02:54 --> URI Class Initialized
DEBUG - 2016-09-13 11:02:54 --> Router Class Initialized
DEBUG - 2016-09-13 11:02:54 --> No URI present. Default controller set.
DEBUG - 2016-09-13 11:02:54 --> Output Class Initialized
DEBUG - 2016-09-13 11:02:54 --> Security Class Initialized
DEBUG - 2016-09-13 11:02:54 --> Input Class Initialized
DEBUG - 2016-09-13 11:02:54 --> XSS Filtering completed
DEBUG - 2016-09-13 11:02:54 --> XSS Filtering completed
DEBUG - 2016-09-13 11:02:54 --> XSS Filtering completed
DEBUG - 2016-09-13 11:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:02:54 --> Language Class Initialized
ERROR - 2016-09-13 11:02:54 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 11:04:36 --> Config Class Initialized
DEBUG - 2016-09-13 11:04:36 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:04:36 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:04:36 --> URI Class Initialized
DEBUG - 2016-09-13 11:04:36 --> Router Class Initialized
DEBUG - 2016-09-13 11:04:36 --> No URI present. Default controller set.
DEBUG - 2016-09-13 11:04:36 --> Output Class Initialized
DEBUG - 2016-09-13 11:04:36 --> Security Class Initialized
DEBUG - 2016-09-13 11:04:36 --> Input Class Initialized
DEBUG - 2016-09-13 11:04:36 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:36 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:36 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:04:36 --> Language Class Initialized
ERROR - 2016-09-13 11:04:36 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 11:04:46 --> Config Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:04:46 --> URI Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Router Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Output Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:04:46 --> Security Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Input Class Initialized
DEBUG - 2016-09-13 11:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 11:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:04:46 --> Language Class Initialized
ERROR - 2016-09-13 11:04:46 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 11:04:46 --> Config Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:04:46 --> URI Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Router Class Initialized
ERROR - 2016-09-13 11:04:46 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 11:04:46 --> Config Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:04:46 --> URI Class Initialized
DEBUG - 2016-09-13 11:04:46 --> Router Class Initialized
ERROR - 2016-09-13 11:04:46 --> 404 Page Not Found --> front_end/favicon.ico
DEBUG - 2016-09-13 11:05:04 --> Config Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:05:04 --> URI Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Router Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Output Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Security Class Initialized
DEBUG - 2016-09-13 11:05:04 --> Input Class Initialized
DEBUG - 2016-09-13 11:05:04 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:04 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:04 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:05:04 --> Language Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Config Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:05:32 --> URI Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Router Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Output Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Security Class Initialized
DEBUG - 2016-09-13 11:05:32 --> Input Class Initialized
DEBUG - 2016-09-13 11:05:32 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:32 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:32 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:05:32 --> Language Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Config Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:05:39 --> URI Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Router Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Output Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Security Class Initialized
DEBUG - 2016-09-13 11:05:39 --> Input Class Initialized
DEBUG - 2016-09-13 11:05:39 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:39 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:39 --> XSS Filtering completed
DEBUG - 2016-09-13 11:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:05:39 --> Language Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Config Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:08:00 --> URI Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Router Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Output Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Security Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Input Class Initialized
DEBUG - 2016-09-13 11:08:00 --> XSS Filtering completed
DEBUG - 2016-09-13 11:08:00 --> XSS Filtering completed
DEBUG - 2016-09-13 11:08:00 --> XSS Filtering completed
DEBUG - 2016-09-13 11:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:08:00 --> Language Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Loader Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:08:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:08:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:08:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:08:00 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Session Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:08:00 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:08:00 --> Session routines successfully run
DEBUG - 2016-09-13 11:08:00 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:08:00 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:08:00 --> Controller Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:08:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:08:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:08:00 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:08:00 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:08:00 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Model Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Model Class Initialized
DEBUG - 2016-09-13 11:08:00 --> Model Class Initialized
ERROR - 2016-09-13 11:08:00 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:08:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:08:00 --> Final output sent to browser
DEBUG - 2016-09-13 11:08:00 --> Total execution time: 0.2153
DEBUG - 2016-09-13 11:09:05 --> Config Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:09:05 --> URI Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Router Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Output Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:09:05 --> Security Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Input Class Initialized
DEBUG - 2016-09-13 11:09:05 --> XSS Filtering completed
DEBUG - 2016-09-13 11:09:05 --> XSS Filtering completed
DEBUG - 2016-09-13 11:09:05 --> XSS Filtering completed
DEBUG - 2016-09-13 11:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:09:05 --> Language Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Loader Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:09:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:09:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:09:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:09:05 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Session Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:09:05 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:09:05 --> Session routines successfully run
DEBUG - 2016-09-13 11:09:05 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:09:05 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:09:05 --> Controller Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:09:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:09:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:09:05 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:09:05 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:09:05 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Model Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Model Class Initialized
DEBUG - 2016-09-13 11:09:05 --> Model Class Initialized
ERROR - 2016-09-13 11:09:05 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:09:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:09:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:09:05 --> Final output sent to browser
DEBUG - 2016-09-13 11:09:05 --> Total execution time: 0.2131
DEBUG - 2016-09-13 11:16:07 --> Config Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:16:07 --> URI Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Router Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Output Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:16:07 --> Security Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Input Class Initialized
DEBUG - 2016-09-13 11:16:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:16:07 --> Language Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Loader Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:16:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:16:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:16:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:16:07 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Session Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:16:07 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:16:07 --> Session routines successfully run
DEBUG - 2016-09-13 11:16:07 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:16:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:16:07 --> Controller Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:16:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:16:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:16:07 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Model Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Model Class Initialized
DEBUG - 2016-09-13 11:16:07 --> Model Class Initialized
ERROR - 2016-09-13 11:16:07 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:16:41 --> Config Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:16:41 --> URI Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Router Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Output Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Security Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Input Class Initialized
DEBUG - 2016-09-13 11:16:41 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:41 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:41 --> XSS Filtering completed
DEBUG - 2016-09-13 11:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:16:41 --> Language Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Loader Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:16:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:16:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:16:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:16:41 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Session Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:16:41 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:16:41 --> Session routines successfully run
DEBUG - 2016-09-13 11:16:41 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:16:41 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:16:41 --> Controller Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:16:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:16:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:16:41 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:16:41 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:16:41 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Model Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Model Class Initialized
DEBUG - 2016-09-13 11:16:41 --> Model Class Initialized
ERROR - 2016-09-13 11:16:41 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:16:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:16:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:16:41 --> Final output sent to browser
DEBUG - 2016-09-13 11:16:41 --> Total execution time: 0.2373
DEBUG - 2016-09-13 11:20:06 --> Config Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:20:06 --> URI Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Router Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Output Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:20:06 --> Security Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Input Class Initialized
DEBUG - 2016-09-13 11:20:06 --> XSS Filtering completed
DEBUG - 2016-09-13 11:20:06 --> XSS Filtering completed
DEBUG - 2016-09-13 11:20:06 --> XSS Filtering completed
DEBUG - 2016-09-13 11:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:20:06 --> Language Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Loader Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:20:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:20:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:20:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:20:06 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Session Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:20:06 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:20:06 --> Session routines successfully run
DEBUG - 2016-09-13 11:20:06 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:20:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:20:06 --> Controller Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:20:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:20:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:20:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:20:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:20:06 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Model Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Model Class Initialized
DEBUG - 2016-09-13 11:20:06 --> Model Class Initialized
ERROR - 2016-09-13 11:20:06 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:20:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:20:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:20:06 --> Final output sent to browser
DEBUG - 2016-09-13 11:20:06 --> Total execution time: 0.2741
DEBUG - 2016-09-13 11:22:55 --> Config Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:22:55 --> URI Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Router Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Output Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:22:55 --> Security Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Input Class Initialized
DEBUG - 2016-09-13 11:22:55 --> XSS Filtering completed
DEBUG - 2016-09-13 11:22:55 --> XSS Filtering completed
DEBUG - 2016-09-13 11:22:55 --> XSS Filtering completed
DEBUG - 2016-09-13 11:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:22:55 --> Language Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Loader Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:22:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:22:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:22:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:22:55 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Session Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:22:55 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:22:55 --> Session routines successfully run
DEBUG - 2016-09-13 11:22:55 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:22:55 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:22:55 --> Controller Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:22:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:22:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:22:55 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:22:55 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:22:55 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Model Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Model Class Initialized
DEBUG - 2016-09-13 11:22:55 --> Model Class Initialized
ERROR - 2016-09-13 11:22:55 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:22:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:22:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:22:55 --> Final output sent to browser
DEBUG - 2016-09-13 11:22:55 --> Total execution time: 0.2866
DEBUG - 2016-09-13 11:23:21 --> Config Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:23:21 --> URI Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Router Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Output Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:23:21 --> Security Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Input Class Initialized
DEBUG - 2016-09-13 11:23:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:23:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:23:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:23:21 --> Language Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Loader Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:23:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:23:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:23:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:23:21 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Session Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:23:21 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:23:21 --> Session routines successfully run
DEBUG - 2016-09-13 11:23:21 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:23:21 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:23:21 --> Controller Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:23:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:23:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:23:21 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:23:21 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:23:21 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Model Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Model Class Initialized
DEBUG - 2016-09-13 11:23:21 --> Model Class Initialized
ERROR - 2016-09-13 11:23:21 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:23:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:23:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:23:21 --> Final output sent to browser
DEBUG - 2016-09-13 11:23:21 --> Total execution time: 0.3100
DEBUG - 2016-09-13 11:26:07 --> Config Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:26:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:26:07 --> URI Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Router Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Output Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:26:07 --> Security Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Input Class Initialized
DEBUG - 2016-09-13 11:26:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:26:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:26:07 --> XSS Filtering completed
DEBUG - 2016-09-13 11:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:26:07 --> Language Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Loader Class Initialized
DEBUG - 2016-09-13 11:26:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:26:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:26:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:26:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:26:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:26:07 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Session Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:26:08 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:26:08 --> Session routines successfully run
DEBUG - 2016-09-13 11:26:08 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:26:08 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:26:08 --> Controller Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:26:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:26:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:26:08 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:26:08 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:26:08 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Model Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Model Class Initialized
DEBUG - 2016-09-13 11:26:08 --> Model Class Initialized
ERROR - 2016-09-13 11:26:08 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:26:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:26:08 --> Final output sent to browser
DEBUG - 2016-09-13 11:26:08 --> Total execution time: 0.3108
DEBUG - 2016-09-13 11:28:21 --> Config Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:28:21 --> URI Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Router Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Output Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:28:21 --> Security Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Input Class Initialized
DEBUG - 2016-09-13 11:28:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:21 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:28:21 --> Language Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Loader Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:28:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:28:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:28:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:28:21 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Session Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:28:21 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:28:21 --> Session routines successfully run
DEBUG - 2016-09-13 11:28:21 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:28:21 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:28:21 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:28:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:28:22 --> Controller Class Initialized
DEBUG - 2016-09-13 11:28:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:28:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:28:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:28:22 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:28:22 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:28:22 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:28:22 --> Model Class Initialized
DEBUG - 2016-09-13 11:28:22 --> Model Class Initialized
DEBUG - 2016-09-13 11:28:22 --> Model Class Initialized
ERROR - 2016-09-13 11:28:22 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:28:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:28:22 --> Final output sent to browser
DEBUG - 2016-09-13 11:28:22 --> Total execution time: 0.3345
DEBUG - 2016-09-13 11:28:23 --> Config Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:28:23 --> URI Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Router Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Output Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:28:23 --> Security Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Input Class Initialized
DEBUG - 2016-09-13 11:28:23 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:23 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:23 --> XSS Filtering completed
DEBUG - 2016-09-13 11:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:28:23 --> Language Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Loader Class Initialized
DEBUG - 2016-09-13 11:28:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:28:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:28:23 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:28:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:28:23 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:28:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:28:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:28:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:28:24 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Session Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:28:24 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:28:24 --> Session routines successfully run
DEBUG - 2016-09-13 11:28:24 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:28:24 --> Controller Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:28:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:28:24 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Model Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Model Class Initialized
DEBUG - 2016-09-13 11:28:24 --> Model Class Initialized
ERROR - 2016-09-13 11:28:24 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:28:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:28:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:28:24 --> Final output sent to browser
DEBUG - 2016-09-13 11:28:24 --> Total execution time: 0.3558
DEBUG - 2016-09-13 11:30:29 --> Config Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Hooks Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Utf8 Class Initialized
DEBUG - 2016-09-13 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 11:30:29 --> URI Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Router Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Output Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 11:30:29 --> Security Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Input Class Initialized
DEBUG - 2016-09-13 11:30:29 --> XSS Filtering completed
DEBUG - 2016-09-13 11:30:29 --> XSS Filtering completed
DEBUG - 2016-09-13 11:30:29 --> XSS Filtering completed
DEBUG - 2016-09-13 11:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 11:30:29 --> Language Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Loader Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 11:30:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: url_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: file_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: common_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: form_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: security_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 11:30:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 11:30:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 11:30:29 --> Database Driver Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Session Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 11:30:29 --> Helper loaded: string_helper
DEBUG - 2016-09-13 11:30:29 --> Session routines successfully run
DEBUG - 2016-09-13 11:30:29 --> Native_session Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 11:30:29 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Form Validation Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 11:30:29 --> Controller Class Initialized
DEBUG - 2016-09-13 11:30:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 11:30:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 11:30:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 11:30:30 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:30:30 --> Carabiner: library configured.
DEBUG - 2016-09-13 11:30:30 --> User Agent Class Initialized
DEBUG - 2016-09-13 11:30:30 --> Model Class Initialized
DEBUG - 2016-09-13 11:30:30 --> Model Class Initialized
DEBUG - 2016-09-13 11:30:30 --> Model Class Initialized
ERROR - 2016-09-13 11:30:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 11:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 11:30:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-13 11:30:30 --> Final output sent to browser
DEBUG - 2016-09-13 11:30:30 --> Total execution time: 0.3713
DEBUG - 2016-09-13 12:31:34 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:34 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Router Class Initialized
DEBUG - 2016-09-13 12:31:34 --> No URI present. Default controller set.
DEBUG - 2016-09-13 12:31:34 --> Output Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Security Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Input Class Initialized
DEBUG - 2016-09-13 12:31:34 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:31:34 --> Language Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Loader Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:31:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:31:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:31:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:31:34 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Session Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:31:34 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:31:34 --> Session routines successfully run
DEBUG - 2016-09-13 12:31:34 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:31:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:31:34 --> Controller Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:31:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:31:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:31:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:34 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:34 --> Model Class Initialized
ERROR - 2016-09-13 12:31:34 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:31:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 12:31:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 12:31:34 --> Final output sent to browser
DEBUG - 2016-09-13 12:31:34 --> Total execution time: 0.3745
DEBUG - 2016-09-13 12:31:38 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:38 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Router Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Output Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Security Class Initialized
DEBUG - 2016-09-13 12:31:38 --> Input Class Initialized
DEBUG - 2016-09-13 12:31:38 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:38 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:31:38 --> Language Class Initialized
ERROR - 2016-09-13 12:31:38 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 12:31:39 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:39 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Router Class Initialized
ERROR - 2016-09-13 12:31:39 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 12:31:39 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:39 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:39 --> Router Class Initialized
ERROR - 2016-09-13 12:31:39 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-13 12:31:48 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:48 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Router Class Initialized
ERROR - 2016-09-13 12:31:48 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-09-13 12:31:48 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:48 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Router Class Initialized
ERROR - 2016-09-13 12:31:48 --> 404 Page Not Found --> back_end/img
DEBUG - 2016-09-13 12:31:48 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:48 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:48 --> Router Class Initialized
ERROR - 2016-09-13 12:31:48 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-09-13 12:31:51 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:51 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Router Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Output Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Security Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Input Class Initialized
DEBUG - 2016-09-13 12:31:51 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:51 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:31:51 --> Language Class Initialized
ERROR - 2016-09-13 12:31:51 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 12:31:51 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:51 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:51 --> Router Class Initialized
ERROR - 2016-09-13 12:31:51 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 12:31:56 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:56 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Router Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Output Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:31:56 --> Security Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Input Class Initialized
DEBUG - 2016-09-13 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:31:56 --> Language Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Loader Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:31:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:31:56 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Session Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:31:56 --> Session routines successfully run
DEBUG - 2016-09-13 12:31:56 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:31:56 --> Controller Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:31:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:56 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Model Class Initialized
ERROR - 2016-09-13 12:31:56 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 12:31:56 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:56 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Router Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Output Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Security Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Input Class Initialized
DEBUG - 2016-09-13 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-13 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:31:56 --> Language Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Loader Class Initialized
DEBUG - 2016-09-13 12:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:31:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:31:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:31:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:31:56 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Session Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:31:57 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:31:57 --> Session routines successfully run
DEBUG - 2016-09-13 12:31:57 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:31:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:31:57 --> Controller Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:31:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:31:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:31:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:31:57 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
DEBUG - 2016-09-13 12:31:57 --> Model Class Initialized
ERROR - 2016-09-13 12:31:57 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 12:31:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 12:31:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-13 12:31:57 --> Final output sent to browser
DEBUG - 2016-09-13 12:31:57 --> Total execution time: 0.4449
DEBUG - 2016-09-13 12:31:58 --> Config Class Initialized
DEBUG - 2016-09-13 12:31:58 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:31:58 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:31:58 --> URI Class Initialized
DEBUG - 2016-09-13 12:31:58 --> Router Class Initialized
ERROR - 2016-09-13 12:31:58 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-13 12:32:03 --> Config Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:32:03 --> URI Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Router Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Output Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:32:03 --> Security Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Input Class Initialized
DEBUG - 2016-09-13 12:32:03 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:03 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:03 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:03 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:32:03 --> Language Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Loader Class Initialized
DEBUG - 2016-09-13 12:32:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:32:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:32:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:32:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:32:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:32:03 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Session Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:32:04 --> Session routines successfully run
DEBUG - 2016-09-13 12:32:04 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:32:04 --> Controller Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:32:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:32:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:04 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
ERROR - 2016-09-13 12:32:04 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 12:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-13 12:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:32:04 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-13 12:32:04 --> Config Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:32:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:32:04 --> URI Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Router Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Output Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Security Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Input Class Initialized
DEBUG - 2016-09-13 12:32:04 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:04 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:32:04 --> Language Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Loader Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:32:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:32:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:32:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:32:04 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Session Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:32:04 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:32:04 --> Session routines successfully run
DEBUG - 2016-09-13 12:32:04 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:32:04 --> Controller Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:32:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:32:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:04 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:04 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 12:32:05 --> Pagination Class Initialized
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:32:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:32:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-13 12:32:05 --> Final output sent to browser
DEBUG - 2016-09-13 12:32:05 --> Total execution time: 0.8514
DEBUG - 2016-09-13 12:32:12 --> Config Class Initialized
DEBUG - 2016-09-13 12:32:12 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:32:12 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:32:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:32:12 --> URI Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Router Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Output Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:32:13 --> Security Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Input Class Initialized
DEBUG - 2016-09-13 12:32:13 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:13 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:13 --> XSS Filtering completed
DEBUG - 2016-09-13 12:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:32:13 --> Language Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Loader Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:32:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:32:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:32:13 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Session Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:32:13 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:32:13 --> Session routines successfully run
DEBUG - 2016-09-13 12:32:13 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:32:13 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:32:13 --> Controller Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:32:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:32:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:32:13 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:13 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:32:13 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Model Class Initialized
DEBUG - 2016-09-13 12:32:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 12:32:13 --> Pagination Class Initialized
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:32:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:32:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-13 12:32:13 --> Final output sent to browser
DEBUG - 2016-09-13 12:32:13 --> Total execution time: 0.6033
DEBUG - 2016-09-13 12:35:30 --> Config Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:35:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:35:30 --> URI Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Router Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Output Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:35:30 --> Security Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Input Class Initialized
DEBUG - 2016-09-13 12:35:30 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:30 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:35:30 --> Language Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Loader Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:35:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:35:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:35:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:35:30 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Session Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:35:30 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:35:30 --> Session routines successfully run
DEBUG - 2016-09-13 12:35:30 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:35:30 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:30 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:35:31 --> Controller Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:35:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:35:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:35:31 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:31 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:31 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 12:35:31 --> Pagination Class Initialized
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/index.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/57d0db215062cedca2b4c7c8b724c691
DEBUG - 2016-09-13 12:35:31 --> Final output sent to browser
DEBUG - 2016-09-13 12:35:31 --> Total execution time: 0.7111
DEBUG - 2016-09-13 12:35:37 --> Config Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:35:37 --> URI Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Router Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Output Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:35:37 --> Security Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Input Class Initialized
DEBUG - 2016-09-13 12:35:37 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:37 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:35:37 --> Language Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Loader Class Initialized
DEBUG - 2016-09-13 12:35:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:35:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:35:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:35:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:35:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:35:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:35:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:35:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Session Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:35:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:35:38 --> Session routines successfully run
DEBUG - 2016-09-13 12:35:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:35:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:35:38 --> Controller Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:35:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:35:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:35:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:38 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 12:35:38 --> Pagination Class Initialized
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2016-09-13 12:35:38 --> Final output sent to browser
DEBUG - 2016-09-13 12:35:38 --> Total execution time: 0.6102
DEBUG - 2016-09-13 12:35:45 --> Config Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Hooks Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Utf8 Class Initialized
DEBUG - 2016-09-13 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 12:35:45 --> URI Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Router Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Output Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 12:35:45 --> Security Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Input Class Initialized
DEBUG - 2016-09-13 12:35:45 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:45 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:45 --> XSS Filtering completed
DEBUG - 2016-09-13 12:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 12:35:45 --> Language Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Loader Class Initialized
DEBUG - 2016-09-13 12:35:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 12:35:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: url_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: file_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: common_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: form_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: security_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 12:35:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 12:35:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 12:35:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 12:35:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 12:35:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 12:35:46 --> Database Driver Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Session Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 12:35:46 --> Helper loaded: string_helper
DEBUG - 2016-09-13 12:35:46 --> Session routines successfully run
DEBUG - 2016-09-13 12:35:46 --> Native_session Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 12:35:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 12:35:46 --> Controller Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 12:35:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 12:35:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 12:35:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 12:35:46 --> User Agent Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Model Class Initialized
DEBUG - 2016-09-13 12:35:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 12:35:46 --> Pagination Class Initialized
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 12:35:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 12:35:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2016-09-13 12:35:46 --> Final output sent to browser
DEBUG - 2016-09-13 12:35:46 --> Total execution time: 0.6066
DEBUG - 2016-09-13 14:01:42 --> Config Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:01:42 --> URI Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Router Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Output Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Security Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Input Class Initialized
DEBUG - 2016-09-13 14:01:42 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:42 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:01:42 --> Language Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Loader Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:01:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:01:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:01:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:01:42 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Session Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:01:42 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:01:42 --> Session routines successfully run
DEBUG - 2016-09-13 14:01:42 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:01:42 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:01:42 --> Controller Class Initialized
DEBUG - 2016-09-13 14:01:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:01:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:01:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:43 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Config Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:01:43 --> URI Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Router Class Initialized
DEBUG - 2016-09-13 14:01:43 --> No URI present. Default controller set.
DEBUG - 2016-09-13 14:01:43 --> Output Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:01:43 --> Security Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Input Class Initialized
DEBUG - 2016-09-13 14:01:43 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:43 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:01:43 --> Language Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Loader Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:01:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:01:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:01:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:01:43 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Session Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:01:43 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:01:43 --> Session routines successfully run
DEBUG - 2016-09-13 14:01:43 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:01:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:01:43 --> Controller Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:01:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:43 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:43 --> Model Class Initialized
ERROR - 2016-09-13 14:01:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:01:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 14:01:43 --> Final output sent to browser
DEBUG - 2016-09-13 14:01:43 --> Total execution time: 0.5700
DEBUG - 2016-09-13 14:01:46 --> Config Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:01:46 --> URI Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Router Class Initialized
DEBUG - 2016-09-13 14:01:46 --> No URI present. Default controller set.
DEBUG - 2016-09-13 14:01:46 --> Output Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:01:46 --> Security Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Input Class Initialized
DEBUG - 2016-09-13 14:01:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:01:46 --> Language Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Loader Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:01:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:01:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:01:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:01:46 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Session Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:01:46 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:01:46 --> Session routines successfully run
DEBUG - 2016-09-13 14:01:46 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:01:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:01:46 --> Controller Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:01:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:01:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:01:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:01:46 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Model Class Initialized
ERROR - 2016-09-13 14:01:46 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:01:46 --> Config Class Initialized
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:01:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:01:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:01:46 --> URI Class Initialized
DEBUG - 2016-09-13 14:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:01:46 --> Router Class Initialized
DEBUG - 2016-09-13 14:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:01:47 --> Output Class Initialized
DEBUG - 2016-09-13 14:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:01:47 --> Security Class Initialized
DEBUG - 2016-09-13 14:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:01:47 --> Input Class Initialized
DEBUG - 2016-09-13 14:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:01:47 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:47 --> XSS Filtering completed
DEBUG - 2016-09-13 14:01:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 14:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:01:47 --> Final output sent to browser
DEBUG - 2016-09-13 14:01:47 --> Total execution time: 0.5899
DEBUG - 2016-09-13 14:01:47 --> Language Class Initialized
ERROR - 2016-09-13 14:01:47 --> 404 Page Not Found --> 
DEBUG - 2016-09-13 14:01:47 --> Config Class Initialized
DEBUG - 2016-09-13 14:01:47 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:01:47 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:01:47 --> URI Class Initialized
DEBUG - 2016-09-13 14:01:47 --> Router Class Initialized
ERROR - 2016-09-13 14:01:47 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 14:02:33 --> Config Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:02:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:02:33 --> URI Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Router Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Output Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Security Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Input Class Initialized
DEBUG - 2016-09-13 14:02:33 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:33 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:02:33 --> Language Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Loader Class Initialized
DEBUG - 2016-09-13 14:02:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:02:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:02:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:02:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:02:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:02:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:02:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:02:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:02:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:02:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:02:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:02:34 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Session Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:02:34 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:02:34 --> Session routines successfully run
DEBUG - 2016-09-13 14:02:34 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:02:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:02:34 --> Controller Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:02:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:02:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:02:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:34 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:02:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:02:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-13 14:02:34 --> Final output sent to browser
DEBUG - 2016-09-13 14:02:34 --> Total execution time: 0.6201
DEBUG - 2016-09-13 14:02:37 --> Config Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:02:37 --> URI Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Router Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Output Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:02:37 --> Security Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Input Class Initialized
DEBUG - 2016-09-13 14:02:37 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:37 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:02:37 --> Language Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Loader Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:02:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:02:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:02:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:02:37 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Session Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:02:37 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:02:37 --> Session routines successfully run
DEBUG - 2016-09-13 14:02:37 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:02:37 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:02:37 --> Controller Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:02:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:02:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:02:37 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:37 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:37 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:37 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
ERROR - 2016-09-13 14:02:38 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:02:38 --> Config Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:02:38 --> URI Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Router Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Output Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Security Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Input Class Initialized
DEBUG - 2016-09-13 14:02:38 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:38 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:02:38 --> Language Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Loader Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:02:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:02:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:02:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Session Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:02:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:02:38 --> Session routines successfully run
DEBUG - 2016-09-13 14:02:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:02:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:02:38 --> Controller Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:02:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:02:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:38 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:38 --> Model Class Initialized
ERROR - 2016-09-13 14:02:38 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 14:02:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 14:02:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-13 14:02:38 --> Final output sent to browser
DEBUG - 2016-09-13 14:02:38 --> Total execution time: 0.6768
DEBUG - 2016-09-13 14:02:42 --> Config Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:02:42 --> URI Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Router Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Output Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:02:42 --> Security Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Input Class Initialized
DEBUG - 2016-09-13 14:02:42 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:42 --> XSS Filtering completed
DEBUG - 2016-09-13 14:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:02:42 --> Language Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Loader Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:02:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:02:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:02:42 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Session Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:02:42 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:02:42 --> Session routines successfully run
DEBUG - 2016-09-13 14:02:42 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:02:42 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:02:42 --> Controller Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:02:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:02:42 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:42 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:02:42 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:42 --> Model Class Initialized
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:02:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-13 14:02:42 --> Final output sent to browser
DEBUG - 2016-09-13 14:02:42 --> Total execution time: 0.6390
DEBUG - 2016-09-13 14:03:03 --> Config Class Initialized
DEBUG - 2016-09-13 14:03:03 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:03:03 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:03:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:03:03 --> URI Class Initialized
DEBUG - 2016-09-13 14:03:03 --> Router Class Initialized
DEBUG - 2016-09-13 14:03:03 --> No URI present. Default controller set.
DEBUG - 2016-09-13 14:03:03 --> Output Class Initialized
DEBUG - 2016-09-13 14:03:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:03:03 --> Security Class Initialized
DEBUG - 2016-09-13 14:03:03 --> Input Class Initialized
DEBUG - 2016-09-13 14:03:04 --> XSS Filtering completed
DEBUG - 2016-09-13 14:03:04 --> XSS Filtering completed
DEBUG - 2016-09-13 14:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:03:04 --> Language Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Loader Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:03:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:03:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:03:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:03:04 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Session Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:03:04 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:03:04 --> Session routines successfully run
DEBUG - 2016-09-13 14:03:04 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:03:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:03:04 --> Controller Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:03:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:03:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:03:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:03:04 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:03:04 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Model Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Model Class Initialized
DEBUG - 2016-09-13 14:03:04 --> Model Class Initialized
ERROR - 2016-09-13 14:03:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:03:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 14:03:04 --> Final output sent to browser
DEBUG - 2016-09-13 14:03:04 --> Total execution time: 0.6721
DEBUG - 2016-09-13 14:04:29 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:29 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:29 --> No URI present. Default controller set.
DEBUG - 2016-09-13 14:04:29 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:29 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:29 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:29 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:29 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:29 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:29 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:29 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:29 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:30 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:30 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:30 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:30 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:30 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:30 --> Model Class Initialized
ERROR - 2016-09-13 14:04:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:04:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 14:04:30 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:30 --> Total execution time: 0.7011
DEBUG - 2016-09-13 14:04:34 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:34 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:34 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:34 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:34 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:34 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:34 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:34 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:34 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:34 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:34 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:34 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:34 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:34 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-13 14:04:34 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:34 --> Total execution time: 0.6865
DEBUG - 2016-09-13 14:04:36 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:36 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:36 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:36 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:36 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:36 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:36 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:36 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:36 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:36 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:36 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:36 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:36 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:36 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:36 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:36 --> Model Class Initialized
ERROR - 2016-09-13 14:04:36 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-13 14:04:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-13 14:04:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-13 14:04:37 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:37 --> Total execution time: 0.8120
DEBUG - 2016-09-13 14:04:45 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:45 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:45 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:45 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:46 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:46 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:46 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:46 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:46 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:46 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:46 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Model Class Initialized
ERROR - 2016-09-13 14:04:46 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:04:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-13 14:04:46 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:46 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-13 14:04:46 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:46 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:46 --> No URI present. Default controller set.
DEBUG - 2016-09-13 14:04:46 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:46 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:46 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:46 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:47 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:47 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:47 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:47 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:47 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:47 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:47 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:47 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:47 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:47 --> Model Class Initialized
ERROR - 2016-09-13 14:04:47 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 14:04:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 14:04:47 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:47 --> Total execution time: 0.7645
DEBUG - 2016-09-13 14:04:50 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:50 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:50 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:50 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:50 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:50 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:50 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:50 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:50 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:50 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:51 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:51 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:51 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:51 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:51 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:51 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-13 14:04:51 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:51 --> Total execution time: 0.7576
DEBUG - 2016-09-13 14:04:54 --> Config Class Initialized
DEBUG - 2016-09-13 14:04:54 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:04:55 --> URI Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Router Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Output Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:04:55 --> Security Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Input Class Initialized
DEBUG - 2016-09-13 14:04:55 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:55 --> XSS Filtering completed
DEBUG - 2016-09-13 14:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:04:55 --> Language Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Loader Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:04:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:04:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:04:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:04:55 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Session Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:04:55 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:04:55 --> Session routines successfully run
DEBUG - 2016-09-13 14:04:55 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:04:55 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:04:55 --> Controller Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:04:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:04:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:04:55 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:55 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:04:55 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Model Class Initialized
DEBUG - 2016-09-13 14:04:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 14:04:55 --> Pagination Class Initialized
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:04:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:04:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 14:04:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:04:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:04:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2016-09-13 14:04:56 --> Final output sent to browser
DEBUG - 2016-09-13 14:04:56 --> Total execution time: 0.8676
DEBUG - 2016-09-13 14:05:00 --> Config Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:05:00 --> URI Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Router Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Output Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 14:05:00 --> Security Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Input Class Initialized
DEBUG - 2016-09-13 14:05:00 --> XSS Filtering completed
DEBUG - 2016-09-13 14:05:00 --> XSS Filtering completed
DEBUG - 2016-09-13 14:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:05:00 --> Language Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Loader Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:05:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:05:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:05:00 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Session Class Initialized
DEBUG - 2016-09-13 14:05:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:05:00 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:05:00 --> Session routines successfully run
DEBUG - 2016-09-13 14:05:00 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:05:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:05:01 --> Controller Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:05:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:05:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:05:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:05:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:05:01 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 14:05:01 --> Pagination Class Initialized
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/index.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/js/index_js.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/js/index_js.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:05:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/67a9fbaf55b76491201f96f5102e0b64
DEBUG - 2016-09-13 14:05:01 --> Final output sent to browser
DEBUG - 2016-09-13 14:05:01 --> Total execution time: 0.9075
DEBUG - 2016-09-13 14:05:06 --> Config Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Utf8 Class Initialized
DEBUG - 2016-09-13 14:05:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 14:05:06 --> URI Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Router Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Output Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Security Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Input Class Initialized
DEBUG - 2016-09-13 14:05:06 --> XSS Filtering completed
DEBUG - 2016-09-13 14:05:06 --> XSS Filtering completed
DEBUG - 2016-09-13 14:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 14:05:06 --> Language Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Loader Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 14:05:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: url_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: file_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: form_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: security_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 14:05:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 14:05:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 14:05:06 --> Database Driver Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Session Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 14:05:06 --> Helper loaded: string_helper
DEBUG - 2016-09-13 14:05:06 --> Session routines successfully run
DEBUG - 2016-09-13 14:05:06 --> Native_session Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 14:05:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 14:05:06 --> Controller Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 14:05:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 14:05:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 14:05:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:05:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 14:05:06 --> User Agent Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:06 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:07 --> Model Class Initialized
DEBUG - 2016-09-13 14:05:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 14:05:07 --> Pagination Class Initialized
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 14:05:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 14:05:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-09-13 14:05:07 --> Final output sent to browser
DEBUG - 2016-09-13 14:05:07 --> Total execution time: 0.8937
DEBUG - 2016-09-13 16:26:56 --> Config Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:26:56 --> URI Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Router Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Output Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 16:26:56 --> Security Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Input Class Initialized
DEBUG - 2016-09-13 16:26:56 --> XSS Filtering completed
DEBUG - 2016-09-13 16:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 16:26:56 --> Language Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Loader Class Initialized
DEBUG - 2016-09-13 16:26:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 16:26:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: url_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: file_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:26:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:26:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 16:26:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: form_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: security_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:26:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 16:26:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 16:26:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 16:26:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 16:26:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 16:26:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 16:26:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 16:26:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 16:26:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 16:26:57 --> Database Driver Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Session Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 16:26:57 --> Helper loaded: string_helper
DEBUG - 2016-09-13 16:26:57 --> A session cookie was not found.
DEBUG - 2016-09-13 16:26:57 --> Session routines successfully run
DEBUG - 2016-09-13 16:26:57 --> Native_session Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 16:26:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 16:26:57 --> Controller Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 16:26:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 16:26:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 16:26:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:26:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:26:57 --> User Agent Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Model Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Model Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Model Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Model Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Model Class Initialized
DEBUG - 2016-09-13 16:26:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 16:26:57 --> Pagination Class Initialized
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 16:26:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 16:26:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2016-09-13 16:26:57 --> Final output sent to browser
DEBUG - 2016-09-13 16:26:57 --> Total execution time: 0.9239
DEBUG - 2016-09-13 16:35:39 --> Config Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:35:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:35:39 --> URI Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Router Class Initialized
DEBUG - 2016-09-13 16:35:39 --> No URI present. Default controller set.
DEBUG - 2016-09-13 16:35:39 --> Output Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 16:35:39 --> Security Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Input Class Initialized
DEBUG - 2016-09-13 16:35:39 --> XSS Filtering completed
DEBUG - 2016-09-13 16:35:39 --> XSS Filtering completed
DEBUG - 2016-09-13 16:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 16:35:39 --> Language Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Loader Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 16:35:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: url_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: file_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: form_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: security_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 16:35:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 16:35:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 16:35:39 --> Database Driver Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Session Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 16:35:39 --> Helper loaded: string_helper
DEBUG - 2016-09-13 16:35:39 --> Session routines successfully run
DEBUG - 2016-09-13 16:35:39 --> Native_session Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 16:35:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 16:35:39 --> Controller Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 16:35:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 16:35:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 16:35:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:35:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:35:39 --> User Agent Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Model Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Model Class Initialized
DEBUG - 2016-09-13 16:35:39 --> Model Class Initialized
ERROR - 2016-09-13 16:35:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:35:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 16:35:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 16:35:40 --> Final output sent to browser
DEBUG - 2016-09-13 16:35:40 --> Total execution time: 0.8750
DEBUG - 2016-09-13 16:36:00 --> Config Class Initialized
DEBUG - 2016-09-13 16:36:00 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:36:00 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:36:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:36:00 --> URI Class Initialized
DEBUG - 2016-09-13 16:36:00 --> Router Class Initialized
ERROR - 2016-09-13 16:36:00 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:36:03 --> Config Class Initialized
DEBUG - 2016-09-13 16:36:03 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:36:03 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:36:03 --> URI Class Initialized
DEBUG - 2016-09-13 16:36:03 --> Router Class Initialized
ERROR - 2016-09-13 16:36:03 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:36:05 --> Config Class Initialized
DEBUG - 2016-09-13 16:36:05 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:36:05 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:36:05 --> URI Class Initialized
DEBUG - 2016-09-13 16:36:05 --> Router Class Initialized
ERROR - 2016-09-13 16:36:05 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:36:13 --> Config Class Initialized
DEBUG - 2016-09-13 16:36:13 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:36:13 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:36:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:36:13 --> URI Class Initialized
DEBUG - 2016-09-13 16:36:13 --> Router Class Initialized
ERROR - 2016-09-13 16:36:13 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:37:01 --> Config Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:37:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:37:01 --> URI Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Router Class Initialized
DEBUG - 2016-09-13 16:37:01 --> No URI present. Default controller set.
DEBUG - 2016-09-13 16:37:01 --> Output Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 16:37:01 --> Security Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Input Class Initialized
DEBUG - 2016-09-13 16:37:01 --> XSS Filtering completed
DEBUG - 2016-09-13 16:37:01 --> XSS Filtering completed
DEBUG - 2016-09-13 16:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 16:37:01 --> Language Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Loader Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 16:37:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: url_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: file_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: common_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: form_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: security_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 16:37:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 16:37:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 16:37:01 --> Database Driver Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Session Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 16:37:01 --> Helper loaded: string_helper
DEBUG - 2016-09-13 16:37:01 --> Session routines successfully run
DEBUG - 2016-09-13 16:37:01 --> Native_session Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 16:37:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 16:37:01 --> Controller Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 16:37:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 16:37:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 16:37:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:37:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 16:37:01 --> User Agent Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Model Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Model Class Initialized
DEBUG - 2016-09-13 16:37:01 --> Model Class Initialized
ERROR - 2016-09-13 16:37:01 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 16:37:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 16:37:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 16:37:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 16:37:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 16:37:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 16:37:02 --> Final output sent to browser
DEBUG - 2016-09-13 16:37:02 --> Total execution time: 0.8876
DEBUG - 2016-09-13 16:37:05 --> Config Class Initialized
DEBUG - 2016-09-13 16:37:05 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:37:05 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:37:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:37:05 --> URI Class Initialized
DEBUG - 2016-09-13 16:37:05 --> Router Class Initialized
ERROR - 2016-09-13 16:37:05 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:37:11 --> Config Class Initialized
DEBUG - 2016-09-13 16:37:11 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:37:11 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:37:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:37:11 --> URI Class Initialized
DEBUG - 2016-09-13 16:37:11 --> Router Class Initialized
ERROR - 2016-09-13 16:37:11 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:37:19 --> Config Class Initialized
DEBUG - 2016-09-13 16:37:19 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:37:19 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:37:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:37:19 --> URI Class Initialized
DEBUG - 2016-09-13 16:37:19 --> Router Class Initialized
ERROR - 2016-09-13 16:37:19 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:37:56 --> Config Class Initialized
DEBUG - 2016-09-13 16:37:56 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:37:56 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:37:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:37:56 --> URI Class Initialized
DEBUG - 2016-09-13 16:37:56 --> Router Class Initialized
ERROR - 2016-09-13 16:37:56 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 16:38:44 --> Config Class Initialized
DEBUG - 2016-09-13 16:38:44 --> Hooks Class Initialized
DEBUG - 2016-09-13 16:38:44 --> Utf8 Class Initialized
DEBUG - 2016-09-13 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 16:38:44 --> URI Class Initialized
DEBUG - 2016-09-13 16:38:44 --> Router Class Initialized
ERROR - 2016-09-13 16:38:44 --> 404 Page Not Found --> img
DEBUG - 2016-09-13 17:08:00 --> Config Class Initialized
DEBUG - 2016-09-13 17:08:00 --> Hooks Class Initialized
DEBUG - 2016-09-13 17:08:00 --> Utf8 Class Initialized
DEBUG - 2016-09-13 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 17:08:00 --> URI Class Initialized
DEBUG - 2016-09-13 17:08:00 --> Router Class Initialized
DEBUG - 2016-09-13 17:08:01 --> No URI present. Default controller set.
DEBUG - 2016-09-13 17:08:01 --> Output Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 17:08:01 --> Security Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Input Class Initialized
DEBUG - 2016-09-13 17:08:01 --> XSS Filtering completed
DEBUG - 2016-09-13 17:08:01 --> XSS Filtering completed
DEBUG - 2016-09-13 17:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 17:08:01 --> Language Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Loader Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 17:08:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: url_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: file_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: form_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: security_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 17:08:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 17:08:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 17:08:01 --> Database Driver Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Session Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 17:08:01 --> Helper loaded: string_helper
DEBUG - 2016-09-13 17:08:01 --> Session routines successfully run
DEBUG - 2016-09-13 17:08:01 --> Native_session Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 17:08:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 17:08:01 --> Controller Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 17:08:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 17:08:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 17:08:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:08:01 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:08:01 --> User Agent Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Model Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Model Class Initialized
DEBUG - 2016-09-13 17:08:01 --> Model Class Initialized
ERROR - 2016-09-13 17:08:01 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 17:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 17:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 17:08:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 17:08:02 --> Final output sent to browser
DEBUG - 2016-09-13 17:08:02 --> Total execution time: 0.9100
DEBUG - 2016-09-13 17:47:13 --> Config Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Utf8 Class Initialized
DEBUG - 2016-09-13 17:47:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 17:47:13 --> URI Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Router Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Output Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Security Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Input Class Initialized
DEBUG - 2016-09-13 17:47:13 --> XSS Filtering completed
DEBUG - 2016-09-13 17:47:13 --> XSS Filtering completed
DEBUG - 2016-09-13 17:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 17:47:13 --> Language Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Loader Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 17:47:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: url_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: file_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: form_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: security_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 17:47:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 17:47:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 17:47:13 --> Database Driver Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Session Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 17:47:13 --> Helper loaded: string_helper
DEBUG - 2016-09-13 17:47:13 --> Session routines successfully run
DEBUG - 2016-09-13 17:47:13 --> Native_session Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 17:47:13 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:47:13 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 17:47:14 --> Controller Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 17:47:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 17:47:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 17:47:14 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:47:14 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:47:14 --> User Agent Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Model Class Initialized
DEBUG - 2016-09-13 17:47:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 17:47:14 --> Pagination Class Initialized
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 17:47:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 17:47:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-13 17:47:14 --> Final output sent to browser
DEBUG - 2016-09-13 17:47:14 --> Total execution time: 1.0811
DEBUG - 2016-09-13 17:50:37 --> Config Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 17:50:37 --> URI Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Router Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Output Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 17:50:37 --> Security Class Initialized
DEBUG - 2016-09-13 17:50:37 --> Input Class Initialized
DEBUG - 2016-09-13 17:50:37 --> XSS Filtering completed
DEBUG - 2016-09-13 17:50:38 --> XSS Filtering completed
DEBUG - 2016-09-13 17:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 17:50:38 --> Language Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Loader Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 17:50:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: url_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: file_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: form_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: security_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 17:50:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 17:50:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 17:50:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Session Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 17:50:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 17:50:38 --> Session routines successfully run
DEBUG - 2016-09-13 17:50:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 17:50:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 17:50:38 --> Controller Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 17:50:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 17:50:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 17:50:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:50:38 --> Carabiner: library configured.
DEBUG - 2016-09-13 17:50:38 --> User Agent Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Model Class Initialized
DEBUG - 2016-09-13 17:50:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 17:50:38 --> Pagination Class Initialized
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:50:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 17:50:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 17:50:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-09-13 17:50:39 --> Final output sent to browser
DEBUG - 2016-09-13 17:50:39 --> Total execution time: 1.0957
DEBUG - 2016-09-13 18:05:38 --> Config Class Initialized
DEBUG - 2016-09-13 18:05:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:05:38 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:05:38 --> URI Class Initialized
DEBUG - 2016-09-13 18:05:38 --> Router Class Initialized
DEBUG - 2016-09-13 18:05:38 --> Output Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 18:05:39 --> Security Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Input Class Initialized
DEBUG - 2016-09-13 18:05:39 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:39 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:05:39 --> Language Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Loader Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:05:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:05:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:05:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:05:39 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Session Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:05:39 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:05:39 --> Session routines successfully run
DEBUG - 2016-09-13 18:05:39 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:05:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:05:39 --> Controller Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 18:05:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 18:05:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 18:05:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:39 --> User Agent Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:39 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 18:05:40 --> Pagination Class Initialized
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-09-13 18:05:40 --> Final output sent to browser
DEBUG - 2016-09-13 18:05:40 --> Total execution time: 1.3900
DEBUG - 2016-09-13 18:05:44 --> Config Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:05:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:05:44 --> URI Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Router Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Output Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 18:05:44 --> Security Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Input Class Initialized
DEBUG - 2016-09-13 18:05:44 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:44 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:05:44 --> Language Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Loader Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:05:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:05:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:05:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:05:44 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Session Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:05:44 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:05:44 --> Session routines successfully run
DEBUG - 2016-09-13 18:05:44 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:05:44 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:05:44 --> Controller Class Initialized
DEBUG - 2016-09-13 18:05:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 18:05:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 18:05:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 18:05:44 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:44 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:44 --> User Agent Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 18:05:45 --> Pagination Class Initialized
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-13 18:05:45 --> Final output sent to browser
DEBUG - 2016-09-13 18:05:45 --> Total execution time: 1.1967
DEBUG - 2016-09-13 18:05:47 --> Config Class Initialized
DEBUG - 2016-09-13 18:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:05:47 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:05:48 --> URI Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Router Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Output Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Security Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Input Class Initialized
DEBUG - 2016-09-13 18:05:48 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:48 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:05:48 --> Language Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Loader Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:05:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:05:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:05:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:05:48 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Session Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:05:48 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:05:48 --> Session routines successfully run
DEBUG - 2016-09-13 18:05:48 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:05:48 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:05:48 --> Controller Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 18:05:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 18:05:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 18:05:48 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:48 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:48 --> User Agent Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:48 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:49 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:49 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:49 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-13 18:05:49 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:05:49 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-09-13 18:05:49 --> Final output sent to browser
DEBUG - 2016-09-13 18:05:49 --> Total execution time: 1.1679
DEBUG - 2016-09-13 18:05:56 --> Config Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:05:56 --> URI Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Router Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Output Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 18:05:56 --> Security Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Input Class Initialized
DEBUG - 2016-09-13 18:05:56 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:56 --> XSS Filtering completed
DEBUG - 2016-09-13 18:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:05:56 --> Language Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Loader Class Initialized
DEBUG - 2016-09-13 18:05:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:05:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:05:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:05:57 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Session Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:05:57 --> Session routines successfully run
DEBUG - 2016-09-13 18:05:57 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:05:57 --> Controller Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 18:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 18:05:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 18:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:05:57 --> User Agent Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Model Class Initialized
DEBUG - 2016-09-13 18:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 18:05:57 --> Pagination Class Initialized
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:05:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-13 18:05:58 --> Final output sent to browser
DEBUG - 2016-09-13 18:05:58 --> Total execution time: 1.1627
DEBUG - 2016-09-13 18:09:06 --> Config Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:09:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:09:06 --> URI Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Router Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Output Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 18:09:06 --> Security Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Input Class Initialized
DEBUG - 2016-09-13 18:09:06 --> XSS Filtering completed
DEBUG - 2016-09-13 18:09:06 --> XSS Filtering completed
DEBUG - 2016-09-13 18:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:09:06 --> Language Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Loader Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:09:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:09:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:09:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:09:06 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Session Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:09:06 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:09:06 --> Session routines successfully run
DEBUG - 2016-09-13 18:09:06 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:09:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:09:06 --> Controller Class Initialized
DEBUG - 2016-09-13 18:09:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 18:09:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 18:09:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 18:09:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:09:06 --> Carabiner: library configured.
DEBUG - 2016-09-13 18:09:06 --> User Agent Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Model Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Model Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Model Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Model Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Model Class Initialized
DEBUG - 2016-09-13 18:09:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 18:09:07 --> Pagination Class Initialized
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 18:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 18:09:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-13 18:09:07 --> Final output sent to browser
DEBUG - 2016-09-13 18:09:07 --> Total execution time: 1.1516
DEBUG - 2016-09-13 18:09:10 --> Config Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:09:10 --> URI Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Router Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Output Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Security Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Input Class Initialized
DEBUG - 2016-09-13 18:09:10 --> XSS Filtering completed
DEBUG - 2016-09-13 18:09:10 --> XSS Filtering completed
DEBUG - 2016-09-13 18:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:09:10 --> Language Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Loader Class Initialized
DEBUG - 2016-09-13 18:09:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:09:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:09:10 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:09:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:09:10 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:09:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:09:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:09:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:09:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:09:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:09:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:09:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:09:11 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:09:11 --> Session Class Initialized
DEBUG - 2016-09-13 18:09:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:09:11 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:09:11 --> Session routines successfully run
DEBUG - 2016-09-13 18:09:11 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:09:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:09:11 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:09:11 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:09:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:09:11 --> Controller Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Config Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:22:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:22:33 --> URI Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Router Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Output Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Security Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Input Class Initialized
DEBUG - 2016-09-13 18:22:33 --> XSS Filtering completed
DEBUG - 2016-09-13 18:22:33 --> XSS Filtering completed
DEBUG - 2016-09-13 18:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:22:33 --> Language Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Loader Class Initialized
DEBUG - 2016-09-13 18:22:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:22:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:22:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:22:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:22:34 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:22:34 --> Session Class Initialized
DEBUG - 2016-09-13 18:22:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:22:34 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:22:34 --> Session routines successfully run
DEBUG - 2016-09-13 18:22:34 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:22:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:22:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:22:34 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:22:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:22:34 --> Controller Class Initialized
DEBUG - 2016-09-13 18:22:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:22:34 --> Final output sent to browser
DEBUG - 2016-09-13 18:22:34 --> Total execution time: 0.9207
DEBUG - 2016-09-13 18:23:27 --> Config Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:23:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:23:27 --> URI Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Router Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Output Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Security Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Input Class Initialized
DEBUG - 2016-09-13 18:23:27 --> XSS Filtering completed
DEBUG - 2016-09-13 18:23:27 --> XSS Filtering completed
DEBUG - 2016-09-13 18:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:23:27 --> Language Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Loader Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:23:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:23:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:23:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:23:27 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Session Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:23:27 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:23:27 --> Session routines successfully run
DEBUG - 2016-09-13 18:23:27 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:23:27 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:23:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:23:27 --> Controller Class Initialized
DEBUG - 2016-09-13 18:23:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:23:28 --> Final output sent to browser
DEBUG - 2016-09-13 18:23:28 --> Total execution time: 0.9146
DEBUG - 2016-09-13 18:26:34 --> Config Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:26:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:26:34 --> URI Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Router Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Output Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Security Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Input Class Initialized
DEBUG - 2016-09-13 18:26:34 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:34 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:26:34 --> Language Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Loader Class Initialized
DEBUG - 2016-09-13 18:26:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:26:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:26:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:26:34 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:26:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:26:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:26:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:26:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:26:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:26:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:26:35 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:26:35 --> Session Class Initialized
DEBUG - 2016-09-13 18:26:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:26:35 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:26:35 --> Session routines successfully run
DEBUG - 2016-09-13 18:26:35 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:26:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:26:35 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:35 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:26:35 --> Controller Class Initialized
DEBUG - 2016-09-13 18:26:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:26:35 --> Final output sent to browser
DEBUG - 2016-09-13 18:26:35 --> Total execution time: 0.9255
DEBUG - 2016-09-13 18:26:37 --> Config Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:26:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:26:37 --> URI Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Router Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Output Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Security Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Input Class Initialized
DEBUG - 2016-09-13 18:26:37 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:37 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:26:37 --> Language Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Loader Class Initialized
DEBUG - 2016-09-13 18:26:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:26:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:26:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:26:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:26:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:26:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:26:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:26:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:26:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:26:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:26:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:26:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:26:38 --> Session Class Initialized
DEBUG - 2016-09-13 18:26:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:26:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:26:38 --> Session routines successfully run
DEBUG - 2016-09-13 18:26:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:26:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:26:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:26:38 --> Controller Class Initialized
DEBUG - 2016-09-13 18:26:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:26:38 --> Final output sent to browser
DEBUG - 2016-09-13 18:26:38 --> Total execution time: 0.9562
DEBUG - 2016-09-13 18:26:58 --> Config Class Initialized
DEBUG - 2016-09-13 18:26:58 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:26:58 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:26:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:26:59 --> URI Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Router Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Output Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Security Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Input Class Initialized
DEBUG - 2016-09-13 18:26:59 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:59 --> XSS Filtering completed
DEBUG - 2016-09-13 18:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:26:59 --> Language Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Loader Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:26:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:26:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:26:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:26:59 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Session Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:26:59 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:26:59 --> Session routines successfully run
DEBUG - 2016-09-13 18:26:59 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:26:59 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:26:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:26:59 --> Controller Class Initialized
ERROR - 2016-09-13 18:26:59 --> Severity: Notice  --> Array to string conversion E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 6
DEBUG - 2016-09-13 18:26:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:26:59 --> Final output sent to browser
DEBUG - 2016-09-13 18:26:59 --> Total execution time: 0.9865
DEBUG - 2016-09-13 18:27:02 --> Config Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:27:02 --> URI Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Router Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Output Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Security Class Initialized
DEBUG - 2016-09-13 18:27:02 --> Input Class Initialized
DEBUG - 2016-09-13 18:27:03 --> XSS Filtering completed
DEBUG - 2016-09-13 18:27:03 --> XSS Filtering completed
DEBUG - 2016-09-13 18:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:27:03 --> Language Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Loader Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:27:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:27:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:27:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:27:03 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Session Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:27:03 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:27:03 --> Session routines successfully run
DEBUG - 2016-09-13 18:27:03 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:27:03 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:27:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:27:03 --> Controller Class Initialized
ERROR - 2016-09-13 18:27:03 --> Severity: Notice  --> Array to string conversion E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 6
DEBUG - 2016-09-13 18:27:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:27:03 --> Final output sent to browser
DEBUG - 2016-09-13 18:27:03 --> Total execution time: 0.9747
DEBUG - 2016-09-13 18:28:46 --> Config Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:28:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:28:46 --> URI Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Router Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Output Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Security Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Input Class Initialized
DEBUG - 2016-09-13 18:28:46 --> XSS Filtering completed
DEBUG - 2016-09-13 18:28:46 --> XSS Filtering completed
DEBUG - 2016-09-13 18:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:28:46 --> Language Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Loader Class Initialized
DEBUG - 2016-09-13 18:28:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:28:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:28:46 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:28:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:28:46 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:28:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:28:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:28:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:28:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:28:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:28:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:28:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:28:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:28:47 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:28:47 --> Session Class Initialized
DEBUG - 2016-09-13 18:28:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:28:47 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:28:47 --> Session routines successfully run
DEBUG - 2016-09-13 18:28:47 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:28:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:28:47 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:28:47 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:28:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:28:47 --> Controller Class Initialized
DEBUG - 2016-09-13 18:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:28:47 --> Final output sent to browser
DEBUG - 2016-09-13 18:28:47 --> Total execution time: 0.9764
DEBUG - 2016-09-13 18:30:01 --> Config Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:30:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:30:01 --> URI Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Router Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Output Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Security Class Initialized
DEBUG - 2016-09-13 18:30:01 --> Input Class Initialized
DEBUG - 2016-09-13 18:30:01 --> XSS Filtering completed
DEBUG - 2016-09-13 18:30:01 --> XSS Filtering completed
DEBUG - 2016-09-13 18:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:30:02 --> Language Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Loader Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:30:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:30:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:30:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:30:02 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Session Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:30:02 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:30:02 --> Session routines successfully run
DEBUG - 2016-09-13 18:30:02 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:30:02 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:30:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:30:02 --> Controller Class Initialized
DEBUG - 2016-09-13 18:30:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:30:02 --> Final output sent to browser
DEBUG - 2016-09-13 18:30:02 --> Total execution time: 0.9853
DEBUG - 2016-09-13 18:32:22 --> Config Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:32:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:32:22 --> URI Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Router Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Output Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Security Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Input Class Initialized
DEBUG - 2016-09-13 18:32:22 --> XSS Filtering completed
DEBUG - 2016-09-13 18:32:22 --> XSS Filtering completed
DEBUG - 2016-09-13 18:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:32:22 --> Language Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Loader Class Initialized
DEBUG - 2016-09-13 18:32:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:32:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:32:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:32:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:32:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:32:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:32:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:32:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:32:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:32:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:32:22 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:32:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:32:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:32:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:32:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:32:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:32:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:32:23 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:32:23 --> Session Class Initialized
DEBUG - 2016-09-13 18:32:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:32:23 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:32:23 --> Session routines successfully run
DEBUG - 2016-09-13 18:32:23 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:32:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:32:23 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:32:23 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:32:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:32:23 --> Controller Class Initialized
DEBUG - 2016-09-13 18:32:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:32:23 --> Final output sent to browser
DEBUG - 2016-09-13 18:32:23 --> Total execution time: 0.9922
DEBUG - 2016-09-13 18:34:06 --> Config Class Initialized
DEBUG - 2016-09-13 18:34:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:34:06 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:34:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:34:06 --> URI Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Router Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Output Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Security Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Input Class Initialized
DEBUG - 2016-09-13 18:34:07 --> XSS Filtering completed
DEBUG - 2016-09-13 18:34:07 --> XSS Filtering completed
DEBUG - 2016-09-13 18:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:34:07 --> Language Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Loader Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:34:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:34:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:34:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:34:07 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Session Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:34:07 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:34:07 --> Session routines successfully run
DEBUG - 2016-09-13 18:34:07 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:34:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:34:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:34:07 --> Controller Class Initialized
DEBUG - 2016-09-13 18:34:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:34:07 --> Final output sent to browser
DEBUG - 2016-09-13 18:34:07 --> Total execution time: 1.0107
DEBUG - 2016-09-13 18:35:28 --> Config Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:35:28 --> URI Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Router Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Output Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Security Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Input Class Initialized
DEBUG - 2016-09-13 18:35:28 --> XSS Filtering completed
DEBUG - 2016-09-13 18:35:28 --> XSS Filtering completed
DEBUG - 2016-09-13 18:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:35:28 --> Language Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Loader Class Initialized
DEBUG - 2016-09-13 18:35:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:35:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:35:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:35:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:35:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:35:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:35:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:35:29 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:35:29 --> Session Class Initialized
DEBUG - 2016-09-13 18:35:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:35:29 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:35:29 --> Session routines successfully run
DEBUG - 2016-09-13 18:35:29 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:35:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:35:29 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:35:29 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:35:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:35:29 --> Controller Class Initialized
ERROR - 2016-09-13 18:35:29 --> Severity: Notice  --> Undefined variable: daftar_nama E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 3
ERROR - 2016-09-13 18:35:29 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 3
DEBUG - 2016-09-13 18:35:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:35:29 --> Final output sent to browser
DEBUG - 2016-09-13 18:35:29 --> Total execution time: 1.0404
DEBUG - 2016-09-13 18:35:59 --> Config Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:35:59 --> URI Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Router Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Output Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Security Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Input Class Initialized
DEBUG - 2016-09-13 18:35:59 --> XSS Filtering completed
DEBUG - 2016-09-13 18:35:59 --> XSS Filtering completed
DEBUG - 2016-09-13 18:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:35:59 --> Language Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Loader Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:35:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:35:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:35:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:35:59 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Session Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:35:59 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:35:59 --> Session routines successfully run
DEBUG - 2016-09-13 18:35:59 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:35:59 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:35:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:36:00 --> Controller Class Initialized
DEBUG - 2016-09-13 18:36:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:36:00 --> Final output sent to browser
DEBUG - 2016-09-13 18:36:00 --> Total execution time: 1.0248
DEBUG - 2016-09-13 18:36:42 --> Config Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:36:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:36:42 --> URI Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Router Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Output Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Security Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Input Class Initialized
DEBUG - 2016-09-13 18:36:42 --> XSS Filtering completed
DEBUG - 2016-09-13 18:36:42 --> XSS Filtering completed
DEBUG - 2016-09-13 18:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:36:42 --> Language Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Loader Class Initialized
DEBUG - 2016-09-13 18:36:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:36:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:36:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:36:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:36:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:36:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:36:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:36:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:36:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:36:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:36:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:36:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:36:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:36:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:36:43 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:36:43 --> Session Class Initialized
DEBUG - 2016-09-13 18:36:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:36:43 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:36:43 --> Session routines successfully run
DEBUG - 2016-09-13 18:36:43 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:36:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:36:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:36:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:36:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:36:43 --> Controller Class Initialized
DEBUG - 2016-09-13 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:36:43 --> Final output sent to browser
DEBUG - 2016-09-13 18:36:43 --> Total execution time: 1.0085
DEBUG - 2016-09-13 18:36:55 --> Config Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:36:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:36:55 --> URI Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Router Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Output Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Security Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Input Class Initialized
DEBUG - 2016-09-13 18:36:55 --> XSS Filtering completed
DEBUG - 2016-09-13 18:36:55 --> XSS Filtering completed
DEBUG - 2016-09-13 18:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:36:55 --> Language Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Loader Class Initialized
DEBUG - 2016-09-13 18:36:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:36:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:36:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:36:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:36:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:36:55 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:36:56 --> Session Class Initialized
DEBUG - 2016-09-13 18:36:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:36:56 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:36:56 --> Session routines successfully run
DEBUG - 2016-09-13 18:36:56 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:36:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:36:56 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:36:56 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:36:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:36:56 --> Controller Class Initialized
DEBUG - 2016-09-13 18:36:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:36:56 --> Final output sent to browser
DEBUG - 2016-09-13 18:36:56 --> Total execution time: 1.0323
DEBUG - 2016-09-13 18:39:09 --> Config Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:39:09 --> URI Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Router Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Output Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Security Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Input Class Initialized
DEBUG - 2016-09-13 18:39:09 --> XSS Filtering completed
DEBUG - 2016-09-13 18:39:09 --> XSS Filtering completed
DEBUG - 2016-09-13 18:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:39:09 --> Language Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Loader Class Initialized
DEBUG - 2016-09-13 18:39:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:39:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:39:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:39:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:39:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:39:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:39:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:39:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:39:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:39:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:39:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:39:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:39:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:39:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:39:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:39:10 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Session Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:39:10 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:39:10 --> Session routines successfully run
DEBUG - 2016-09-13 18:39:10 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:39:10 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:39:10 --> Controller Class Initialized
DEBUG - 2016-09-13 18:39:10 --> Model Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Config Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:39:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:39:53 --> URI Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Router Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Output Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Security Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Input Class Initialized
DEBUG - 2016-09-13 18:39:53 --> XSS Filtering completed
DEBUG - 2016-09-13 18:39:53 --> XSS Filtering completed
DEBUG - 2016-09-13 18:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:39:53 --> Language Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Loader Class Initialized
DEBUG - 2016-09-13 18:39:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:39:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:39:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:39:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:39:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:39:53 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Session Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:39:54 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:39:54 --> Session routines successfully run
DEBUG - 2016-09-13 18:39:54 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:39:54 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:39:54 --> Controller Class Initialized
DEBUG - 2016-09-13 18:39:54 --> Model Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Config Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:40:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:40:13 --> URI Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Router Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Output Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Security Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Input Class Initialized
DEBUG - 2016-09-13 18:40:13 --> XSS Filtering completed
DEBUG - 2016-09-13 18:40:13 --> XSS Filtering completed
DEBUG - 2016-09-13 18:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:40:13 --> Language Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Loader Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:40:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:40:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:40:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:40:13 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Session Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:40:13 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:40:13 --> Session routines successfully run
DEBUG - 2016-09-13 18:40:13 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:40:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:40:14 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:40:14 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:40:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:40:14 --> Controller Class Initialized
DEBUG - 2016-09-13 18:40:14 --> Model Class Initialized
DEBUG - 2016-09-13 18:40:14 --> Model Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Config Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:41:34 --> URI Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Router Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Output Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Security Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Input Class Initialized
DEBUG - 2016-09-13 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-13 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-13 18:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:41:34 --> Language Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Loader Class Initialized
DEBUG - 2016-09-13 18:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:41:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:41:34 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:41:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:41:34 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:41:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:41:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:41:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:41:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:41:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:41:35 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Session Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:41:35 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:41:35 --> Session routines successfully run
DEBUG - 2016-09-13 18:41:35 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:41:35 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:41:35 --> Controller Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Model Class Initialized
DEBUG - 2016-09-13 18:41:35 --> Model Class Initialized
DEBUG - 2016-09-13 18:41:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:41:35 --> Final output sent to browser
DEBUG - 2016-09-13 18:41:35 --> Total execution time: 1.1059
DEBUG - 2016-09-13 18:43:40 --> Config Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:43:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:43:40 --> URI Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Router Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Output Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Security Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Input Class Initialized
DEBUG - 2016-09-13 18:43:40 --> XSS Filtering completed
DEBUG - 2016-09-13 18:43:40 --> XSS Filtering completed
DEBUG - 2016-09-13 18:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:43:40 --> Language Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Loader Class Initialized
DEBUG - 2016-09-13 18:43:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:43:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:43:40 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:43:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:43:40 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:43:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:43:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:43:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:43:41 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Session Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:43:41 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:43:41 --> Session routines successfully run
DEBUG - 2016-09-13 18:43:41 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:43:41 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:43:41 --> Controller Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Model Class Initialized
DEBUG - 2016-09-13 18:43:41 --> Model Class Initialized
DEBUG - 2016-09-13 18:43:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/view_orang.php
DEBUG - 2016-09-13 18:43:41 --> Final output sent to browser
DEBUG - 2016-09-13 18:43:41 --> Total execution time: 1.1011
DEBUG - 2016-09-13 18:43:44 --> Config Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:43:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:43:44 --> URI Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Router Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Output Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Security Class Initialized
DEBUG - 2016-09-13 18:43:44 --> Input Class Initialized
DEBUG - 2016-09-13 18:43:44 --> XSS Filtering completed
DEBUG - 2016-09-13 18:43:44 --> XSS Filtering completed
DEBUG - 2016-09-13 18:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:43:45 --> Language Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Loader Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:43:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:43:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:43:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:43:45 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Session Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:43:45 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:43:45 --> Session routines successfully run
DEBUG - 2016-09-13 18:43:45 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:43:45 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:43:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:43:45 --> Controller Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Config Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Hooks Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Utf8 Class Initialized
DEBUG - 2016-09-13 18:46:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 18:46:08 --> URI Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Router Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Output Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Security Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Input Class Initialized
DEBUG - 2016-09-13 18:46:08 --> XSS Filtering completed
DEBUG - 2016-09-13 18:46:08 --> XSS Filtering completed
DEBUG - 2016-09-13 18:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 18:46:08 --> Language Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Loader Class Initialized
DEBUG - 2016-09-13 18:46:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 18:46:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: url_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: file_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:46:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 18:46:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 18:46:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: common_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: form_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 18:46:08 --> Helper loaded: security_helper
DEBUG - 2016-09-13 18:46:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:46:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 18:46:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 18:46:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 18:46:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 18:46:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 18:46:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 18:46:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 18:46:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 18:46:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 18:46:09 --> Database Driver Class Initialized
DEBUG - 2016-09-13 18:46:09 --> Session Class Initialized
DEBUG - 2016-09-13 18:46:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 18:46:09 --> Helper loaded: string_helper
DEBUG - 2016-09-13 18:46:09 --> Session routines successfully run
DEBUG - 2016-09-13 18:46:09 --> Native_session Class Initialized
DEBUG - 2016-09-13 18:46:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 18:46:09 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:46:09 --> Form Validation Class Initialized
DEBUG - 2016-09-13 18:46:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 18:46:09 --> Controller Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Config Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:00:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:00:38 --> URI Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Router Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Output Class Initialized
DEBUG - 2016-09-13 19:00:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:00:38 --> Security Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Input Class Initialized
DEBUG - 2016-09-13 19:00:39 --> XSS Filtering completed
DEBUG - 2016-09-13 19:00:39 --> XSS Filtering completed
DEBUG - 2016-09-13 19:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:00:39 --> Language Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Loader Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:00:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:00:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:00:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:00:39 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Session Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:00:39 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:00:39 --> Session routines successfully run
DEBUG - 2016-09-13 19:00:39 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:00:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:00:39 --> Controller Class Initialized
DEBUG - 2016-09-13 19:00:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:00:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:00:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:00:40 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:00:40 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:00:40 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-13 19:00:40 --> Pagination Class Initialized
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-13 19:00:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-13 19:00:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-13 19:00:40 --> Final output sent to browser
DEBUG - 2016-09-13 19:00:40 --> Total execution time: 1.3799
DEBUG - 2016-09-13 19:00:42 --> Config Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:00:42 --> URI Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Router Class Initialized
DEBUG - 2016-09-13 19:00:42 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:00:42 --> Output Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:00:42 --> Security Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Input Class Initialized
DEBUG - 2016-09-13 19:00:42 --> XSS Filtering completed
DEBUG - 2016-09-13 19:00:42 --> XSS Filtering completed
DEBUG - 2016-09-13 19:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:00:42 --> Language Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Loader Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:00:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:00:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:00:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:00:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:00:42 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:00:42 --> Session Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:00:43 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:00:43 --> Session routines successfully run
DEBUG - 2016-09-13 19:00:43 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:00:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:00:43 --> Controller Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:00:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:00:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:00:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:00:43 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:00:43 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Model Class Initialized
DEBUG - 2016-09-13 19:00:43 --> Model Class Initialized
ERROR - 2016-09-13 19:00:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:00:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:00:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:00:43 --> Final output sent to browser
DEBUG - 2016-09-13 19:00:43 --> Total execution time: 1.3278
DEBUG - 2016-09-13 19:02:57 --> Config Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:02:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:02:57 --> URI Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Router Class Initialized
DEBUG - 2016-09-13 19:02:57 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:02:57 --> Output Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:02:57 --> Security Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Input Class Initialized
DEBUG - 2016-09-13 19:02:57 --> XSS Filtering completed
DEBUG - 2016-09-13 19:02:57 --> XSS Filtering completed
DEBUG - 2016-09-13 19:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:02:57 --> Language Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Loader Class Initialized
DEBUG - 2016-09-13 19:02:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:02:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:02:57 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:02:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:02:57 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:02:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:02:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:02:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:02:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:02:58 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Session Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:02:58 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:02:58 --> Session routines successfully run
DEBUG - 2016-09-13 19:02:58 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:02:58 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:02:58 --> Controller Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:02:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:02:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:02:58 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:02:58 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:02:58 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Model Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Model Class Initialized
DEBUG - 2016-09-13 19:02:58 --> Model Class Initialized
ERROR - 2016-09-13 19:02:58 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:02:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:02:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:02:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:02:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:02:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:02:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:02:59 --> Final output sent to browser
DEBUG - 2016-09-13 19:02:59 --> Total execution time: 1.3576
DEBUG - 2016-09-13 19:07:23 --> Config Class Initialized
DEBUG - 2016-09-13 19:07:23 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:07:23 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:07:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:07:23 --> URI Class Initialized
DEBUG - 2016-09-13 19:07:23 --> Router Class Initialized
DEBUG - 2016-09-13 19:07:23 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:07:23 --> Output Class Initialized
DEBUG - 2016-09-13 19:07:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:07:23 --> Security Class Initialized
DEBUG - 2016-09-13 19:07:23 --> Input Class Initialized
DEBUG - 2016-09-13 19:07:23 --> XSS Filtering completed
DEBUG - 2016-09-13 19:07:24 --> XSS Filtering completed
DEBUG - 2016-09-13 19:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:07:24 --> Language Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Loader Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:07:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:07:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:07:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:07:24 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Session Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:07:24 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:07:24 --> Session routines successfully run
DEBUG - 2016-09-13 19:07:24 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:07:24 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:07:24 --> Controller Class Initialized
DEBUG - 2016-09-13 19:07:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:07:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:07:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:07:25 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:07:25 --> Model Class Initialized
DEBUG - 2016-09-13 19:07:25 --> Model Class Initialized
DEBUG - 2016-09-13 19:07:25 --> Model Class Initialized
ERROR - 2016-09-13 19:07:25 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:07:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:07:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:07:25 --> Final output sent to browser
DEBUG - 2016-09-13 19:07:25 --> Total execution time: 1.3680
DEBUG - 2016-09-13 19:11:06 --> Config Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:11:06 --> URI Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Router Class Initialized
DEBUG - 2016-09-13 19:11:06 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:11:06 --> Output Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:11:06 --> Security Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Input Class Initialized
DEBUG - 2016-09-13 19:11:06 --> XSS Filtering completed
DEBUG - 2016-09-13 19:11:06 --> XSS Filtering completed
DEBUG - 2016-09-13 19:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:11:06 --> Language Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Loader Class Initialized
DEBUG - 2016-09-13 19:11:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:11:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:11:06 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:11:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:11:07 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Session Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:11:07 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:11:07 --> Session routines successfully run
DEBUG - 2016-09-13 19:11:07 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:11:07 --> Controller Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:11:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:11:07 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Model Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Model Class Initialized
DEBUG - 2016-09-13 19:11:07 --> Model Class Initialized
ERROR - 2016-09-13 19:11:08 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:11:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:11:08 --> Final output sent to browser
DEBUG - 2016-09-13 19:11:08 --> Total execution time: 1.3928
DEBUG - 2016-09-13 19:20:09 --> Config Class Initialized
DEBUG - 2016-09-13 19:20:09 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:20:09 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:20:09 --> URI Class Initialized
DEBUG - 2016-09-13 19:20:09 --> Router Class Initialized
DEBUG - 2016-09-13 19:20:09 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:20:09 --> Output Class Initialized
DEBUG - 2016-09-13 19:20:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:20:09 --> Security Class Initialized
DEBUG - 2016-09-13 19:20:09 --> Input Class Initialized
DEBUG - 2016-09-13 19:20:09 --> XSS Filtering completed
DEBUG - 2016-09-13 19:20:10 --> XSS Filtering completed
DEBUG - 2016-09-13 19:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:20:10 --> Language Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Loader Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:20:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:20:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:20:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:20:10 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Session Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:20:10 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:20:10 --> Session routines successfully run
DEBUG - 2016-09-13 19:20:10 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:20:10 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:20:10 --> Controller Class Initialized
DEBUG - 2016-09-13 19:20:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:20:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:20:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:20:11 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:20:11 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:20:11 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:20:11 --> Model Class Initialized
DEBUG - 2016-09-13 19:20:11 --> Model Class Initialized
DEBUG - 2016-09-13 19:20:11 --> Model Class Initialized
ERROR - 2016-09-13 19:20:11 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:20:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:20:11 --> Final output sent to browser
DEBUG - 2016-09-13 19:20:11 --> Total execution time: 1.3925
DEBUG - 2016-09-13 19:20:37 --> Config Class Initialized
DEBUG - 2016-09-13 19:20:37 --> Hooks Class Initialized
DEBUG - 2016-09-13 19:20:37 --> Utf8 Class Initialized
DEBUG - 2016-09-13 19:20:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-13 19:20:37 --> URI Class Initialized
DEBUG - 2016-09-13 19:20:37 --> Router Class Initialized
DEBUG - 2016-09-13 19:20:37 --> No URI present. Default controller set.
DEBUG - 2016-09-13 19:20:37 --> Output Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-13 19:20:38 --> Security Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Input Class Initialized
DEBUG - 2016-09-13 19:20:38 --> XSS Filtering completed
DEBUG - 2016-09-13 19:20:38 --> XSS Filtering completed
DEBUG - 2016-09-13 19:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-13 19:20:38 --> Language Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Loader Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-13 19:20:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: url_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: file_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: common_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: form_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: security_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-13 19:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-13 19:20:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-13 19:20:38 --> Database Driver Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Session Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-13 19:20:38 --> Helper loaded: string_helper
DEBUG - 2016-09-13 19:20:38 --> Session routines successfully run
DEBUG - 2016-09-13 19:20:38 --> Native_session Class Initialized
DEBUG - 2016-09-13 19:20:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-13 19:20:38 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Form Validation Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-13 19:20:39 --> Controller Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-13 19:20:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-13 19:20:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-13 19:20:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:20:39 --> Carabiner: library configured.
DEBUG - 2016-09-13 19:20:39 --> User Agent Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Model Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Model Class Initialized
DEBUG - 2016-09-13 19:20:39 --> Model Class Initialized
ERROR - 2016-09-13 19:20:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-13 19:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-13 19:20:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-13 19:20:39 --> Final output sent to browser
DEBUG - 2016-09-13 19:20:39 --> Total execution time: 1.4143
