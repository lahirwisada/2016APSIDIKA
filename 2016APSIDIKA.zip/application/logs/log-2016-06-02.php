<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-06-02 21:40:40 --> Config Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:40:40 --> URI Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Router Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Output Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:40:40 --> Security Class Initialized
DEBUG - 2016-06-02 21:40:40 --> Input Class Initialized
DEBUG - 2016-06-02 21:40:40 --> XSS Filtering completed
DEBUG - 2016-06-02 21:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:40:40 --> Language Class Initialized
DEBUG - 2016-06-02 21:40:41 --> Loader Class Initialized
DEBUG - 2016-06-02 21:40:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:40:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:40:41 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:40:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:40:41 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Session Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:40:42 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:40:42 --> A session cookie was not found.
DEBUG - 2016-06-02 21:40:42 --> Session routines successfully run
DEBUG - 2016-06-02 21:40:42 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:40:42 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:40:42 --> Controller Class Initialized
DEBUG - 2016-06-02 21:40:42 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:40:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:40:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:40:42 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:40:42 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:40:42 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:40:43 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:43 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:43 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:45 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:40:45 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-02 21:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:40:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-02 21:40:46 --> Final output sent to browser
DEBUG - 2016-06-02 21:40:46 --> Total execution time: 5.3274
DEBUG - 2016-06-02 21:40:54 --> Config Class Initialized
DEBUG - 2016-06-02 21:40:54 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:40:54 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:40:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:40:54 --> URI Class Initialized
DEBUG - 2016-06-02 21:40:54 --> Router Class Initialized
ERROR - 2016-06-02 21:40:54 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-02 21:40:57 --> Config Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:40:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:40:57 --> URI Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Router Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Output Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:40:57 --> Security Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Input Class Initialized
DEBUG - 2016-06-02 21:40:57 --> XSS Filtering completed
DEBUG - 2016-06-02 21:40:57 --> XSS Filtering completed
DEBUG - 2016-06-02 21:40:57 --> XSS Filtering completed
DEBUG - 2016-06-02 21:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:40:57 --> Language Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Loader Class Initialized
DEBUG - 2016-06-02 21:40:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:40:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:40:57 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:40:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:40:57 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Session Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:40:58 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:40:58 --> Session routines successfully run
DEBUG - 2016-06-02 21:40:58 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:40:58 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:40:58 --> Controller Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:40:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:40:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:40:58 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:40:58 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:40:58 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:40:58 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:41:00 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:41:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:41:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-02 21:41:00 --> Final output sent to browser
DEBUG - 2016-06-02 21:41:00 --> Total execution time: 2.3119
DEBUG - 2016-06-02 21:41:00 --> Config Class Initialized
DEBUG - 2016-06-02 21:41:00 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:41:00 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:41:00 --> URI Class Initialized
DEBUG - 2016-06-02 21:41:00 --> Router Class Initialized
ERROR - 2016-06-02 21:41:00 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-02 21:41:08 --> Config Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:41:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:41:08 --> URI Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Router Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Output Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Security Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Input Class Initialized
DEBUG - 2016-06-02 21:41:08 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:08 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:08 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:41:08 --> Language Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Loader Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:41:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:41:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:08 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Session Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:41:08 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:41:08 --> Session routines successfully run
DEBUG - 2016-06-02 21:41:08 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:41:08 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:41:08 --> Controller Class Initialized
DEBUG - 2016-06-02 21:41:08 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:41:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:41:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:41:08 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:08 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:09 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:09 --> Model Class Initialized
ERROR - 2016-06-02 21:41:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:163) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-06-02 21:41:50 --> Config Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:41:50 --> URI Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Router Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Output Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Security Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Input Class Initialized
DEBUG - 2016-06-02 21:41:50 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:50 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:50 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:41:50 --> Language Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Loader Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:41:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:50 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Session Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:41:50 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:41:50 --> Session routines successfully run
DEBUG - 2016-06-02 21:41:50 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:41:50 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:41:50 --> Controller Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:41:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:41:50 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:50 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:50 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:41:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-06-02 21:41:51 --> Final output sent to browser
DEBUG - 2016-06-02 21:41:51 --> Total execution time: 0.2589
DEBUG - 2016-06-02 21:41:52 --> Config Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:41:52 --> URI Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Router Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Output Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Security Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Input Class Initialized
DEBUG - 2016-06-02 21:41:52 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:52 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:52 --> XSS Filtering completed
DEBUG - 2016-06-02 21:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:41:52 --> Language Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Loader Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:41:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:41:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:41:52 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Session Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:41:52 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:41:52 --> Session routines successfully run
DEBUG - 2016-06-02 21:41:52 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:41:52 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:41:52 --> Controller Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:41:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:41:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:41:52 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:52 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:41:52 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
DEBUG - 2016-06-02 21:41:52 --> Model Class Initialized
ERROR - 2016-06-02 21:41:52 --> 404 Page Not Found --> 
DEBUG - 2016-06-02 21:42:13 --> Config Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:42:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:42:13 --> URI Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Router Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Output Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:42:13 --> Security Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Input Class Initialized
DEBUG - 2016-06-02 21:42:13 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:13 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:13 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:42:13 --> Language Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Loader Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:42:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:13 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Session Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:42:13 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:42:13 --> Session routines successfully run
DEBUG - 2016-06-02 21:42:13 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:42:13 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:42:13 --> Controller Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:42:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:42:13 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:13 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:13 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:42:13 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-02 21:42:13 --> Final output sent to browser
DEBUG - 2016-06-02 21:42:13 --> Total execution time: 0.3271
DEBUG - 2016-06-02 21:42:18 --> Config Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:42:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:42:18 --> URI Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Router Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Output Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:42:18 --> Security Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Input Class Initialized
DEBUG - 2016-06-02 21:42:18 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:18 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:18 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:42:18 --> Language Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Loader Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:42:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:42:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:18 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Session Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:42:18 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:42:18 --> Session routines successfully run
DEBUG - 2016-06-02 21:42:18 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:42:18 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:42:18 --> Controller Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:42:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:42:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:42:18 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:18 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:18 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:42:18 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-06-02 21:42:19 --> Final output sent to browser
DEBUG - 2016-06-02 21:42:19 --> Total execution time: 0.6867
DEBUG - 2016-06-02 21:42:19 --> Config Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:42:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:42:19 --> URI Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Router Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Output Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Security Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Input Class Initialized
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:42:19 --> Language Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Loader Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:42:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Session Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:42:19 --> Session routines successfully run
DEBUG - 2016-06-02 21:42:19 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:42:19 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:42:19 --> Controller Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:42:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:42:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:42:19 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:19 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:19 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Config Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:42:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:42:19 --> URI Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Router Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Output Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:42:19 --> Security Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Input Class Initialized
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> XSS Filtering completed
DEBUG - 2016-06-02 21:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:42:19 --> Language Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Loader Class Initialized
DEBUG - 2016-06-02 21:42:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:42:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:42:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:42:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:42:19 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:42:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:42:20 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:42:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:42:20 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:42:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:42:20 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:42:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:42:20 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Session Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:42:20 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:42:20 --> Session routines successfully run
DEBUG - 2016-06-02 21:42:20 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:42:20 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:42:20 --> Controller Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:42:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:42:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:42:20 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:20 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:42:20 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Model Class Initialized
DEBUG - 2016-06-02 21:42:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:42:20 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:42:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:42:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-02 21:42:20 --> Final output sent to browser
DEBUG - 2016-06-02 21:42:20 --> Total execution time: 0.3859
DEBUG - 2016-06-02 21:47:40 --> Config Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:47:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:47:40 --> URI Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Router Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Output Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Security Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Input Class Initialized
DEBUG - 2016-06-02 21:47:40 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:40 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:40 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:47:40 --> Language Class Initialized
DEBUG - 2016-06-02 21:47:40 --> Loader Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:47:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:47:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:47:41 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Session Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:47:41 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:47:41 --> Session routines successfully run
DEBUG - 2016-06-02 21:47:41 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:47:41 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:47:41 --> Controller Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:47:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:47:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:47:41 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:47:41 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:47:41 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:47:41 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:47:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-06-02 21:47:41 --> Final output sent to browser
DEBUG - 2016-06-02 21:47:41 --> Total execution time: 0.4465
DEBUG - 2016-06-02 21:47:48 --> Config Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Hooks Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Utf8 Class Initialized
DEBUG - 2016-06-02 21:47:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-02 21:47:48 --> URI Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Router Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Output Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Cache file has expired. File deleted
DEBUG - 2016-06-02 21:47:48 --> Security Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Input Class Initialized
DEBUG - 2016-06-02 21:47:48 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:48 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:48 --> XSS Filtering completed
DEBUG - 2016-06-02 21:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-02 21:47:48 --> Language Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Loader Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-02 21:47:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: url_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: file_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: conf_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists common_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: common_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: form_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: security_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: lang_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: atlant_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: crypto_helper
DEBUG - 2016-06-02 21:47:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-02 21:47:48 --> Database Driver Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Session Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-02 21:47:48 --> Helper loaded: string_helper
DEBUG - 2016-06-02 21:47:48 --> Session routines successfully run
DEBUG - 2016-06-02 21:47:48 --> Native_session Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-02 21:47:48 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Form Validation Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-02 21:47:48 --> Controller Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Carabiner: Library initialized.
DEBUG - 2016-06-02 21:47:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-02 21:47:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-02 21:47:48 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:47:48 --> Carabiner: library configured.
DEBUG - 2016-06-02 21:47:48 --> User Agent Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Model Class Initialized
DEBUG - 2016-06-02 21:47:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-02 21:47:48 --> Pagination Class Initialized
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-02 21:47:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-02 21:47:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-02 21:47:48 --> Final output sent to browser
DEBUG - 2016-06-02 21:47:48 --> Total execution time: 0.4696
