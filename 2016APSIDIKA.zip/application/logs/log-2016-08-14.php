<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-14 09:45:40 --> Config Class Initialized
DEBUG - 2016-08-14 09:45:41 --> Hooks Class Initialized
DEBUG - 2016-08-14 09:45:42 --> Utf8 Class Initialized
DEBUG - 2016-08-14 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-14 09:45:43 --> URI Class Initialized
DEBUG - 2016-08-14 09:45:45 --> Router Class Initialized
DEBUG - 2016-08-14 09:45:47 --> Output Class Initialized
DEBUG - 2016-08-14 09:45:48 --> Cache file has expired. File deleted
DEBUG - 2016-08-14 09:45:48 --> Security Class Initialized
DEBUG - 2016-08-14 09:45:48 --> Input Class Initialized
DEBUG - 2016-08-14 09:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-14 09:45:48 --> Language Class Initialized
DEBUG - 2016-08-14 09:45:51 --> Loader Class Initialized
DEBUG - 2016-08-14 09:45:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-14 09:45:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-14 09:45:52 --> Helper loaded: url_helper
DEBUG - 2016-08-14 09:45:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-14 09:45:52 --> Helper loaded: file_helper
DEBUG - 2016-08-14 09:45:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 09:45:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-14 09:45:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-14 09:45:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 09:45:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-14 09:45:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: common_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: common_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: form_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: security_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 09:45:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 09:45:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-14 09:45:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-14 09:45:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: atlant_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 09:45:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-14 09:45:53 --> Helper loaded: crypto_helper
DEBUG - 2016-08-14 09:45:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 09:45:54 --> Database Driver Class Initialized
DEBUG - 2016-08-14 09:45:55 --> Session Class Initialized
DEBUG - 2016-08-14 09:45:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-14 09:45:55 --> Helper loaded: string_helper
DEBUG - 2016-08-14 09:45:55 --> A session cookie was not found.
DEBUG - 2016-08-14 09:45:55 --> Session routines successfully run
DEBUG - 2016-08-14 09:45:55 --> Native_session Class Initialized
DEBUG - 2016-08-14 09:45:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-14 09:45:55 --> Form Validation Class Initialized
DEBUG - 2016-08-14 09:45:56 --> Form Validation Class Initialized
DEBUG - 2016-08-14 09:45:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-14 09:45:56 --> Controller Class Initialized
DEBUG - 2016-08-14 09:45:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-14 09:45:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-14 09:45:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-14 09:45:56 --> Carabiner: library configured.
DEBUG - 2016-08-14 09:45:56 --> Carabiner: library configured.
DEBUG - 2016-08-14 09:45:56 --> User Agent Class Initialized
DEBUG - 2016-08-14 09:45:57 --> Model Class Initialized
DEBUG - 2016-08-14 09:45:57 --> Model Class Initialized
DEBUG - 2016-08-14 09:45:57 --> Model Class Initialized
DEBUG - 2016-08-14 09:45:59 --> Model Class Initialized
DEBUG - 2016-08-14 09:45:59 --> Model Class Initialized
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 09:46:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 09:46:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-14 09:46:03 --> Final output sent to browser
DEBUG - 2016-08-14 09:46:03 --> Total execution time: 23.8873
DEBUG - 2016-08-14 09:46:49 --> Config Class Initialized
DEBUG - 2016-08-14 09:46:49 --> Hooks Class Initialized
DEBUG - 2016-08-14 09:46:49 --> Utf8 Class Initialized
DEBUG - 2016-08-14 09:46:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-14 09:46:49 --> URI Class Initialized
DEBUG - 2016-08-14 09:46:49 --> Router Class Initialized
DEBUG - 2016-08-14 09:46:49 --> Output Class Initialized
DEBUG - 2016-08-14 09:46:50 --> Cache file has expired. File deleted
DEBUG - 2016-08-14 09:46:50 --> Security Class Initialized
DEBUG - 2016-08-14 09:46:50 --> Input Class Initialized
DEBUG - 2016-08-14 09:46:50 --> XSS Filtering completed
DEBUG - 2016-08-14 09:46:50 --> XSS Filtering completed
DEBUG - 2016-08-14 09:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-14 09:46:50 --> Language Class Initialized
DEBUG - 2016-08-14 09:46:50 --> Loader Class Initialized
DEBUG - 2016-08-14 09:46:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-14 09:46:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: url_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: file_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: conf_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists common_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: common_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: common_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: form_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: security_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: lang_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: atlant_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-14 09:46:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 09:46:51 --> Database Driver Class Initialized
DEBUG - 2016-08-14 09:46:51 --> Session Class Initialized
DEBUG - 2016-08-14 09:46:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-14 09:46:51 --> Helper loaded: string_helper
DEBUG - 2016-08-14 09:46:51 --> Session routines successfully run
DEBUG - 2016-08-14 09:46:51 --> Native_session Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-14 09:46:52 --> Form Validation Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Form Validation Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-14 09:46:52 --> Controller Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Carabiner: Library initialized.
DEBUG - 2016-08-14 09:46:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-14 09:46:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-14 09:46:52 --> Carabiner: library configured.
DEBUG - 2016-08-14 09:46:52 --> Carabiner: library configured.
DEBUG - 2016-08-14 09:46:52 --> User Agent Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Model Class Initialized
DEBUG - 2016-08-14 09:46:52 --> Model Class Initialized
DEBUG - 2016-08-14 09:46:53 --> Model Class Initialized
DEBUG - 2016-08-14 09:46:53 --> Model Class Initialized
DEBUG - 2016-08-14 09:46:53 --> Model Class Initialized
ERROR - 2016-08-14 09:46:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-14 09:46:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 09:46:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 09:46:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-08-14 09:46:54 --> Final output sent to browser
DEBUG - 2016-08-14 09:46:54 --> Total execution time: 3.8969
DEBUG - 2016-08-14 10:48:46 --> Config Class Initialized
DEBUG - 2016-08-14 10:48:46 --> Hooks Class Initialized
DEBUG - 2016-08-14 10:48:46 --> Utf8 Class Initialized
DEBUG - 2016-08-14 10:48:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-14 10:48:46 --> URI Class Initialized
DEBUG - 2016-08-14 10:48:46 --> Router Class Initialized
DEBUG - 2016-08-14 10:48:46 --> Output Class Initialized
DEBUG - 2016-08-14 10:48:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-14 10:48:47 --> Security Class Initialized
DEBUG - 2016-08-14 10:48:47 --> Input Class Initialized
DEBUG - 2016-08-14 10:48:47 --> XSS Filtering completed
DEBUG - 2016-08-14 10:48:47 --> XSS Filtering completed
DEBUG - 2016-08-14 10:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-14 10:48:47 --> Language Class Initialized
DEBUG - 2016-08-14 10:48:48 --> Loader Class Initialized
DEBUG - 2016-08-14 10:48:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-14 10:48:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: url_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: file_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: common_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: common_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: form_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: security_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-14 10:48:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-14 10:48:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 10:48:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-14 10:48:50 --> Helper loaded: crypto_helper
DEBUG - 2016-08-14 10:48:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 10:48:50 --> Database Driver Class Initialized
DEBUG - 2016-08-14 10:48:51 --> Session Class Initialized
DEBUG - 2016-08-14 10:48:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-14 10:48:51 --> Helper loaded: string_helper
DEBUG - 2016-08-14 10:48:51 --> Session routines successfully run
DEBUG - 2016-08-14 10:48:51 --> Native_session Class Initialized
DEBUG - 2016-08-14 10:48:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-14 10:48:52 --> Form Validation Class Initialized
DEBUG - 2016-08-14 10:48:52 --> Form Validation Class Initialized
DEBUG - 2016-08-14 10:48:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-14 10:48:53 --> Controller Class Initialized
DEBUG - 2016-08-14 10:48:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-14 10:48:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-14 10:48:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-14 10:48:53 --> Carabiner: library configured.
DEBUG - 2016-08-14 10:48:53 --> Carabiner: library configured.
DEBUG - 2016-08-14 10:48:54 --> User Agent Class Initialized
DEBUG - 2016-08-14 10:48:54 --> Model Class Initialized
DEBUG - 2016-08-14 10:48:55 --> Model Class Initialized
DEBUG - 2016-08-14 10:48:55 --> Model Class Initialized
DEBUG - 2016-08-14 10:48:56 --> Model Class Initialized
DEBUG - 2016-08-14 10:48:56 --> Model Class Initialized
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 10:48:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 10:48:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-14 10:48:59 --> Final output sent to browser
DEBUG - 2016-08-14 10:48:59 --> Total execution time: 13.9991
DEBUG - 2016-08-14 10:49:18 --> Config Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Hooks Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Utf8 Class Initialized
DEBUG - 2016-08-14 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-14 10:49:18 --> URI Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Router Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Output Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-14 10:49:18 --> Security Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Input Class Initialized
DEBUG - 2016-08-14 10:49:18 --> XSS Filtering completed
DEBUG - 2016-08-14 10:49:18 --> XSS Filtering completed
DEBUG - 2016-08-14 10:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-14 10:49:18 --> Language Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Loader Class Initialized
DEBUG - 2016-08-14 10:49:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-14 10:49:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: url_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: file_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: common_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: common_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: form_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: security_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-14 10:49:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-14 10:49:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-14 10:49:18 --> Database Driver Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Session Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-14 10:49:19 --> Helper loaded: string_helper
DEBUG - 2016-08-14 10:49:19 --> Session routines successfully run
DEBUG - 2016-08-14 10:49:19 --> Native_session Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-14 10:49:19 --> Form Validation Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Form Validation Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-14 10:49:19 --> Controller Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-14 10:49:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-14 10:49:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-14 10:49:19 --> Carabiner: library configured.
DEBUG - 2016-08-14 10:49:19 --> Carabiner: library configured.
DEBUG - 2016-08-14 10:49:19 --> User Agent Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Model Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Model Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Model Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Model Class Initialized
DEBUG - 2016-08-14 10:49:19 --> Model Class Initialized
ERROR - 2016-08-14 10:49:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-14 10:49:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-14 10:49:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-14 10:49:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-08-14 10:49:19 --> Final output sent to browser
DEBUG - 2016-08-14 10:49:19 --> Total execution time: 0.4413
