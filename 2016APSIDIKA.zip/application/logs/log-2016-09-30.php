<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-30 17:07:15 --> Config Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Utf8 Class Initialized
DEBUG - 2016-09-30 17:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 17:07:15 --> URI Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Router Class Initialized
DEBUG - 2016-09-30 17:07:15 --> No URI present. Default controller set.
DEBUG - 2016-09-30 17:07:15 --> Output Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-30 17:07:15 --> Security Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Input Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 17:07:15 --> Language Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Loader Class Initialized
DEBUG - 2016-09-30 17:07:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-30 17:07:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: url_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: file_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:07:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:07:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-30 17:07:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-30 17:07:15 --> Helper loaded: form_helper
DEBUG - 2016-09-30 17:07:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-30 17:07:16 --> Helper loaded: security_helper
DEBUG - 2016-09-30 17:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-30 17:07:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-30 17:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-30 17:07:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-30 17:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-30 17:07:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-30 17:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-30 17:07:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-30 17:07:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-30 17:07:16 --> Database Driver Class Initialized
ERROR - 2016-09-30 17:07:17 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-30 17:07:17 --> Unable to connect to the database
DEBUG - 2016-09-30 17:07:17 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-30 17:09:08 --> Config Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Utf8 Class Initialized
DEBUG - 2016-09-30 17:09:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 17:09:08 --> URI Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Router Class Initialized
DEBUG - 2016-09-30 17:09:08 --> No URI present. Default controller set.
DEBUG - 2016-09-30 17:09:08 --> Output Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Security Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Input Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 17:09:08 --> Language Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Loader Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-30 17:09:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: url_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: file_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: form_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: security_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-30 17:09:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-30 17:09:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-30 17:09:08 --> Database Driver Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Session Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-30 17:09:08 --> Helper loaded: string_helper
DEBUG - 2016-09-30 17:09:08 --> A session cookie was not found.
DEBUG - 2016-09-30 17:09:08 --> Session routines successfully run
DEBUG - 2016-09-30 17:09:08 --> Native_session Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-30 17:09:08 --> Form Validation Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Form Validation Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-30 17:09:08 --> Controller Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-30 17:09:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-30 17:09:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-30 17:09:08 --> Carabiner: library configured.
DEBUG - 2016-09-30 17:09:08 --> Carabiner: library configured.
DEBUG - 2016-09-30 17:09:08 --> User Agent Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:08 --> Model Class Initialized
ERROR - 2016-09-30 17:09:09 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-30 17:09:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-30 17:09:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-30 17:09:09 --> Final output sent to browser
DEBUG - 2016-09-30 17:09:09 --> Total execution time: 0.9193
DEBUG - 2016-09-30 17:09:10 --> Config Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Hooks Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Utf8 Class Initialized
DEBUG - 2016-09-30 17:09:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 17:09:10 --> URI Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Router Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Output Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-30 17:09:10 --> Security Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Input Class Initialized
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> XSS Filtering completed
DEBUG - 2016-09-30 17:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 17:09:10 --> Language Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Loader Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-30 17:09:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: url_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: file_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: common_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: form_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: security_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-30 17:09:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-30 17:09:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-30 17:09:10 --> Database Driver Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Session Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-30 17:09:10 --> Helper loaded: string_helper
DEBUG - 2016-09-30 17:09:10 --> Session routines successfully run
DEBUG - 2016-09-30 17:09:10 --> Native_session Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-30 17:09:10 --> Form Validation Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Form Validation Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-30 17:09:10 --> Controller Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-30 17:09:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-30 17:09:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-30 17:09:10 --> Carabiner: library configured.
DEBUG - 2016-09-30 17:09:10 --> Carabiner: library configured.
DEBUG - 2016-09-30 17:09:10 --> User Agent Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Model Class Initialized
DEBUG - 2016-09-30 17:09:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-30 17:09:10 --> Final output sent to browser
DEBUG - 2016-09-30 17:09:10 --> Total execution time: 0.7758
