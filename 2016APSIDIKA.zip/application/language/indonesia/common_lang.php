<?php

/* 
 * ID
 */

$lang['common_exists'] = "ada";
$lang['common_not_exists'] = "tidak";
$lang['common_bool_yes'] = "ya";
$lang['common_bool_no'] = "tidak";
$lang['common_sex_male'] = "pria";
$lang['common_sex_female'] = "wanita";
$lang['common_marriage_single'] = "lajang";
$lang['common_marriage_married'] = "menikah";