<?php

/* 
 * EN
 */

$lang['common_exists'] = "yes";
$lang['common_not_exists'] = "no";
$lang['common_bool_yes'] = "yes";
$lang['common_bool_no'] = "no";
$lang['common_sex_male'] = "male";
$lang['common_sex_female'] = "female";
$lang['common_marriage_single'] = "single";
$lang['common_marriage_married'] = "married";