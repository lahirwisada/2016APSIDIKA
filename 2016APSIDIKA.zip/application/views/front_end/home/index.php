<div class="page-content-wrap bg-dark light-elements">
    <div class="page-content-holder">
        <div class="block-heading block-heading-centralized this-animate" data-animate="fadeInDown">
            <h2><strong>Si Dika</strong> &mdash; Sistem Informasi Pendidikan dan Latihan</h2>
            <div class="block-heading-text">
                Mudah, Tepat dan cepat untuk pengelolaan diklat Kota Tangerang Selatan.
            </div>
        </div>
    </div>
</div>
<div class="page-content-wrap">
    <div class="page-content-holder">

        <div class="row">
            <?php echo load_partial('front_end/home/index/calender_diklat'); ?>
        </div>

    </div>
</div>