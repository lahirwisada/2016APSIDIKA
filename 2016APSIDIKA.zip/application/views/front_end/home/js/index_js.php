<script type="text/javascript">
    $(document).ready(function () {
        calender_diklat.init();
    });
</script>