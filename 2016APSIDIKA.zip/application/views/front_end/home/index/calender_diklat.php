<div class="panel panel-default">
    <div class="panel-heading">                                
        <h3 class="panel-title">Kalender Diklat</h3>
        <ul class="panel-controls">
            <li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>
            <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
            <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
        </ul>                                
    </div>
    <div id="divContainer" class="panel-body">
    </div>
</div>