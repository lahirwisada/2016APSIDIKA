<div class="row">
    <div class="col-md-6">
        <div class="panel panel-info">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 clearfix">
                        <h4 class="pull-left" style="margin: 0 0 20px;">Pendapatan</h4>
<!--                        <div class="btn-group pull-right">
                            <a href="javascript:;" class="btn btn-default btn-sm active">this week</a>
                            <a href="javascript:;" class="btn btn-default btn-sm ">previous week</a>
                        </div>-->
                    </div>
                    <div class="col-md-12">
                        <div id="plot-pendapatan" style="height:250px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="panel panel-grape">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12 clearfix">
                        <h4 class="pull-left" style="margin: 0 0 20px;">Pendaftaran Penghuni</h4>
<!--                        <div class="btn-group pull-right">
                            <a href="javascript:;" class="btn btn-default btn-sm active">2012</a>
                            <a href="javascript:;" class="btn btn-default btn-sm ">2011</a>
                            <a href="javascript:;" class="btn btn-default btn-sm ">2010</a>
                        </div>-->
                    </div>
                    <div class="col-md-12">
                        <div id="plot-penghuni" style="height:250px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>