<div class="row">

    <!-- about -->
    <?php /*
    <div class="col-md-12">
        &nbsp;
    </div>
     * 
     */
    ?>
    <!-- ./about -->

</div>