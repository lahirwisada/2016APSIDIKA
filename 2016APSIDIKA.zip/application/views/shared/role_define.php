<?php
$current_role = isset($current_role) ? $current_role : FALSE;
$const_role_administrator = isset($const_role_administrator) ? $const_role_administrator : FALSE;
$const_role_pengembang = isset($const_role_pengembang) ? $const_role_pengembang : FALSE;
$const_role_anggota = isset($const_role_anggota) ? $const_role_anggota : FALSE;
$const_role_tamu = isset($const_role_tamu) ? $const_role_tamu : FALSE;
?>