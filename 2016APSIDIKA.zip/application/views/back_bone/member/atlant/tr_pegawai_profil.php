<div class="form-group">
    <label class="col-md-3 col-xs-12 control-label">NIP *</label>
    <div class="col-md-6 col-xs-12">
        <select id="slc-nip" class="form-control select2-basic" name="id_pegawai">
        </select>                                       
        <span class="help-block">Pilih Pegawai.<br />Masukkan NIP sebagai kata kunci untuk melakukan pencarian.</span>
    </div>
</div>